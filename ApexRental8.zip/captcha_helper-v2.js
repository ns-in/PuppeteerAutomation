var request = require('request');

var inUrl = "http://2captcha.com/in.php";
var resUrl = "http://2captcha.com/res.php";
var apiKey = "ed8d2850ac7e012dddaf8b9d5031484e";
var details = {
    "isSolved": false,
    "error": null
};

var challengeUrl = '';

var gtParams = {
    challenge: '',
    googlekey: '',
    pageurl: ''
}

async function verifyCaptchaPage(page) {
    let ele = await page.evaluate(() => document.querySelector('#challenge-form'));
    console.log(JSON.stringify(ele));
    console.log(JSON.stringify(ele[0]));
    if (ele) {
        console.log("Real ALASKA user.");

        return true;
    }
    return false;
}

async function solveCaptchaPage(page, _challengeUrl) {
    challengeUrl = _challengeUrl;


    await retry(solveCaptchaRetry, page).then(() => {
        console.log("inside solve captcha retry main");
    }).catch(() => {
        console.log("inside solve captcha retry catch");
    });
}

async function solveCaptchaRetry(page) {

    //await page.setRequestInterception(true);

    if (challengeUrl) {
       
        var c = await page.evaluate(() => {
        var a  = document.querySelector('#challenge-form');
        console.log('a' + a);
        var b = a.querySelector("script").getAttribute("data-sitekey");
        console.log('a = ' + b);
        return b;
        });

        gtParams.googlekey  = c;
        
       // gtParams.googlekey = await page.evaluate(() => document.querySelector("script").getAttribute("data-sitekey"));
        gtParams.challenge = challengeUrl;
        //await page.setRequestInterception(false);
        if (gtParams.challenge && gtParams.googlekey) {
            console.log("calling solve captcha");
            //await page.setRequestInterception(false);
            let tokensResponse = await solveCaptchaAsync(gtParams, page);
            if (tokensResponse.status == 0) {
                console.log("unsolved captcha");
                console.log(tokensResponse);
                //    await page.evaluate((tokens) =>{ document.getElementById("g-recaptcha-response").innerHTML = tokens},tokens);


                //return Promise.reject(new Error("reject"));
            } 
            else {
                var token = tokensResponse.request;
                console.log(token);
                await page.evaluate((token) =>{ document.getElementById("g-recaptcha-response").innerHTML = token},token);
                //await page.click('#recaptcha_submit');
                await page.evaluate(() =>{ document.getElementById("recaptcha_submit").click()});
                

            }

        } else {
            console.log('bad geetest parameters');
        }

    }
}

async function retry(fn, param, retriesLeft = 2, interval = 3000) {
      //return new Promise((resolve, reject) => {
    try {
        // let funParam = await fn(param);
        return await fn(param);
    }
    catch (error) {
        setTimeout(() => {
            if (retriesLeft === 1) {
                console.log("retries over");
                details.isSolved = true;
               //  reject(error);
                return error;
            }
            param.removeAllListeners('request');
            param.removeAllListeners('requestfinished');
            console.log("calling retryiessssss");
            // Passing on "reject" is the important part
            retry(fn, param, retriesLeft - 1, interval).then(resolve, reject);
        }, interval);

    }
    //  })
}

async function solveCaptchaAsync(params, page) {
    var capUrl = inUrl + "?key=" + apiKey + "&method=userrecaptcha&googlekey=" + params.googlekey + "&pageurl=" + params.challenge + "&here=now&json=1";
    console.log("send captcha async");
    let id = await sendCaptchaAsync(capUrl);
    console.log("after send captcha async");
    console.log(id);
    // await page.waitFor(45000);
    let tokensResponse = await getTokenAsync(id);
    return tokensResponse;
}

async function sendCaptchaAsync(url) {
    var options = {
        url: url,
        method: 'GET'
    }
    return new Promise(function (resolve, reject) {
        request(options, function (err, response, body) {
            if (err) {
                resolve(err);
            }
            var res = JSON.parse(body);
            if (res.status === 1) {
                console.log("send captcha status 1");
                console.log(res.request);
                resolve(res.request);
            } else {
                console.log("send captcha print");
                console.log(res.request);
            }
        });
    });
}
async function getTokenAsync(id) {
    var reqResUrl = resUrl + "?key=" + apiKey + "&action=get&json=1&id=" + id;
    var options = {
        url: reqResUrl,
        method: 'GET'
    }
    return new Promise(function (resolve, reject) {
        var intId = setInterval(function () {
            request(options, function (err, response, body) {
                if (err) {
                    clearInterval(intId);
                    resolve("ERROR");
                }
                var res = JSON.parse(body);
                console.log(res);
                if (res.status === 1) {
                    clearInterval(intId);
                    resolve(res);
                } else if (res.request === "ERROR_CAPTCHA_UNSOLVABLE" || res.request === "ERROR_METHOD_CALL" || res.request === 'ERROR_TOKEN_EXPIRED') {
                    clearInterval(intId);
                    resolve(res);
                } else {
                    
                    console.log("get token print");
                    console.log(res);
                }
            });
        }, 15000);
    });
}


module.exports = { verifyCaptchaPage, solveCaptchaPage, details };