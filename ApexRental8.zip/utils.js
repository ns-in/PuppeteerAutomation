var azure = require('azure-storage');
var fs = require('fs');
var req = require('request');
var stream = require('stream');
let logDetails = [];
let filePatternTouploadToAzure = "stream";
var crawlRequestFile = process.argv.slice(2)[0];
var crawlRequest = JSON.parse(fs.readFileSync(crawlRequestFile));
var debugMode = crawlRequest['BotInfo']['DebugMode'];

var CacheFileAzurePath = crawlRequest['CacheFilePath'];
var requestDetailId = crawlRequest["MetaData"]["RowKey"];
var CacheFilePath = crawlRequest['ApiEndpoints']['CachePageServiceUrl'];
var subscriberId = crawlRequest["MetaData"]["SubscriberId"];

const logLevel = { "Info": "info", "Warn": "warn", "Error": "error" };
const strCommonMessage = "Bot name : " + crawlRequest['BotInfo']['BotName'] + " | ";

var data = {
    "AzureWorkspaceId": crawlRequest['SystemSettings']['AzureWorkspaceId'],
    "AzureAuthenticationId": crawlRequest['SystemSettings']['AzureAuthenticationId'],
    "LoggerName": "bot_puppeteer"
};
process.env['AZURE_STORAGE_ACCOUNT'] = crawlRequest['SystemSettings']['AzureStorageAccount'];
process.env['AZURE_STORAGE_ACCESS_KEY'] = crawlRequest['SystemSettings']['AzureStorageAccessKey'];
var authData = {
    "grant_type": "client_credentials",
    "client_id": "RDMServiceAccess",
    "client_secret": "61a380a6-4e3e-4bde-8e83-a9fdcbf38e86",
    "scope": "RDMServiceAccess"
}
const requestStatus = ['O', 'C', 'RF'];
var imageCounter = 1;
//to clear page controls.
module.exports = {
    clear: async function (page, selector) {
        const value = await page.$eval(
            selector,
            el => el.value || el.innerText || ""
        );
        await page.focus(selector);
        for (let i = 0; i < value.length; i++) {
            await page.keyboard.press("Backspace");
        }
    },
    // <summary>
    // Helper function to convert string value to boolean.
    // </summary>
    // <param name="strvalue">String value.</param>
    // <returns>Boolean</returns>
    str2bool: function (strvalue) {
        return (strvalue && typeof strvalue == 'string') ? (strvalue.toLowerCase() == 'true' || strvalue == '1') : (strvalue == true);
    },
    formatStartOrEndCrawlDate: function (datetime) {
        if (!datetime) {
            datetime = new Date();
        }
        var month = datetime.getMonth() + 1;
        month = month < 10 ? "0" + month : month;
        var date = datetime.getDate() < 10 ? "0" + datetime.getDate() : datetime.getDate();
        var hours = datetime.getHours() < 10 ? "0" + datetime.getHours() : datetime.getHours();
        var minutes = datetime.getMinutes() < 10 ? "0" + datetime.getMinutes() : datetime.getMinutes();
        var seconds = datetime.getSeconds() < 10 ? "0" + datetime.getSeconds() : datetime.getSeconds();
        let time = hours + ":" + minutes + ":" + seconds;
        var ampm = hours >= 12 ? 'pm' : 'am';
        hours = hours % 12;
        hours = hours ? hours : 12; // the hour '0' should be '12'
        var strTime = hours + ':' + minutes + ' ' + ampm;
        return month + "/" + date + "/" + datetime.getFullYear() + " " + strTime;
    },
    formatDateWithoutTime: function (datetime) {

        datetime = new Date(datetime);
        var month = datetime.getMonth() + 1;
        month = month < 10 ? "0" + month : month;
        var date = datetime.getDate() < 10 ? "0" + datetime.getDate() : datetime.getDate();
        var hours = datetime.getHours() < 10 ? "0" + datetime.getHours() : datetime.getHours();
        var minutes = datetime.getMinutes() < 10 ? "0" + datetime.getMinutes() : datetime.getMinutes();
        var seconds = datetime.getSeconds() < 10 ? "0" + datetime.getSeconds() : datetime.getSeconds();
        let time = hours + ":" + minutes + ":" + seconds;
        var ampm = hours >= 12 ? 'pm' : 'am';
        hours = hours % 12;
        hours = hours ? hours : 12; // the hour '0' should be '12'
        var strTime = hours + ':' + minutes + ' ' + ampm;
        return month + "/" + date + "/" + datetime.getFullYear();
    },
  
 // <summary>
    // To upload image to google service.
    // </summary>
    // <param name="searchBuffer">Page screen shot of page.</param>
    uploadToGCP: async function (logLevel, searchBuffer, fileName) {
        module.exports.createLogJson(logLevel.info, "Method name : uploadToGCP | Uploading image to GCP.");
        var formData = {
            file: {
                value: searchBuffer, // Upload the first file in the multi-part post
                options: {
                    filename: fileName
                }
            }
        };
        var options = {
            url: CacheFilePath,
            formData: formData,
            method: 'POST',
            headers: {
                'contenttype': 'multipart/form-data',
                'subscriber': customerId,
                'cache-control': 'no-cache'
            }
        };
        // Return new promise 
        return new Promise(function (resolve, reject) {
            // Do async job
            req.post(options, async function (err, resp, body) {

                if (err) {
                    module.exports.createLogJson(logLevel.error, "Error in upload :" + err);
                    reject(err);
                }
                else {
                    try {
                        if (JSON.parse(body).success) {
                            module.exports.createLogJson(logLevel.info, 'File ' + fileName + ' uploaded successfully.');
                            resolve(JSON.parse(body).publicUrl);
                        }
                    }
                    catch (error) {
                        module.exports.createLogJson(logLevel.error, "Error in upload :" + err);
                        resolve();
                    }
                }
            })
        })
    },

    uploadImage: async function (logLevel, searchBuffer, fileName) {
        var CacheFile = "";
        try {
            CacheFile = await module.exports.uploadToGCP(logLevel, searchBuffer, fileName);
            if (!CacheFile) {
                fileName = customerId + "/" + fileName;
                CacheFile = await module.exports.uploadToAzure(logLevel, searchBuffer, fileName);
                CacheFile = CacheFileAzurePath + "/" + fileName;
            }
        }
        catch (error) {
            fileName = customerId + "/" + fileName;
            CacheFile = await module.exports.uploadToAzure(logLevel, searchBuffer, fileName);
            CacheFile = CacheFileAzurePath + "/" + fileName;
        }
        return CacheFile;
    },

    // <summary>
    // To upload image to azure service.
    // </summary>
    // <param name="searchBuffer">Page screen shot of page.</param>
    uploadToAzure: async function (searchBuffer, filename) {
        module.exports.createLogJson({
            Level: logLevel.Info,
            Message: "Uploading image to azure"
        });
        var blobSvc = await azure.createBlobService();
        var containerName = module.exports.getAzureContainerName();
        //Create Container if does not exists
        await blobSvc.createContainerIfNotExists(containerName, function (err, result, response) {
            if (err) {
                module.exports.createLogJson({
                    Level: logLevel.Error,
                    Message: "Couldn't create container " + containerName
                });
            }
            else {
                if (result) {
                    module.exports.createLogJson({
                        Level: logLevel.Info,
                        Message: "Container '" + containerName + "' created."
                    });
                }
                else {
                    module.exports.createLogJson({
                        Level: logLevel.warn,
                        Message: "Container " + containerName + " already exists."
                    });
                }
            }
        });

        if (filePatternTouploadToAzure == "stream") {
            var bufferStream = new stream.PassThrough();
            bufferStream.end(searchBuffer);
            bufferStream.pipe(blobSvc.createWriteStreamToBlockBlob(
                containerName, filename
                , function (error, result, response) {
                    if (error) {
                        module.exports.createLogJson({
                            Level: logLevel.Error,
                            Message: "Couldn't upload file " + fileName + ". couldn't create container.",
                            Details: error.message
                        });
                    }
                    else {
                        module.exports.createLogJson({
                            Level: logLevel.Info,
                            Message: "File uploaded successfully."
                        });
                    }
                }));
        }
        else {
            //Read image/screenshot from file and upload to azure blob
            var fileName = "screenshots/" + searchBuffer;
            blobSvc.createBlockBlobFromLocalFile(
                containerName, fileName, fileName,
                function (error, result, response) {
                    if (error) {
                        module.exports.createLogJson({
                            Level: logLevel.Error,
                            Message: "Couldn't upload file " + fileName + ". Coud'nt create container",
                            Details: error.message
                        });
                    }
                    else {
                        module.exports.createLogJson({
                            Level: logLevel.Info,
                            Message: "File " + fileName + " uploaded successfully"
                        });
                    }
                });
        }
    },
    // <summary>
    // Get Azure Container
    // </summary>
    getAzureContainerName: function () {
        var azureContainer = crawlRequest['CacheFilePath'].split("/");
        return azureContainer[azureContainer.length - 1];
    },
    // <summary>
    // To record a log in JSON format
    // </summary>   
    // <param name="data">options = {Level : string, Message : string, Details : string }</param>
    createLogJson: function (options) {
        try {
            if (options == null || options == undefined || !(typeof options === 'object')) {
                new Error('1');
            }
            else if (options.Level == null || options.Level == undefined || !(typeof options.Level === 'string')) {
                new Error('2');
            }
            else if (options.Message == null || options.Message == undefined || !(typeof options.Message === 'string')) {
                new Error('3');
            }
            else {
                var logJson = {};
                if (options["Details"] == null) {
                    logJson = {
                        RequestDetailId: crawlRequest.MetaData.RowKey,
                        LogLevel: options.Level,
                        DateTimeStamp: module.exports.formatStartOrEndCrawlDate(),
                        Method: module.exports.createLogJson.caller != null ? module.exports.createLogJson.caller.name : "",
                        Message: options.Message
                    };
                }
                else {
                    logJson = {
                        RequestDetailId: crawlRequest.MetaData.RowKey,
                        LogLevel: options.Level,
                        DateTimeStamp: module.exports.formatStartOrEndCrawlDate(),
                        Method: module.exports.createLogJson.caller != null ? module.exports.createLogJson.caller.name : "",
                        Message: options.Message,
                        Details: options.Details
                    };
                }

                //If {this.createLogJson.caller.name} is blank then its called by one of the event handlers
                if (logJson.Method == '') {
                    logJson.Method = 'From Event Handler';
                }

                if (crawlRequest.BotInfo.DebugMode) {
                    if (options.Level == 'error') {
                        console.error(JSON.stringify(logJson));
                    }
                    else if (options.Level == 'warn') {
                        console.warn(JSON.stringify(logJson));
                    }
                    else if (options.Level == 'info') {
                        console.log(JSON.stringify(logJson));
                    }
                }

                logDetails.push({
                    "RequestDetailId": logJson.RequestDetailId,
                    "Message": logJson.Message,
                    "DateTimeStamp": logJson.DateTimeStamp,
                    "LogLevel": logJson.LogLevel
                });

            }
        }
        catch (Error) {
            throw new Error('Error while Logging Record.Error is ' + Error);
        }
    },
    // <summary>
    // To create logs.
    // </summary>
    createFinalLogJson: function (message) {
        if (debugMode) console.log(message);
    },
    postLogs: function (endpoints, code) {
        let clientId;
        var r = req({
            headers: {
                'Content-Type': 'application/json'
            },
            strictSSL: false,
            agentOptions: {
                rejectUnauthorized: false
            },
            uri: endpoints['RegistrationUrl'],
            body: JSON.stringify(data),
            method: 'POST'
        }, function (err, response, body) {
            if (!err) {
                module.exports.createLogJson({ Level: logLevel.Info, Message: "Status from registration url: " + response.statusCode });
                if (response.statusCode == 200) {
                    clientId = JSON.parse(body).clientId;
                    req({
                        headers: {
                            'Clientid': clientId,
                            'Content-Type': 'application/json'
                        },
                        strictSSL: false,
                        agentOptions: {
                            rejectUnauthorized: false
                        },
                        uri: endpoints['LogUrl'],
                        body: JSON.stringify(logDetails),
                        method: 'POST'
                    }, function (err, response, body) {
                        module.exports.createLogJson({ Level: logLevel.Info, Message: "Status from log url:  " + response.statusCode });
                        if (!err) {
                            module.exports.createLogJson({ Level: logLevel.Info, Message: "Logs Posted successfully,closing browser instance.." });
                            if (code == 1) {
                               // process.exit();
                            }
                        } else {
                            if (code == 1) {
                              //  process.exit();
                            }
                        }
                    });
                }
                else {
                   //process.exit();
                }
            }
        });
    },
    postRequestStatus: function (logLevel, url) {
        module.exports.createLogJson({
            Level: logLevel.Info,
            Message: "Method name : postRequestStatus | Posting Request Status."
        });
        req({
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            strictSSL: false,
            agentOptions: {
                rejectUnauthorized: false
            },
            uri: url,
            method: 'POST'
        }, function (err, response, body) {
            if (!err) {
                module.exports.createLogJson({
                    Level: logLevel.Info,
                    Message: "Method name : postRequestStatus | Posting request status Code. " + response.statusCode
                });
            }
        });
    },
    closureServiceRequest: async function (logLevel, apiEndpoints, pageData) {
        module.exports.createLogJson({
            Level: logLevel.Info,
            Message: "Method name : closureServiceRequest | Posting data to closure service. Data: " + JSON.stringify(pageData)
        });
        req({
            headers: {
                'Content-Type': 'application/json'
            },
            strictSSL: false,
            agentOptions: {
                rejectUnauthorized: false
            },
            uri: apiEndpoints.ClosureServiceUrl,
            body: JSON.stringify(pageData),
            method: 'POST'
        }, function (err, response, body) {
            if (!err) {
                module.exports.createLogJson({ Level: logLevel.Info, Message: "Data posted to closure service. Status code: " + response.statusCode });
            }
            else {
                module.exports.createLogJson({ Level: logLevel.Error, Message: "Error while posting to closure service. Error: " + err });
            }
        });
    },
    getAzureContainerName: function () {
        var azureContainer = crawlRequest['CacheFilePath'].split("/");
        return azureContainer[azureContainer.length - 1];
    },
    proxyHitCountRequest: function (logLevel, apiEndpoints, proxyHitCountData) {
        //to encode authorization data.
        let body = "";
        for (let key in authData) {
            if (body.length) {
                body += "&";
            }
            body += key + "=";
            body += encodeURIComponent(authData[key]);
        }
        let token;
        var r = req({
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            strictSSL: false,
            agentOptions: {
                rejectUnauthorized: false
            },
            uri: apiEndpoints.AuthorizationUrl,
            body: body,
            method: 'POST'
        }, function (err, response, body) {
            if (!err) {
                module.exports.createLogJson({
                    Level: logLevel.Info,
                    Message: "Status from authorization url. Status code: " + response.statusCode
                });
                if (response.statusCode == 200) {
                    token = JSON.parse(body).access_token;
                    req({
                        headers: {
                            'Authorization': 'bearer  ' + token,
                            'Content-Type': 'application/json'
                        },
                        strictSSL: false,
                        agentOptions: {
                            rejectUnauthorized: false
                        },
                        uri: apiEndpoints.ProxyHitCount,
                        body: JSON.stringify(proxyHitCountData),
                        method: 'POST'
                    }, function (err, response, body) {
                        if (!err) {
                            module.exports.createLogJson({
                                Level: logLevel.Info,
                                Message: "Data posted to proxy hit count api. Status code: " + response.statusCode
                            });
                        }
                        else {
                            module.exports.createLogJson({
                                Level: logLevel.Error,
                                Message: "Error while posting to closure service. Error : " + err
                            });
                        }
                    });
                }
            }
        });
    },
    empty: function (data) {
        if (typeof (data) == 'number' || typeof (data) == 'boolean') {
            return false;
        }
        if (typeof (data) == 'undefined' || data === null) {
            return true;
        }
        if (typeof (data.length) != 'undefined') {
            return data.trim().length == 0;
        }
        var count = 0;
        for (var i in data) {
            if (data.hasOwnProperty(i)) {
                count++;
            }
        }
        return count == 0;
    },
    getSelector: async function (page, htmltag) {
        var returnElementHandler = null;
        var elementCount = 0;
        if (("ById" in crawlRequest['BotInfo']['HtmlTags'][htmltag]) && !module.exports.empty(crawlRequest['BotInfo']['HtmlTags'][htmltag]["ById"])) {
            if (!crawlRequest['BotInfo']['HtmlTags'][htmltag]['isOptional']) {
                await page.waitForSelector(crawlRequest['BotInfo']['HtmlTags'][htmltag]["ById"]).catch((error) => {
                    return "error occured while waiting selector." + error;
                });
            }
            elementCount = await page.$$eval(crawlRequest['BotInfo']['HtmlTags'][htmltag]["ById"], el => el.length);
            if (elementCount > 0) {
                module.exports.createLogJson({
                    Level: logLevel.Info,
                    Message: "Selector " + htmltag + " found by using ById."
                });
                returnElementHandler = await page.$(crawlRequest['BotInfo']['HtmlTags'][htmltag]["ById"]);
            }
            else {
                module.exports.createLogJson({ Level: logLevel.Info, Message: "Selector " + htmltag + " not found by using ById." });
            }
        }
        if (("ByClass" in crawlRequest['BotInfo']['HtmlTags'][htmltag]) && !module.exports.empty(crawlRequest['BotInfo']['HtmlTags'][htmltag]["ByClass"]) && returnElementHandler == null) {
            elementCount = await page.$$eval(crawlRequest['BotInfo']['HtmlTags'][htmltag]["ByClass"], el => el.length);
            module.exports.createLogJson({ Level: logLevel.Info, Message: "Selector " + htmltag + " count is " + elementCount });
            if (elementCount > 0) {
                module.exports.createLogJson({ Level: logLevel.Info, Message: "Selector " + htmltag + " found by using ByClass." });
                returnElementHandler = await page.$(crawlRequest['BotInfo']['HtmlTags'][htmltag]["ByClass"]);
            }
            else {
                module.exports.createLogJson({ Level: logLevel.Info, Message: "Selector " + htmltag + " not found by using ByClass." });
            }
        }
        if (("ByXpath" in crawlRequest['BotInfo']['HtmlTags'][htmltag]) && !module.exports.empty(crawlRequest['BotInfo']['HtmlTags'][htmltag]["ByXpath"]) && returnElementHandler == null) {
            try {
                let xpathElement = await page.$x(crawlRequest['BotInfo']['HtmlTags'][htmltag]["ByXpath"], el => el.length);
                if (xpathElement.length > 0) {
                    module.exports.createLogJson({
                        Level: logLevel.Info,
                        Message: "Selector " + htmltag + " found by using ByXpath."
                    });
                    returnElementHandler = await page.$x(crawlRequest['BotInfo']['HtmlTags'][htmltag]["ByXpath"]);
                }
            }
            catch (error) {
                module.exports.createLogJson({
                    Level: logLevel.Info,
                    Message: "Selector " + htmltag + " not found by using ByXpath."
                });
            }
        }
        if (returnElementHandler == null && !crawlRequest['BotInfo']['HtmlTags'][htmltag]['isOptional']) {
            module.exports.createLogJson({ Level: logLevel.Error, Message: "Tried all selectors but no matching selector found for html tag " + htmltag });
            throw "Tried all selectors but no matching selector found for html tag " + htmltag;
        }
        else {
            return returnElementHandler;
        }
    },
    selectValue: async function (dataList, valueToSelect, valueToReplace, logMessage) {
        for (var data of dataList) {
            var pdata = await (await data.getProperty('innerText')).jsonValue();
            if (pdata != '' && pdata.trim().toLowerCase().indexOf(valueToReplace) > -1) {
                pdata = pdata.trim().replace(valueToReplace, '');
            }
            if (pdata.trim().indexOf(valueToSelect) > -1) {
                data.click();
                module.exports.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + logMessage });
                break;
            }
        }
    },
    getOptionValue: async function (dataList, valueToSelect, valueToReplace, logMessage) {
        let isOptionExists = false;
        for (var data of dataList) {
            var pdata = await (await data.getProperty('value')).jsonValue();
            if (pdata.toLowerCase() == valueToSelect.toLowerCase()) {
                module.exports.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + logMessage });
                isOptionExists = true;
                return await (await data.getProperty('innerText')).jsonValue()
            }
        }
        if (!isOptionExists) {
            throw "Problem in selecting option from dropdown.Value to select :" + valueToSelect;
        }
    },
    getSelectorValue: async function (page, htmltag) {
        if (("ById" in crawlRequest['BotInfo']['HtmlTags'][htmltag]) && !module.exports.empty(crawlRequest['BotInfo']['HtmlTags'][htmltag]["ById"])) {
            try {
                return Promise.resolve(await page.$eval(crawlRequest['BotInfo']['HtmlTags'][htmltag]["ById"], el => el.innerText));
            } catch (e) {
                module.exports.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "Selector " + htmltag + " failed to be fetched using ById" });
                console.log("Selector " + htmltag + " failed to be fetched using ById");
            }
        }
        if (("ByClass" in crawlRequest['BotInfo']['HtmlTags'][htmltag]) && !module.exports.empty(crawlRequest['BotInfo']['HtmlTags'][htmltag]["ByClass"])) {
            try {
                return Promise.resolve(await page.$eval(crawlRequest['BotInfo']['HtmlTags'][htmltag]["ByClass"], el => el.innerText));
            } catch (e) {
                module.exports.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "Selector " + htmltag + " failed to be fetched using ById" });
                console.log("Selector " + htmltag + " failed to be fetched using ByClass");
            }
        }
        if (("ByXpath" in crawlRequest['BotInfo']['HtmlTags'][htmltag]) && !module.exports.empty(crawlRequest['BotInfo']['HtmlTags'][htmltag]["ByXpath"])) {
            let xpathElement = await page.$x(crawlRequest['BotInfo']['HtmlTags'][htmltag]["ByXpath"]);
            var xpathElementValue = await page.evaluate(xpathElement => {
                return document.evaluate(xpathElement, page, null, XPathResult.ANY_TYPE, null).singleNodeValue.toString();
            })
            return xpathElementValue;
        }
    },
    getAllSelectorValue: async function (page, htmltag) {
        if (("ById" in crawlRequest['BotInfo']['HtmlTags'][htmltag]) && !module.exports.empty(crawlRequest['BotInfo']['HtmlTags'][htmltag]["ById"])) {
            try {
                return await page.$$eval(crawlRequest['BotInfo']['HtmlTags'][htmltag]["ById"], el => el.map(n => n.innerText));
            } catch (e) {
                console.log("Selector " + htmltag + " failed to be fetched using ById");
            }
        }
        if (("ByClass" in crawlRequest['BotInfo']['HtmlTags'][htmltag]) && !module.exports.empty(crawlRequest['BotInfo']['HtmlTags'][htmltag]["ByClass"])) {
            try {
                return await page.$$eval(crawlRequest['BotInfo']['HtmlTags'][htmltag]["ByClass"], el => el.map(n => n.innerText));
            } catch (e) {
                console.log("Selector " + htmltag + " failed to be fetched using ByClass");
            }
        }
        if (("ByXpath" in crawlRequest['BotInfo']['HtmlTags'][htmltag]) && !module.exports.empty(crawlRequest['BotInfo']['HtmlTags'][htmltag]["ByXpath"])) {
            let xpathElement = await page.$x(crawlRequest['BotInfo']['HtmlTags'][htmltag]["ByXpath"]);
            var xpathElementValue = await page.evaluate(xpathElement => {
                return document.evaluate(xpathElement, document, null, XPathResult.ANY_TYPE, null).singleNodeValue.toString();
            })
            return xpathElementValue;
        }
    },
    getAllSelectors: async function (element, htmltag) {
        if (("ById" in crawlRequest['BotInfo']['HtmlTags'][htmltag]) && !module.exports.empty(crawlRequest['BotInfo']['HtmlTags'][htmltag]["ById"])) {
            try {
                return await element.$$(crawlRequest['BotInfo']['HtmlTags'][htmltag]["ById"]);
            } catch (e) {
                console.log("Selector " + htmltag + " failed to be fetched using ById");
            }
        }
        if (("ByClass" in crawlRequest['BotInfo']['HtmlTags'][htmltag]) && !module.exports.empty(crawlRequest['BotInfo']['HtmlTags'][htmltag]["ByClass"])) {
            try {
                return await element.$$(crawlRequest['BotInfo']['HtmlTags'][htmltag]["ByClass"]);
            } catch (e) {
                console.log("Selector " + htmltag + " failed to be fetched using ByClass");
            }
        }
        if (("ByXpath" in crawlRequest['BotInfo']['HtmlTags'][htmltag]) && !module.exports.empty(crawlRequest['BotInfo']['HtmlTags'][htmltag]["ByXpath"])) {
            let xpathElement = await element.$x(crawlRequest['BotInfo']['HtmlTags'][htmltag]["ByXpath"]);
            var xpathElementValue = await element.evaluate(xpathElement => {
                return document.evaluate(xpathElement, document, null, XPathResult.ANY_TYPE, null).singleNodeValue;
            })
            return xpathElementValue;
        }
    },
    replaceNewLineCharacter: async function (value, indexToSelect) {
        var arrReturnValue = [];
        if (!!value && value.constructor === Array) {
            arrReturnValue = value.map(a => a.split(/\r?\n/)[indexToSelect].trim())
        }
        else {
            arrReturnValue = value.split(/\r?\n/)[indexToSelect].trim();
        }
        return arrReturnValue;
    },
    convertTime: async function (time) {
        // Check correct time format and split into components
        time = time.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)/) || [time];
        if (time.length > 1) { // If time format correct
            time = time.slice(1);  // Remove full string match value
            time[5] = +time[0] < 12 ? ' AM' : ' PM'; // Set AM/PM
            time[0] = +time[0] % 12 || 12; // Adjust hours
        }
        return time.join(''); // return adjusted time or original string
    },
    getReferenceOrCustomValues: async function () {
        module.exports.createLogJson({ Level: logLevel.Info, Message: "Checking whether max stops or requested stops are available or not." });
        var custom = crawlRequest['CrawlParams']['custom'];
        module.exports.createLogJson({ Level: logLevel.Info, Message: "Custom parameter value is  " + custom });
        var reference = crawlRequest['CrawlParams']['reference'];
        module.exports.createLogJson({ Level: logLevel.Info, Message: "Reference parameter value is  " + reference });
        var isNonStop = crawlRequest['CrawlParams']['flighttype'];
        module.exports.createLogJson({ Level: logLevel.Info, Message: "Flight type is " + crawlRequest['CrawlParams']['flighttype'] });
        var returnStops = {
            isRequestedStop: false,
            stopOvers: 0,
            availability: false,
            isDirectFlight: false
        }
        if (isNonStop.toLowerCase() == 'd') {
            return returnStops = {
                isRequestedStop: false,
                stopOvers: 0,
                availability: false,
                isDirectFlight: true
            }
        }
        var secondFilter = ((custom != undefined || custom != null) && custom.length > 0) ? true : false;
        if (!secondFilter) {
            secondFilter = ((reference != undefined || reference != null) && reference.length > 0) ? true : false;
        }
        var max_stop = 0;
        var req_stop = 0;
        if (custom != undefined && custom != null && custom.length > 0) {
            module.exports.createLogJson({ Level: logLevel.Info, Message: "Custom parameter values found." });
            let temp = custom.toLowerCase().split('|');
            for (var flag of temp) {
                if (flag.includes('max_stops')) {
                    max_stop = parseInt(flag.split(':')[1]);
                    returnStops = {
                        isRequestedStop: false,
                        stopOvers: max_stop,
                        availability: true,
                        isDirectFlight: false
                    }
                    module.exports.createLogJson({ Level: logLevel.Info, Message: "Custom parameter with max stop found and max stop is " + max_stop });
                } else if (flag.includes('req_stops')) {
                    req_stop = parseInt(flag.split(':')[1]);
                    returnStops = {
                        isRequestedStop: true,
                        stopOvers: req_stop,
                        availability: true,
                        isDirectFlight: false
                    }
                    module.exports.createLogJson({ Level: logLevel.Info, Message: "Custom parameter with req stop found and req stop is " + req_stop });
                }
            }
        }
        if (max_stop == 0 && req_stop == 0) {
            module.exports.createLogJson({ Level: logLevel.Info, Message: "Custom parameter with req stop or max stop not so trying to check reference parameter." });
            if (reference != undefined && reference != null && reference.length > 0) {
                let temp = reference.toLowerCase().split('|');
                for (var flag of temp) {
                    if (flag.includes('max_stops')) {
                        max_stop = parseInt(flag.split(':')[1]);
                        returnStops = {
                            isRequestedStop: true,
                            stopOvers: max_stop,
                            availability: true
                        }
                        module.exports.createLogJson({ Level: logLevel.Info, Message: "Reference parameter with max stop found and max stop is " + max_stop });
                    } else if (flag.includes('req_stops')) {
                        req_stop = parseInt(flag.split(':')[1]);
                        returnStops = {
                            isRequestedStop: true,
                            stopOvers: req_stop,
                            availability: true
                        }
                        module.exports.createLogJson({ Level: logLevel.Info, Message: "Reference parameter with req stop found and req stop is " + req_stop });
                    }
                }
            }
        }
        if (max_stop == 0 && req_stop == 0) {
            returnStops = {
                isRequestedStop: false,
                stopOvers: 0,
                availability: false,
                isDirectFlight: false
            }
            module.exports.createLogJson({ Level: logLevel.Info, Message: "Req stop or max stop not found." });
        }
        return returnStops;
    },
    isClassTypeAvailable: async function (classTypeMMapperObj, className, requestedClass) {
        let classTypes = classTypeMMapperObj.filter((ct) => ct.name.toLowerCase() == className && ct.type.toLowerCase() == requestedClass);
        return classTypes.length > 0 ? true : false;
    },
    guid: async function () {
        function s4() {
            return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
        }
        return new Promise((resolve, reject) => {
            resolve(s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4());
        });
    },
    takeScreenShot: async function (page, type, index) {
        try {
            module.exports.createLogJson({ Level: logLevel.Info, Message: "Taking screenshot for index " + index });
            var pathName = null;
            var validLevel = false;
            var websiteId = crawlRequest.BotInfo.WebsiteID;
            var requestId = crawlRequest.MetaData.RequestId;
            module.exports.createLogJson({ Level: logLevel.Info, Message: "Taking screenshot." });
            var screenBuffer = await page.screenshot({ fullPage: true, omitBackground: false });
            pathName = await module.exports.getImageName(type);
            module.exports.createLogJson({ Level: logLevel.Info, Message: "File name : " + pathName });
            var CacheFilePathUrl = crawlRequest['CacheFilePath'] + "/" + pathName;
            module.exports.createLogJson({ Level: logLevel.Info, Message: "Cachefile Path Url : " + CacheFilePathUrl });
           // await module.exports.uploadToAzure(screenBuffer, pathName);

            CacheFilePathUrl = await module.exports.uploadImage(screenBuffer, pathName);
            return Promise.resolve(CacheFilePathUrl);
        }
        catch (error) {
            module.exports.createLogJson({ Level: logLevel.Error, Message: "Some error occured while taking screenshot", Details: error.message });
            //throw error;
        }
    },


    uploadImage: async function (searchBuffer, fileName) {
        var CacheFile = "";
        try {

            CacheFile = await module.exports.uploadToGCP(searchBuffer, fileName);
            if (!CacheFile) {
                fileName = subscriberId + "/" + fileName;
                CacheFile = await module.exports.uploadToAzure(searchBuffer, fileName);
                CacheFile = crawlRequest['CacheFilePath'] + "/" + fileName;
                // CacheFile = CacheFileAzurePath + "/" + fileName;
            }
        }
        catch (error) {
            fileName = subscriberId + "/" + fileName;
            CacheFile = await module.exports.uploadToAzure(searchBuffer, fileName);
            CacheFile = crawlRequest['CacheFilePath'] + "/" + fileName;
            // CacheFile = CacheFileAzurePath + "/" + fileName;
        }
        return CacheFile;
    },
    // <summary>
    // To upload image to google service.
    // </summary>
    // <param name="searchBuffer">Page screen shot of page.</param>
    uploadToGCP: async function (searchBuffer, fileName) {

        fileName = fileName.split('/').join('_');
        module.exports.createLogJson({
            Level: 'info',
            Message: "Method name : uploadToGCP | Uploading image to GCP."
        });
        var formData = {
            file: {
                value: searchBuffer, // Upload the first file in the multi-part post
                options: {
                    filename: fileName
                }
            }
        };
        var options = {
            url: CacheFilePath,
            formData: formData,
            method: 'POST',
            headers: {
                'contenttype': 'multipart/form-data',
                'subscriber': subscriberId,
                'cache-control': 'no-cache'
            }
        };


        // Return new promise 
        return new Promise(function (resolve, reject) {
            // Do async job
            req.post(options, async function (err, resp, body) {

                if (err) {
                    module.exports.createLogJson({
                        Level: 'error',
                        Message: "Error in upload :" + err
                    });
                    reject(err);
                }
                else {
                    try {
                        if (JSON.parse(body).success) {
                            module.exports.createLogJson({
                                Level: 'info',
                                Message: "Method name : uploadToGCP | " + 'File ' + fileName + ' uploaded successfully.'
                            });
                            resolve(JSON.parse(body).publicUrl);
                        }
                    }
                    catch (error) {
                        module.exports.createLogJson({
                            Level: 'error',
                            Message: "Error in upload :" + err
                        });
                        resolve();
                    }
                }
            })
        })
    },


    getImageName: async function (type) {
        var imageName = null;
        if (type == 'O')
            imageName = String.format("{0}/{1}/{2}_{3}.png", crawlRequest.MetaData.SiteId, crawlRequest.MetaData.RowKey, crawlRequest['BotInfo']['BotName'], imageCounter++);
        else if (type == 'C')
            imageName = String.format("{0}/{1}/{2}.NotAvail.png", crawlRequest.MetaData.SiteId, crawlRequest.MetaData.RowKey, crawlRequest['BotInfo']['BotName']);
        else if (type == 'RF')
            imageName = String.format("{0}/{1}/{2}.NotParsed.png", crawlRequest.MetaData.SiteId, crawlRequest.MetaData.RowKey, crawlRequest['BotInfo']['BotName']);

        return imageName;
    },
    sendEmptyDataToClosure: async function (dataToPost, errorMessage, isFailed, avail = null, path) {
        try {
            module.exports.createLogJson({ Level: logLevel.Info, Message: "Preparing to sending empty data to closure service." });
            module.exports.createLogJson({ Level: logLevel.Info, Message: "Empty data parameters are 'errorMessage' : " + errorMessage + " 'isFailed' : " + isFailed + " 'avail' :" + avail });
            await module.exports.createEmptyData(dataToPost, errorMessage, isFailed, path, avail);
            module.exports.createLogJson({ Level: logLevel.Info, Message: "Empty data created.Final data to send to closure service : " + JSON.stringify(dataToPost) });
            await module.exports.closureServiceRequest(logLevel, crawlRequest['ApiEndpoints'], dataToPost);
           // console.log(JSON.stringify(dataToPost));
            module.exports.createLogJson({ Level: logLevel.Info, Message: "Data sent to closure service." });
            await module.exports.postLogs(crawlRequest['ApiEndpoints'], 1);
            module.exports.createLogJson({ Level: logLevel.Info, Message: "Log posted." });
        }
        catch (error) {
            module.exports.createLogJson({ Level: logLevel.Error, Message: "Error occurred while posting data." });
            //     throw error;
        }
    },
    createEmptyData: async function (dataToPost, errorMessage, isFailed, path, avail = null) {
        
        //dataToPost.Cars = [];
        dataToPost.crawlEndTime = module.exports.formatStartOrEndCrawlDate('');;
        // var data = {
        //     'path': path
        // }
        dataToPost.Path = path;
        var availability = (isFailed) ? requestStatus[2] : requestStatus[1];
        if (avail == null){
            dataToPost.Cars = [];
            dataToPost.availability = availability;
            dataToPost.RequestAvailability = availability;
        }else{
            dataToPost.availability = avail;
            dataToPost.RequestAvailability = avail;
            
        }
        dataToPost.errorDescription = errorMessage;
        dataToPost.isRequestFailed = isFailed;
        dataToPost.crawlEndTime = module.exports.formatStartOrEndCrawlDate("");
        dataToPost.parseStartTime = module.exports.formatStartOrEndCrawlDate("");
       // console.log("datatopost" + JSON.stringify(dataToPost));
    },
    writeLogFile: function () {
        var flag = true;
        var fileName = null;
        var fileContent = logDetails;
        fileName = "./logs/" + module.exports.getTimeStamp().toString() + "_log.json";
        fs.writeFileSync(fileName, JSON.stringify(fileContent));
        return flag;
    },
    getTimeStamp: function () {
        return new Date().getTime();
    },
    splitSting(stringToSplit, splitByCharacter) {
        let returnValue = [];
        if (stringToSplit != undefined || stringToSplit != "") {
            returnValue = stringToSplit.split(splitByCharacter);
        }
        return returnValue;
    },
    replaceMultipleCharacters(value, replaceCharacters) {
        var returnValue = value;
        if ((value != undefined || value != null || value != "") && (replaceCharacters != null || replaceCharacters != "")) {
            for (var c = 0; c <= replaceCharacters.length - 1; c++) {
                if (value.indexOf(replaceCharacters[c]) > -1) {
                    returnValue = value.replace(replaceCharacters[c], '');
                    value = returnValue.trim();
                }
            }
        }
        return returnValue;
    },
    formatCurrency(value) {
        if (value != undefined || value != null || value != "") {
            value = value.trim().replace(/[^0-9.]/g, "").trim();
        }
        return value;
    },
    timeFormate: async function (timeinfo) {
        var a = timeinfo.toLowerCase();
        if (a.indexOf(" pm") > -1 || a.indexOf(" am") > -1) {
            return Promise.resolve(timeinfo);
        }
        if (a.includes('am') || a.includes('pm')) {
            var b = " ";
            var position = a.indexOf("pm");
            if (position > 0) {
                var output = [a.slice(0, position), b, a.slice(position)].join('');
            }
            else {
                var position = a.indexOf("am");
                var output = [a.slice(0, position), b, a.slice(position)].join('');
            }
            return Promise.resolve(output);
        }
    }
};
