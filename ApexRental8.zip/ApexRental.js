// <summary>
// Global variable declaration.
// </summary>
const puppeteer = require('puppeteer');
var fs = require('fs');
const {performance} = require('perf_hooks');
//Read config file.
var crawlRequestFile = process.argv.slice(2)[0];
var utils = require("./utils.js");

var isPopupClosedOnce = false;
var captchaHelper = require('./captcha_helper-v2.js');
//Store crawl request parameters.
var crawlRequest = JSON.parse(fs.readFileSync(crawlRequestFile));

//console.log(crawlRequest['BotInfo']['CalendarScriptPath']);
var isProxyUsed = crawlRequest['BotInfo']['UseProxy'];

var requestId = crawlRequest['MetaData']['RequestId'];
var debugMode = crawlRequest['BotInfo']['DebugMode'];
let retryCount = crawlRequest['MetaData']['RetryCount'];
const logLevel = { "Info": "info", "Warn": "warn", "Error": "error" };
let azureContainer = crawlRequest['CacheFilePath'].split("/");
const strCommonMessage = "Bot name : Hertz | ";
var promotionAvailablility = crawlRequest["CrawlParams"]["PromotionCode"];
var crawlStartTime = new Date();
var pickUpLocation = crawlRequest["CrawlParams"]["WS_PickUpLocation"];
var dropOffLocation = crawlRequest["CrawlParams"]["WS_DropOffLocation"];
var _configuration = crawlRequest['BotInfo']['BaseUrl'];
let hitCount = 0;

var page = null;
var response = [];
var inBoundOutBoundData = {
	Cars: [],
	"crawlstarttime": crawlStartTime,
	"IsConversionRequired": crawlRequest['CrawlParams']['IsConversionRequired'],
	"RequestedCurrency": crawlRequest['CrawlParams']['CurrencyName'],
	"WebsiteId": crawlRequest['MetaData']['SiteId'],
	"WebsiteName": crawlRequest['BotInfo']['WebsiteName'],
	"BaseUrl": crawlRequest['BotInfo']['BaseUrl'],
	"RequestAvailability": "",
	"UserId": crawlRequest['MetaData']['UserId'],
	"ReportSegmentId": crawlRequest['MetaData']['ReportSegmentId'],
	"ReportType": crawlRequest['MetaData']['ReportType'],
	"ReportId": crawlRequest['MetaData']['ReportId'],
	"RowKey": crawlRequest['MetaData']['RowKey'],
	"PickUpDate": crawlRequest['CrawlParams']['PickUpDate'],
	"PickUpTime": crawlRequest['CrawlParams']['PickUpTime'],
	"pickUpLocation": crawlRequest['CrawlParams']['PickUpLocation'],
	"PG_PickUpLocationId": crawlRequest['CrawlParams']['PG_PickUpLocationId'],
	"DropoffDate": crawlRequest['CrawlParams']['DropOffDate'],
	"DropoffTime": crawlRequest['CrawlParams']['DropOffTime'],
	"DropoffLocation": crawlRequest['CrawlParams']['DropOffLocation'],
	"PG_DropOffLocationId": crawlRequest['CrawlParams']['PG_DropOffLocationId'],
	"Path": "",
	"CurrencyBatchId": crawlRequest['CrawlParams']['CurrencyBatchId'],
	"WS_PickUpLocation": null,
	"WS_DropOffLocation": null,
};


var proxyHitCount = 0;
//var proxy = null;
var requestStatus = 6;

proxy = crawlRequest['Proxies'][Math.floor(Math.random() * crawlRequest['Proxies'].length)];
const userAgent = crawlRequest.BotInfo['UserAgentList'][Math.floor(Math.random() * crawlRequest.BotInfo['UserAgentList'].length)];
const args = [
	"--disable-infobars",
	"--disable-dev-shm-usage",
	"--remote-debugging-port=122",
	//"--disk-cache-size-200000000",
	"--no-sandbox",
	//'--no-first-run',
	'--start-maximized',
	"--disable-background-networking",
	"--disable-setuid-sandbox",
	"--ignore-certifcate-errors",
	"--user-agent=Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36"
	//"--ignore-certifcate-errors-spki-list",
];
const options = {
	args,
	headless: true,
	ignoreHTTPSErrors: true,
	timeout: 60000
};

process.on("unhandledRejection", (reason, p) => {
	var index = 0;
	if(page && page != null){
		utils.takeScreenShot(page, 'RF', index).then(function (pagePath) {
			utils.sendEmptyDataToClosure(inBoundOutBoundData, reason.stack == undefined ? reason : reason.stack, true, 'RF', pagePath);
	});
	}else{
		var pagePath = "";
		utils.sendEmptyDataToClosure(inBoundOutBoundData, reason.stack == undefined ? reason : reason.stack, true, 'RF', pagePath);
	}
	setTimeout(() => {
		process.exit(1);
	}, 10000);
});


async function BrowserHeaderSettings(page) {
	

	//============================================start================
	await page.evaluateOnNewDocument(() => {
		function mockPluginsAndMimeTypes () {
			/* global MimeType MimeTypeArray PluginArray */
			// Disguise custom functions as being native
			const makeFnsNative = (fns = []) => {
			  const oldCall = Function.prototype.call
			  function call () {
				return oldCall.apply(this, arguments)
			  }
			  // eslint-disable-next-line
			  Function.prototype.call = call
	
			  const nativeToStringFunctionString = Error.toString().replace(
				/Error/g,
				'toString'
			  )
			  const oldToString = Function.prototype.toString
	
			  function functionToString () {
				for (const fn of fns) {
				  if (this === fn.ref) {
					return `function ${fn.name}() { [native code] }`
				  }
				}
	
				if (this === functionToString) {
				  return nativeToStringFunctionString
				}
				return oldCall.call(oldToString, this)
			  }
			  // eslint-disable-next-line
			  Function.prototype.toString = functionToString
			}
	
			const mockedFns = []
	
			const fakeData = {
			  mimeTypes: [
				{
				  type: 'application/pdf',
				  suffixes: 'pdf',
				  description: '',
				  __pluginName: 'Chrome PDF Viewer'
				},
				{
				  type: 'application/x-google-chrome-pdf',
				  suffixes: 'pdf',
				  description: 'Portable Document Format',
				  __pluginName: 'Chrome PDF Plugin'
				},
				{
				  type: 'application/x-nacl',
				  suffixes: '',
				  description: 'Native Client Executable',
				  enabledPlugin: Plugin,
				  __pluginName: 'Native Client'
				},
				{
				  type: 'application/x-pnacl',
				  suffixes: '',
				  description: 'Portable Native Client Executable',
				  __pluginName: 'Native Client'
				}
			  ],
			  plugins: [
				{
				  name: 'Chrome PDF Plugin',
				  filename: 'internal-pdf-viewer',
				  description: 'Portable Document Format'
				},
				{
				  name: 'Chrome PDF Viewer',
				  filename: 'mhjfbmdgcfjbbpaeojofohoefgiehjai',
				  description: ''
				},
				{
				  name: 'Native Client',
				  filename: 'internal-nacl-plugin',
				  description: ''
				}
			  ],
			  fns: {
				namedItem: instanceName => {
				  // Returns the Plugin/MimeType with the specified name.
				  const fn = function (name) {
					if (!arguments.length) {
					  throw new TypeError(
						`Failed to execute 'namedItem' on '${instanceName}': 1 argument required, but only 0 present.`
					  )
					}
					return this[name] || null
				  }
				  mockedFns.push({ ref: fn, name: 'namedItem' })
				  return fn
				},
				item: instanceName => {
				  // Returns the Plugin/MimeType at the specified index into the array.
				  const fn = function (index) {
					if (!arguments.length) {
					  throw new TypeError(
						`Failed to execute 'namedItem' on '${instanceName}': 1 argument required, but only 0 present.`
					  )
					}
					return this[index] || null
				  }
				  mockedFns.push({ ref: fn, name: 'item' })
				  return fn
				},
				refresh: instanceName => {
				  // Refreshes all plugins on the current page, optionally reloading documents.
				  const fn = function () {
					return undefined
				  }
				  mockedFns.push({ ref: fn, name: 'refresh' })
				  return fn
				}
			  }
			}
			// Poor mans _.pluck
			const getSubset = (keys, obj) =>
			  keys.reduce((a, c) => ({ ...a, [c]: obj[c] }), {})
	
			function generateMimeTypeArray () {
			  const arr = fakeData.mimeTypes
				.map(obj => getSubset(['type', 'suffixes', 'description'], obj))
				.map(obj => Object.setPrototypeOf(obj, MimeType.prototype))
			  arr.forEach(obj => {
				arr[obj.type] = obj
			  })
	
			  // Mock functions
			  arr.namedItem = fakeData.fns.namedItem('MimeTypeArray')
			  arr.item = fakeData.fns.item('MimeTypeArray')
	
			  return Object.setPrototypeOf(arr, MimeTypeArray.prototype)
			}
	
			const mimeTypeArray = generateMimeTypeArray()
			Object.defineProperty(navigator, 'mimeTypes', {
			  get: () => mimeTypeArray
			})
	
			function generatePluginArray () {
			  const arr = fakeData.plugins
				.map(obj => getSubset(['name', 'filename', 'description'], obj))
				.map(obj => {
				  const mimes = fakeData.mimeTypes.filter(
					m => m.__pluginName === obj.name
				  )
				  // Add mimetypes
				  mimes.forEach((mime, index) => {
					navigator.mimeTypes[mime.type].enabledPlugin = obj
					obj[mime.type] = navigator.mimeTypes[mime.type]
					obj[index] = navigator.mimeTypes[mime.type]
				  })
				  obj.length = mimes.length
				  return obj
				})
				.map(obj => {
				  // Mock functions
				  obj.namedItem = fakeData.fns.namedItem('Plugin')
				  obj.item = fakeData.fns.item('Plugin')
				  return obj
				})
				.map(obj => Object.setPrototypeOf(obj, Plugin.prototype))
			  arr.forEach(obj => {
				arr[obj.name] = obj
			  })
	
			  // Mock functions
			  arr.namedItem = fakeData.fns.namedItem('PluginArray')
			  arr.item = fakeData.fns.item('PluginArray')
			  arr.refresh = fakeData.fns.refresh('PluginArray')
	
			  return Object.setPrototypeOf(arr, PluginArray.prototype)
			}
	
			const pluginArray = generatePluginArray()
			Object.defineProperty(navigator, 'plugins', {
			  get: () => pluginArray
			})
	
			// Make mockedFns toString() representation resemble a native function
			makeFnsNative(mockedFns)
		  }
		  try {
			const isPluginArray = navigator.plugins instanceof PluginArray
			const hasPlugins = isPluginArray && navigator.plugins.length > 0
			if (isPluginArray && hasPlugins) {
			  return // nothing to do here
			}
			mockPluginsAndMimeTypes()
		  } catch (err) {}
		  delete window.navigator.__proto__.webdriver
			window.navigator.__defineGetter__('maxTouchPoints', function() {
				return 0;
			})
		});
	 
	//========================================end=======
	
	
	// Pass the Webdriver Test.
	await page.evaluateOnNewDocument(() => {
		Object.defineProperty(navigator, 'webdriver', {
			get: () => false,
		});
		Object.defineProperty(navigator, 'userAgent', {
			get: () => "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36",
		});
		// We can mock this in as much depth as we need for the test.
		window.navigator.chrome = {
			runtime: {}
		};
		Object.defineProperty(navigator, 'plugins', {
			get: () => [1, 2, 3, 4, 5],
		});
		// Overwrite the `languages` property to use a custom getter.
		Object.defineProperty(navigator, 'languages', {
			get: () => ['en-US', 'en'],
		});
		Object.defineProperty(navigator, 'platform', {
			get: () => "Linux x86_64",
		});
		const originalQuery = window.navigator.permissions.query;
		window.navigator.permissions.__proto__.query = parameters =>
			parameters.name === 'notifications'
				? Promise.resolve({ state: Notification.permission })
				: originalQuery(parameters);

	});
};
var page;
async function run() {
	//console.log("Proxy " + JSON.stringify(options))
	//Set UserAgent
	//console.log("userAgent " + userAgent);
	console.log("starting");
	var address = crawlRequest['BotInfo']['BaseUrl'];
	utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "Launching browser." });
	const browser = await puppeteer.launch(options);
	utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "Browser launched." });
	page = await browser.newPage();
	await BrowserHeaderSettings(page);
	// if (isProxyUsed) {
	// 	args.push("--proxy-server=" + proxy.IPAddress);
	// 	//console.log(args);
	// }

	var pages = await browser.pages();

	//Close the browser page
	if (pages.length > 1) {
		await pages[0].close();
	}
	await page.setJavaScriptEnabled(true);
	//await page.setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3359.181 Safari/537.36");
	//await page.setUserAgent(userAgents[Math.floor(Math.random() * userAgents.length)]);
	await page.setUserAgent(userAgent);

	await page.setViewport({
		width: 1550,
		height: 750
	});
	/*await page.setRequestInterception(true);
	page.on('request', request => {
	  if (request.resourceType() === 'image') {
			 request.abort();
		 } else{
		   request.continue();
		 }
   });*/
	await page.setDefaultNavigationTimeout(60000);

	//utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "Calender Page Injected" });

	await page.exposeFunction('getSelectorString', utils.getSelectorString);
	await page.exposeFunction('createLogJson', utils.createLogJson);
	await page.exposeFunction('selectValue', utils.selectValue);

	//authenticate Proxy 
	if (isProxyUsed) {
		page.authenticate({
			username: proxy.UserId,
			password: proxy.Password
		});
	}

	utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "Setting page view port." });
	await page.setViewport({
		width: 1050,
		height: 750
	});

	await utils.postRequestStatus(logLevel, crawlRequest['ApiEndpoints']['StateServiceUrl'] + "/" + crawlRequest['MetaData']['RowKey'] + "/" + requestStatus);

	//var crawlStartTime = new Date();
	crawlStartTime = crawlStartTime.toUTCString();
	utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "crawlStartTime" + crawlStartTime });

	console.log("go to url");
	await page.goto(address, {
		waitUntil: ['networkidle0', 'domcontentloaded', 'load'],
		timeout: 150000
	});

	
	try {
		//waiting for country selector
		//this is done to check the selector before capcha and to increase the time of execution
		//waiting for few seconds stop the navigation on site aswell while checing the browser settings
		var countrySelector = crawlRequest["BotInfo"]["HtmlTags"]["countrySelector"]["ById"];
		await page.waitForSelector(countrySelector, { timeout: 30000 });
	} catch (err) {
	}
	
	console.log("after 1 try catch");


//captcha check
var captcha = await page.evaluate(() => document.querySelector('#challenge-form'));
console.log(captcha);
if(captcha){
	console.log("inside captcha");
//captcha 
console.log("ReCaptcha V2")
if ((await captchaHelper.verifyCaptchaPage(page))) {
//	let newTabNavigationStartTime = performance.now();
//	console.log("processStart " + newTabNavigationStartTime);
	await captchaHelper.solveCaptchaPage(page, address);
	console.log("after captcha bla bla");
	while (!captchaHelper.details.isSolved) {
		await page.waitFor(20000);
		console.log("waiting for captcha");
	//	newTabIntermediateEndTime = performance.now();
	//	console.log("processEnd " + newTabIntermediateEndTime);
		//if ((newTabIntermediateEndTime - newTabNavigationStartTime) > 120000) {
		//	var imageName = "detailsScreen-" + _configuration.requestDetailId() + "-" + Math.floor((Math.random() * 1000) + 1).toString() + ".png";
		//	let img = await helper.captureAndUploadScreenshot(page, _configuration, imageName);
		//	console.log("Captcha Image", _configuration);
			captchaHelper.details.isSolved = true;
	//	}
	}
	isPageLoaded = await page.evaluate(() => document.readyState);
	while (isPageLoaded != "complete") {
		isPageLoaded = await page.evaluate(() => document.readyState);
		await page.waitFor(4000);
	}
}

};

await page.waitFor(10000); 

//If cacptcha not resolved
var captcha = await page.evaluate(() => document.querySelector('#challenge-form'));
	if (captcha) {
		
		let pagePath = await utils.takeScreenShot(page, 'RF');
		return await utils.sendEmptyDataToClosure(inBoundOutBoundData, "Captch Not Resolved", false, 'RF', pagePath);
	}


	var success = await fillSearchData(page);

	await page
	if (!success) {
		return;
	}

	
	//close case for red text popup
	var closePopUp = await utils.getAllSelectors(page, "closepopUp");
	if (closePopUp.length > 0) {
	
		const texthandle = await page.evaluateHandle((el) => el.innerText, closePopUp[0]);
		var closeText = await texthandle.jsonValue();

	utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + closeText });
	let pagePath = await utils.takeScreenShot(page, 'C');
	var closeData = await closeCaseResponse(page, pagePath);
	closeData.Price[0].PriceDesc = closeText;
	//closeData.ErrorDesc = closeText;
	inBoundOutBoundData.Cars.push(closeData);
	//console.log(JSON.stringify(inBoundOutBoundData));
	return await utils.sendEmptyDataToClosure(inBoundOutBoundData, closeText, false, 'C', pagePath);
}

//close case on nextx page
var closeNextPage = await utils.getAllSelectors(page, "closenextPage");
if (closeNextPage.length > 0) {

	const texthandle = await page.evaluateHandle((el) => el.innerText, closeNextPage[0]);
	var closeText = await texthandle.jsonValue();

utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + closeText });
let pagePath = await utils.takeScreenShot(page, 'C');
var closeData = await closeCaseResponse(page, pagePath);
closeData.Price[0].PriceDesc = closeText;
inBoundOutBoundData.Cars.push(closeData);
//console.log(JSON.stringify(inBoundOutBoundData));
return await utils.sendEmptyDataToClosure(inBoundOutBoundData, closeText, false, 'C', pagePath);
}



	//============================End to get class types=========================
	//============================To get CarList div===============
	utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "Selecting complete car div." });
	let carList = await utils.getAllSelectors(page, 'CarListSelector');
	utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "Complete car div information collected." });
	//============================End to get CarList divs===========
	//============================To store each car rows=========================
	utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "Collecting car rows infomation." });
	let carRows = await utils.getAllSelectors(carList[0], 'carRowSelector');
	utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "Collecting car rows information collected." });
	//============================End to store each car rows======================
	//=======================No car record found=============================
	if (carRows.length == 0) {
		utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "Car rows not found." });
		let pagePath = await utils.takeScreenShot(page, 'C');
		var closeData = await closeCaseResponse(page, pagePath);
		inBoundOutBoundData.Cars.push(closeData);
		//console.log(JSON.stringify(inBoundOutBoundData));
		return await utils.sendEmptyDataToClosure(inBoundOutBoundData, "Car rows not found.", false, 'C', pagePath);
	}
	// if (returnTrip && inboundFlightRows == null) {
	// 	utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "Inbound flight row(s) not found." });
	// 	let pagePath = await utils.takeScreenShot(page, 'C');
	// 	return await utils.sendEmptyDataToClosure(inBoundOutBoundData, "Either outbound or inbound flight row(s) not found.", false, 'C', pagePath);
	// }
	//=======================End no outbound record found=========================
	await page.waitFor(5000);
	await getPageData(carRows, page);
	utils.createLogJson({ Level: logLevel.Info, Message: "Crawlling done." });
	console.log(JSON.stringify(inBoundOutBoundData));
	await utils.closureServiceRequest(logLevel, crawlRequest['ApiEndpoints'], inBoundOutBoundData);
	await utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "Data posted.Posting log started." });
	await utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "Posting data to proxy hit count service." });
	var proxyHitDetails = {
		"productId": crawlRequest['BotInfo']['productId'],
		"proxyMasterID": proxy['ProxyMasterId'],
		"websiteID": crawlRequest['BotInfo']['WebsiteId'],
		"websiteName": crawlRequest['BotInfo']['WebsiteName'],
		"costGroupiD": proxy['CostGroupId'],
		"proxyOptionGroupID": proxy['ProxyOptionGroupId'],
		"hitCount": proxyHitCount,
		"isActive": proxy['IsActive'],
		"remark": proxy['Remark'],
		"proxyHitID": 0,
	}
	await utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "Proxy hit data details are :" + JSON.stringify(proxyHitDetails) });
	await utils.proxyHitCountRequest(logLevel, crawlRequest['ApiEndpoints'], proxyHitDetails);
	await utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "Data posted to proxy hit count service." });
	await utils.postLogs(crawlRequest['ApiEndpoints'], 1);
}


async function popUp(page) {

	if (!isPopupClosedOnce) {
		var popUp = await utils.getAllSelectors(page, "popUp")
		if (popUp.length > 0) {
			await popUp[0].click();
			//console.log("popup Clicked");
			isPopupClosedOnce = true;
		}

		return;
	}
}

async function fillSearchData(page) {
	utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "Filling search data." });
	try {

		try {
			//waiting for country selector
			//this is done to check the selector before capcha and to increase the time of execution
			//waiting for few seconds stop the navigation on site aswell while checing the browser settings
			var countrySelector = crawlRequest["BotInfo"]["HtmlTags"]["countrySelector"]["ById"];
			await page.waitForSelector(countrySelector, { timeout: 30000 });
		} catch (err) {
		}

		
	

		//selecting the country 
		var countryCode = crawlRequest['CrawlParams']['WS_PickUpCountryCode'];
		await page.select(countrySelector, countryCode);

		await page.waitFor(3000);

		//pickup location
		var pickupLocatorSelector = crawlRequest["BotInfo"]["HtmlTags"]["pickupLocatorSelector"]["ById"];
		await page.select(pickupLocatorSelector, pickUpLocation);


		await page.waitFor(4000);

		//dropoff Location
		var dropOffLocatorSelector = crawlRequest["BotInfo"]["HtmlTags"]["dropOffLocatorSelector"]["ById"];
		if (pickUpLocation != dropOffLocation) {
			await page.select(dropOffLocatorSelector, dropOffLocation);
		}



		await page.waitFor(2000);


		//pick up Calender click open
		var pickUpcalenderClick = await utils.getAllSelectors(page, 'calenderClickButton');
		await pickUpcalenderClick[0].click();


		await page.waitFor(4000);


		await injectCalendar(page);

		await page.waitFor(4000);

		//find date and click

		await page.evaluate(async (crawlRequest, logLevel, strCommonMessage) => {
			var pickUpDate = await findGivenDateControl(crawlRequest["CrawlParams"]['PickUpDate']);
			await pickUpDate.click();

			//repeative code for selecting the date when date of 2 months above from current is given
			var pickUpDate = await findGivenDateControl(crawlRequest["CrawlParams"]['PickUpDate']);
			await pickUpDate.click();
		}, crawlRequest, logLevel, strCommonMessage);


		await page.waitFor(3000);

		//repeative code for selecting the date when date of 2 months above from current is given
		// await page.evaluate(async (crawlRequest, logLevel, strCommonMessage) => {
		// 	var pickUpDate = await findGivenDateControl(crawlRequest["CrawlParams"]['PickUpDate']);
		// 	await pickUpDate.click();
		// }, crawlRequest, logLevel, strCommonMessage);


		await page.waitFor(5000);



		//dropoff Date 
		//Calender click open
		var dropOffcalenderClick = await utils.getAllSelectors(page, 'DropOffcalenderClickButton');
		await dropOffcalenderClick[0].click();


		await page.waitFor(5000);
		//find date and click

		await page.evaluate(async (crawlRequest, logLevel, strCommonMessage) => {
			var DropOffDate = await findGivenDateControl(crawlRequest["CrawlParams"]['DropOffDate']);
			await DropOffDate.click();
		}, crawlRequest, logLevel, strCommonMessage);


		await page.waitFor(3000);



		await page.waitFor(2000);

		//Pick up Time
		var pickUpTimeSelector = crawlRequest["BotInfo"]["HtmlTags"]["pickUpTimeSelector"]["ById"];
		var pickUpTime = (crawlRequest["CrawlParams"]["PickUpTime"]).slice(0, 5);

		await page.select(pickUpTimeSelector, pickUpTime);
		utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "pickup time clicked" });


		await page.waitFor(3000);


		//Drop Off time
		var dropOffTimeSelector = crawlRequest["BotInfo"]["HtmlTags"]["dropOffTimeSelector"]["ById"];
		var dropOffTime = (crawlRequest["CrawlParams"]["DropOffTime"]).slice(0, 5);

		await page.select(dropOffTimeSelector, dropOffTime);
		utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "dropoff time clicked" });


		await page.waitFor(3000);


		//Search
		var searchButton = await utils.getAllSelectors(page, "searchButtonClick");
		await searchButton[0].click();

		await page.waitFor(3000);
		//====================================================================

		
		// In few cases search button got clicked, but navigation does not happens, so clicking again
		var searchButtonAgain = await utils.getAllSelectors(page, "searchButtonAgain");
		if(searchButtonAgain.length > 0 ){
			
				await searchButtonAgain[0].click();
	
		}

		utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "submitButton clicked" });

		var listingPageSelector = crawlRequest["BotInfo"]["HtmlTags"]["CarListSelector"]["ById"];

		try {
			// await page.waitForNavigation({
			// 	waitUntil: ['networkidle0', 'domcontentloaded', 'load'],
			// 	timeout: 150000
			// });
			
				await page.waitForSelector(listingPageSelector, { timeout: 60000 });
				console.log("wait is over");
		}
		catch (err) {
		}

		utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "Page navigated." });
		return true;
	}
	catch (error) {
		utils.createLogJson({ Level: logLevel.Error, Message: strCommonMessage + "Error occurred while filling search data." + error });
		throw "Error occurred while filling search data." + error
	}
}



async function getPageData(carRows, page) {
	utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "Crawling page data started." });

	var index = 0;
	let imagePath = await utils.takeScreenShot(page, 'O', index);

	utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "Looping outbount flight started." });

	for (var car of carRows) {
		let carData = await getCarDetail(car, imagePath, page);
		utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "Outbound flight details collected.Outbound details are" + inBoundOutBoundData.Cars });
		if (carData == 'blank') {
			continue;
		} else {
			inBoundOutBoundData.Cars.push(carData);
		}

	}
}


async function getCarDetail(carRows, imagePath, page) {
	utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "Price details crawling started." });
	try {

		if (inBoundOutBoundData["WS_PickUpLocation"] == null) {
			//WS_pickupLocation
			var mainDiv = await utils.getAllSelectors(page, "ws_loactionDiv");
			for (var ws = 0; ws < mainDiv.length; ws++) {

				const texthandle = await page.evaluateHandle((el) => el.innerText, mainDiv[ws]);
				var cellText = await texthandle.jsonValue();
				cellText = cellText.split('\n');
				if (cellText[0].includes("Pick Up")) {
					var wsPickUpLocation = cellText[2];
					inBoundOutBoundData["WS_PickUpLocation"] = wsPickUpLocation;
				}
				if (cellText[0].includes("Drop Off")) {
					//WS_DropOffLocation
					var wsDropOffLocation = cellText[2];
					inBoundOutBoundData["WS_DropOffLocation"] = wsDropOffLocation;
				}

			}
		}
		



		//price div for both daily and total 
		var pricelist = [];
		var priceDivCount = await utils.getAllSelectors(carRows, "priceDivCountList");
		var PriceDivSoldOut = await utils.getAllSelectors(carRows, "PriceSoldOut");
		if (priceDivCount.length > 0) {

			//total price
			var totalpriceCount = await utils.getAllSelectors(priceDivCount[0], "priceCountList");

			const texthandle = await page.evaluateHandle((el) => el.innerText, totalpriceCount[0]);
			var cellText = await texthandle.jsonValue();
			//var priceCurrency = await utils.getSelectorValue(carRows, "Price");
			var priceCurrency = cellText.trim();
			var price = priceCurrency.split(':');
			priced = price[1].trim();
			price = priced.match('[0-9\\s\\.,]+');
			var currency = priced.replace(/\d+|^\s+|\s+$/g, '');

			if (currency != null) {

				if (currency.includes('.')) {
					currency = currency.replace(/\./g, '');
					if (currency.includes(',')) {
						currency = currency.replace(/,/g, '');
					}
				}

				//currency conversion

				if (currency == "NZ$") {
					currency = "NZD";
				} else if (currency == "AU$") {
					currency = "AUD";
				} else {
					currency = null;
				}
			}

			//daily rates 
			var dailyRate = await utils.getAllSelectors(carRows, 'dailyRateList');
			var dailyPrice = null;
			if (dailyRate.length > 0) {
				const texthandle = await page.evaluateHandle((el) => el.innerText, dailyRate[0]);
				var cellText = await texthandle.jsonValue();
				var dailypriceCurrency = cellText.trim();
				dailyPrice = dailypriceCurrency.match('[0-9\\s\\.,]+');
			}


			pricelist.push({
				"PriceAvailability": "O",
				"PriceDesc": "Success",
				"Currency": currency,
				"RateCode": null,
				"Mainratetype": null,
				"PromotionString": null,
				"RateBeforePromotion": null,
				"FuelCharges": {
					"amount": null,
					"isIncluded": null
				},
				"DropFee": {
					"amount": null,
					"isIncluded": null
				},
				"PassThrough": null,
				"ExtraDay": null,
				"HourCharge": null,
				"DepositAmount": null,
				"BalanceAmount": null,
				"Exclusive": {
					"amount": null
				},
				"Inclusive": {
					"amount": price[0],
					"ratetype": null
				},
				"Base": {
					"dailyRate": dailyPrice[0],
					"weekendRate": null,
					"weeklyRate": null,
					"monthlyRate": null
				},
				"Tax": {
					"description": null,
					"Currency": null,
					"amount": null,
					"isIncluded": null
				},
				"ExtraMileage": {
					"description": null,
					"amount": null
				}

			})


		}else if (PriceDivSoldOut.length > 0){


			pricelist.push({
				"PriceAvailability": "C",
				"PriceDesc": "Success",
				"Currency": null,
				"RateCode": null,
				"Mainratetype": null,
				"PromotionString": null,
				"RateBeforePromotion": null,
				"FuelCharges": {
					"amount": null,
					"isIncluded": null
				},
				"DropFee": {
					"amount": null,
					"isIncluded": null
				},
				"PassThrough": null,
				"ExtraDay": null,
				"HourCharge": null,
				"DepositAmount": null,
				"BalanceAmount": null,
				"Exclusive": {
					"amount": null
				},
				"Inclusive": {
					"amount": null,
					"ratetype": null
				},
				"Base": {
					"dailyRate": null,
					"weekendRate": null,
					"weeklyRate": null,
					"monthlyRate": null
				},
				"Tax": {
					"description": null,
					"Currency": null,
					"amount": null,
					"isIncluded": null
				},
				"ExtraMileage": {
					"description": null,
					"amount": null
				}

			});

		}



		//============Category========== 
		utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "Category Started" });

		var category = await utils.getSelectorValue(carRows, 'category');
		category = category.trim();

		var carName = await utils.getSelectorValue(carRows, 'carNameValue');
		carName = carName.trim();

		utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "Category Ended" });
		//============Category==========





		//===========All type===========
		var rating = null;
		var guaranteed = null;
		var year = null;
		var transmission = null;
		var engine = null;
		var fuel = null;
		var adult = null;
		var luggage = null;
		var doors = null;
		var mainRateType = null;
		var airConditioner = null;

		var expandedColumn = await utils.getAllSelectors(carRows, 'expandedColumNCount');
		if (expandedColumn.length > 0) {
			if (expandedColumn.length == 3) {

				//this id to get the length of the divs we need to get the value from
				var divLength = await utils.getAllSelectors(expandedColumn[2], 'divCount');
				for (var l = 0; l < divLength.length; l++) {


					//this is to check the length of images in particular div
					var imageCheck = await utils.getAllSelectors(divLength[l], 'imageValue');
					if (imageCheck.length > 0) {
						const innerTexthandle = await page.evaluateHandle((el) => el.innerText, divLength[l]);
						var innerCellText = await innerTexthandle.jsonValue();
						var innerCellTextValue = innerCellText.split('\n');

						//this is the length of items in particluar div on the basis of image attribute.
						for (var p = 0; p < imageCheck.length; p++) {

							const textHandle = await page.evaluateHandle((el, attr) => el.getAttribute(attr), imageCheck[p], "alt");
							var cellText = await textHandle.jsonValue();

							//Safety Rating
							if (cellText.includes("ancap")) {

								if (innerCellTextValue.length > 2) {
									rating = innerCellTextValue[p + 1];
									if (rating != "") {
										rating = rating.trim();
									} else {
										rating = null;
									}
								} else {
									//first value of split is empty thats why p+1 
									rating = innerCellTextValue[p];
									if (rating != "") {
										rating = rating.trim();
									} else {
										rating = null;
									}

								}

							}

							//gaurentee model
							if (cellText.includes("guaranteed")) {


								if (innerCellTextValue.length > 2) {
									guaranteed = innerCellTextValue[p + 1];
									if (guaranteed != "") {
										guaranteed = guaranteed.trim();
									} else {
										guaranteed = null;
									}
								} else {
									//first value of split is empty thats why p+1 
									guaranteed = innerCellTextValue[p];
									if (guaranteed != "") {
										guaranteed = guaranteed.trim();
									} else {
										guaranteed = null;
									}

								}

							}

							//year 
							if (cellText.includes("year")) {

								if (innerCellTextValue.length > 2) {
									year = innerCellTextValue[p + 1];
									if (year != "") {
										year = year.trim();
									} else {
										year = null;
									}
								} else {
									//first value of split is empty thats why p+1 
									year = innerCellTextValue[p];
									if (year != "") {
										year = year.trim();
									} else {
										year = null;
									}

								}
							}

							//transmission
							if (cellText.includes("trans")) {

								if (innerCellTextValue.length > 2) {
									transmission = innerCellTextValue[p + 1];
									if (transmission != "") {
										transmission = transmission.trim();
									} else {
										transmission = null;
									}
								} else {
									//first value of split is empty thats why p+1 
									transmission = innerCellTextValue[p];
									if (transmission != "") {
										transmission = transmission.trim();
									} else {
										transmission = null;
									}

								}
							}

							//engine
							if (cellText.includes("engine")) {

								if (innerCellTextValue.length > 2) {
									engine = innerCellTextValue[p + 1];
									if (engine != "") {
										engine = engine.trim();
									} else {
										engine = null;
									}
								} else {
									//first value of split is empty thats why p+1 
									engine = innerCellTextValue[p];
									if (engine != "") {
										engine = engine.trim();
									} else {
										engine = null;
									}

								}
							}


							//fuel
							if (cellText.includes("fuel")) {

								if (innerCellTextValue.length > 2) {
									fuel = innerCellTextValue[p + 1];
									if (fuel != "") {
										fuel = fuel.trim();
									} else {
										fuel = null;
									}
								} else {
									//first value of split is empty thats why p+1 
									fuel = innerCellTextValue[p];
									if (fuel != "") {
										fuel = fuel.trim();
									} else {
										fuel = null;
									}

								}
							}

							//adult
							if (cellText.includes("adult")) {

								if (innerCellTextValue.length > 2) {
									adult = innerCellTextValue[p + 1];
									if (adult != "") {
										adult = adult.trim();
										adult = parseInt(adult);
									} else {
										adult = null;
									}
								} else {
									//first value of split is empty thats why p+1 
									adult = innerCellTextValue[p];
									if (adult != "") {
										adult = adult.trim();
										adult = parseInt(adult);
										//add parseint for count value
									} else {
										adult = null;
									}

								}
							}


							//luggage-large
							if (cellText.includes("luggage-large")) {

								if (innerCellTextValue.length > 2) {
									luggage = innerCellTextValue[p + 1];
									if (luggage != "") {
										luggage = luggage.trim();
									} else {
										luggage = null;
									}
								} else {
									//first value of split is empty thats why p+1 
									luggage = innerCellTextValue[p];
									if (luggage != "") {
										luggage = luggage.trim();
									} else {
										luggage = null;
									}

								}
							}
						}
					} else {


						const innerTexthandle = await page.evaluateHandle((el) => el.innerText, divLength[l]);
						var innerCellText = await innerTexthandle.jsonValue();
						//var innerCellTextValue = innerCellText.split('\n');
						//==============mainratetype information============
						mainRateType = innerCellText;
						if (mainRateType.includes("Features")) {
							mainRateType = innerCellText.trim();
							mainRateType = mainRateType.replace('Features', '');
						}


						if (rating != null) {
							mainRateType = mainRateType + ', ' + rating;
						}
						if (guaranteed != null) {
							mainRateType = mainRateType + ', ' + guaranteed;
						}
						if (year != null) {
							mainRateType = mainRateType + ', ' + year;
						}
						if (engine != null && engine != "") {
							mainRateType = mainRateType + ', ' + engine;
						}

						mainRateType = mainRateType.trim();
						pricelist[0].Mainratetype = mainRateType;

						//===============Air Conditioned========
						if (mainRateType.includes("Air Conditioning")) {
							airConditioner = "Air Conditioning";
						}

						//================doors information=================
						doors = mainRateType.split(',');
						doors = doors[0];
						if (doors.includes("Door")) {
							doors = parseInt(doors);
						}


					}



				}
			}




		}

		//=====================================================



		//==================metadata=================
		var metaDataObj = {
			"Mileage": {
				"distance": null,
				"unitOfMeasure": null
			},
			"Doors": doors,
			"DriveType": null,
			"TransmissionType": transmission,
			"FuelType": fuel,
			"Luggage": luggage,
			"AirConditioner": airConditioner,
			"Category": category,
			"SippCode": null,
			"Name": carName,
			"Code": null
		}
		//===========================================

		//====================vendor=================
		var vendorObj = {
			"Code": null,
			"Name": null
		}
		//===========================================




		//====================seating========================
		var seatingCapacityObj = {
			"Adult": adult,
			"Child": null
		}

		//====================insurance======================
		var insuranceList = []

		insuranceList.push({
			"TheftProtection": {
				"description": null,
				"isIncluded": null,
				"currency": null,
				"price": null
			},
			"ThirdPartyCover": {
				"description": null,
				"isIncluded": null,
				"currency": null,
				"price": null
			},
			"LossDamageWaiver": {
				"description": null,
				"isIncluded": null,
				"currency": null,
				"price": null
			},
			"PersonalAccident": {
				"description": null,
				"isIncluded": null,
				"currency": null,
				"price": null
			}
		});

		//===================================================each itenary data==============================================
		if (priceDivCount.length > 0) {
			var data = {
				"Availability": "O",
				"LOK_Description": null,
				"Inclusions": null,
				"MetaData": metaDataObj,
				"Vendor": vendorObj,
				"Price": pricelist,
				"SeatingCapacity": seatingCapacityObj,
				"Insurances": insuranceList,
				"Extra1": null,
				"Extra2": null,
				"Extra3": null,
				"Extra4": null,
				"Extra5": null,
				"ServerResponseTime": null,
				"ProxyIp": null,
				"Path": imagePath,
				"ErrorCode": null,
				"ErrorDesc": null,
				"Depth": 1,
				"Shop": 1,
				"Hit": 0
			};
			return data;
		} else {
			var data = {
				"Availability": "C",
				"LOK_Description": null,
				"Inclusions": null,
				"MetaData": metaDataObj,
				"Vendor": vendorObj,
				"Price": pricelist,
				"SeatingCapacity": seatingCapacityObj,
				"Insurances": insuranceList,
				"Extra1": null,
				"Extra2": null,
				"Extra3": null,
				"Extra4": null,
				"Extra5": null,
				"ServerResponseTime": null,
				"ProxyIp": null,
				"Path": imagePath,
				"ErrorCode": null,
				"ErrorDesc": null,
				"Depth": 1,
				"Shop": 1,
				"Hit": 0
			};
			return data;

		}
	}
	catch (error) {
		utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "Error occurred while crawling flight details." + error });
		throw "Error occurred while crawling car details." + error;
	}
}

async function closeCaseResponse(page, imagePath) {

	var data = {
		"Availability": "C",
		"LOK_Description": null,
		"Inclusions": null,
		"MetaData": {
			"Mileage": {
				"distance": null,
				"unitOfMeasure": null
			},
			"Doors": null,
			"DriveType": null,
			"TransmissionType": null,
			"FuelType": null,
			"Luggage": null,
			"AirConditioner": null,
			"Category": null,
			"SippCode": null,
			"Name": null,
			"Code": null
		},
		"Vendor": {
			"Code": null,
			"Name": null
		},
		"Price": [
			{
				"PriceAvailability": "C",
				"PriceDesc": null,
				"Currency": null,
				"RateCode": null,
				"Mainratetype": null,
				"PromotionString": null,
				"RateBeforePromotion": null,
				"FuelCharges": {
					"amount": null,
					"isIncluded": null
				},
				"DropFee": {
					"amount": null,
					"isIncluded": null
				},
				"PassThrough": null,
				"ExtraDay": null,
				"HourCharge": null,
				"DepositAmount": null,
				"BalanceAmount": null,
				"Exclusive": {
					"amount": null
				},
				"Inclusive": {
					"amount": null,
					"ratetype": null
				},
				"Base": {
					"dailyRate": null,
					"weekendRate": null,
					"weeklyRate": null,
					"monthlyRate": null
				},
				"Tax": {
					"description": null,
					"Currency": null,
					"amount": null,
					"isIncluded": null
				},
				"ExtraMileage": {
					"description": null,
					"amount": null
				}
			}
		],
		"SeatingCapacity": {
			"Adult": null,
			"Child": null
		},
		"Insurances": [
			{
				"TheftProtection": {
					"description": null,
					"isIncluded": null,
					"currency": null,
					"price": null
				},
				"ThirdPartyCover": {
					"description": null,
					"isIncluded": null,
					"currency": null,
					"price": null
				},
				"LossDamageWaiver": {
					"description": null,
					"isIncluded": null,
					"currency": null,
					"price": null
				},
				"PersonalAccident": {
					"description": null,
					"isIncluded": null,
					"currency": null,
					"price": null
				}
			}
		],
		"Extra1": null,
		"Extra2": null,
		"Extra3": null,
		"Extra4": null,
		"Extra5": null,
		"ServerResponseTime": null,
		"ProxyIp": null,
		"Path": imagePath,
		"ErrorCode": "AVL01",
		"ErrorDesc": null,
		"Depth": 1,
		"Shop": 1,
		"Hit": 0
	}

	return data;
}

//Method : inject calendar.
// commented by me
async function injectCalendar(page) {
	utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "Injecting calendar script." });
	await page.addScriptTag({
		path: './' + crawlRequest['BotInfo']['CalendarScriptPath']
	});
	//await page.evaluateOnNewDocument(fs.readFileSync('./' + crawlRequest['BotInfo']['CalendarScriptPath'], 'utf8'));
	utils.createLogJson({ Level: logLevel.Info, Message: strCommonMessage + "Calendar script injected." });
}


// <summary>
// To run bot steps.
// </summary>
run().then(() => {
	setTimeout(() => {
		//console.log(strCommonMessage + "Waited for stipulated time and closing the thread.");
		process.exit();
	}, 1 * 60 * 1000);
});

//String prototype helper method for formatting
//STRING FORMAT helper
if (!String.format) {
	String.format = function (format) {
		var args = Array.prototype.slice.call(arguments, 1);
		return format.replace(/{(\d+)}/g, function (match, number) {
			return typeof args[number] != 'undefined' ?
				args[number] :
				match;
		});
	};
};



