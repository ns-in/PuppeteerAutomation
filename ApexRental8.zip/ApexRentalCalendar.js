/// find all the div having the datepicker using $( "div[class*='hasDatepicker']" )
/// then find the one which is currently shown as class style will be show:block
/// then look for the From datepicker calendar which will have it in it's name  as $("div[class*='hasDatepicker']")[0].className
/// then get to the table child node which is housing the calendar dates
/// then put the table html in variable and run a queryselector for intended date and perform click
/// NOTE: This has to be repeated for the retrun date calendar all, after moving focus to the return input box.

var monthsLongNameArray = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];
var monthsShortNameArray = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];

console.log("calendar file log");

 function findGivenDateControl(configDateValue) {
    console.log("findGivenDateControl called");

    //get the specified date from the request
    var givenDate = new Date(configDateValue);
    //debug
    console.log("Date to search: " + givenDate);

    var lookupMonthDataControl = traverseAndGetCalendarControl(configDateValue);
    //debug
    if (lookupMonthDataControl == null) {
        console.log('unable to find');
    }
    else {
        var currentDates = lookupMonthDataControl.querySelectorAll('tbody tr td');
        console.log('currentdate :' + currentDates);
        console.log(' givenDate.getDate() :' + givenDate.getDate());
        var selectedDateControl;
        for (var i = 0, len = currentDates.length; i < len; i++) {


            if (currentDates[i].innerText == givenDate.getDate()) {

                selectedDateControl = currentDates[i];
                console.log('selectedDateControl' + selectedDateControl);
                //selectedDateControl.click();
                break;
            }
            // var anchor = currentDates[i].querySelector('');
            //
            // if (anchor != null) {
            //     if (anchor.innerText == givenDate.getDate()) {
            //         selectedDateControl = currentDates[i];
            //         console.log('selectedDateControl' + selectedDateControl.outerHTML);
            //         break;
            //     }
            // }
        }
    }
    //Return the selected Date control back for clicking
    //selectedDateControl
    return selectedDateControl;
}

//private helper method
 function traverseAndGetCalendarControl(configDateValue) {
    var lookupMonthDataControl = null;
    var loopingCounter = 0;
    while (true) {
        loopingCounter++;
        //get the specified date from the request
        var givenDate = new Date(configDateValue),
            locale = "en-us",
            longMonthName = givenDate.toLocaleString(locale, {
                month: "long"
            }).split(" ")[0],
            shortMonthName = givenDate.toLocaleString(locale, {
                month: "short"
            }).split(" ")[0].substring(0, 3);

        var monthIndex = givenDate.getMonth();
        console.log("Month Index :" + monthIndex);
        var givenMonthLongNameIndex = monthsLongNameArray.indexOf(longMonthName.trim().toLowerCase());
        var givenMontShorthNameIndex = monthsShortNameArray.indexOf(shortMonthName.trim().toLowerCase());

        var givenMonthLongNameIndex = monthIndex;
        var givenMontShorthNameIndex = monthIndex;

        longMonthName = monthsLongNameArray[monthIndex];
        console.log("Long Month Name :" + longMonthName);
        shortMonthName = monthsShortNameArray[monthIndex];
        console.log("Short Month Name :" + shortMonthName);
        if (longMonthName == "" || shortMonthName == "") {
            console.log("Invalid Month Name.");
            retrun;
        }
        //once the date input box is clicked, it shows the calendar popup, from here we have to get the active calendar months, as at a time only two calendar months are shown
        //we use the css style of visibility to get the current calendar html block
        //  var allDatePickers =  document.getElementsByClassName("js-overlay-container overlay--container  calendar-selector-no-instructions");    //$("div[id*='ui-datepicker-div']");
        //  var allDatePickers =  document.getElementsByClassName("calendar-selector js-calendar-selector");
        // console.log("All dataPickers : "+allDatePickers);

        //
        // var activeFromCalendarID;
        // for (var i = 0; i < allDatePickers.length; i++) {
        //     if (allDatePickers[i].style.cssText.includes("aria-hidden='true'"))
        //
        //   {
        //         activeFromCalendarID = allDatePickers[i].id;
        //     }
        // }
        // console.log("Activate From Calender Id : "+activeFromCalendarID);
        ///When the calendar is opened, it shows two months, viz. the current and the next.
        ///So using the given date, we need to traverse to the correct month and then choose the date given.
        console.log('before fromcaledarHtmlcontrol')

        //Mian DIV for both Calender
        var fromCalendarHtmlControls = document.getElementsByClassName('ui-datepicker')[0];
        console.log('fromCalendarHtmlControls is :' + fromCalendarHtmlControls);
        

        //Get the current month
        var currentTableMonthDataControls = fromCalendarHtmlControls.getElementsByClassName('ui-datepicker-group ui-datepicker-group-first')[0];
        console.log('currentTableMonthDataControls is :' + currentTableMonthDataControls);

        //var currentMonthNameControls = currentTableMonthDataControls.previousSibling;    // currentTableMonthDataControls.previousSibling;

        var currentMonth = currentTableMonthDataControls.querySelectorAll('.ui-datepicker-month')[0].innerText; //currentMonthNameControls.querySelector('span[class*="month"]').innerText;
        currentMonth = currentMonth.trim();
        console.log(currentMonth);

        var currentMonthLongNameIndex = monthsLongNameArray.indexOf(currentMonth.trim().toLowerCase());

        var currentMonthShortNameIndex = monthsShortNameArray.indexOf(currentMonth.substring(0, 3).toLowerCase());
        //Get the year
        var currentYear = currentTableMonthDataControls.querySelectorAll('.ui-datepicker-year')[0].innerText;
        currentYear = currentYear.trim();
        console.log(currentYear);




        //Get the Prev Month control to traverse the calendar months --> this is very important as the phantom web driver has a cache page, so if the previous
        //request was in future, and the current request is present, then we have to move to the current month using the previous page control
        var prevPageControl = document.getElementsByClassName('ui-icon ui-icon-circle-triangle-w')[0];
        //  var prevPageControl = currentTableMonthDataControls.querySelector('div.calendar-1.js-calendar-1 > a');
        console.log('prevPageControl :' + prevPageControl);

        //Get the next month
        var nextMonthTableDataControls = fromCalendarHtmlControls.getElementsByClassName('ui-datepicker-group ui-datepicker-group-last')[0];
        console.log('nextMonthTableDataControls : ' + nextMonthTableDataControls);


        //  var nextMonthsNameControls = nextMonthTableDataControls.previousSibling;
        var nextMonth = nextMonthTableDataControls.querySelectorAll('.ui-datepicker-month')[0].innerText;
        nextMonth = nextMonth.trim();
        console.log(nextMonth);

        var nextMonthLongNameIndex = monthsLongNameArray.indexOf(nextMonth.trim().toLowerCase());
        var nextShortLongNameIndex = monthsShortNameArray.indexOf(nextMonth.substring(0, 3).toLowerCase());

        //Get the year
        var nextMonthsYear = nextMonthTableDataControls.querySelectorAll('.ui-datepicker-year')[0].innerText;
        nextMonthsYear = nextMonthsYear.trim();
        console.log(nextMonthsYear);
        //Get the Next Months control to traverse the calendar months
        var nextPageControl = document.getElementsByClassName('ui-icon ui-icon-circle-triangle-e')[0];
        //  var nextPageControl = document.getElementsByClassName('next js-next');


        console.log(nextPageControl);

        //debug
        console.log("current month long name given Index:" + currentMonthLongNameIndex + " current month short name Index:" + currentMonthShortNameIndex);
        console.log("next month long name given Index:" + nextMonthLongNameIndex + " next month short name Index:" + nextShortLongNameIndex);
        console.log("current month:" + currentMonth.trim().toLowerCase() + "  next month:" + nextMonth.trim().toLowerCase() + " long given month:" + longMonthName.trim().toLowerCase() + " short given month:" + shortMonthName.trim().toLowerCase());
      
        
        if ((currentMonthLongNameIndex > givenMonthLongNameIndex || currentMonthShortNameIndex > givenMontShorthNameIndex) && currentYear >= givenDate.getFullYear()) {
            //debug
            //console.log("need to go back in the calendar");
            if (prevPageControl != null) {
                prevPageControl.click();
            }
            if (loopingCounter == 12) {
                break;
            }
        }
        else {
            if ((currentMonth.trim().toLowerCase() == longMonthName.trim().toLowerCase() || currentMonth.trim().toLowerCase() == shortMonthName.trim().toLowerCase()) && currentYear == givenDate.getFullYear()) {
                //debug
                //console.log("current month:" + currentMonth);
                lookupMonthDataControl = currentTableMonthDataControls;
                break;
            }
            else if ((currentMonthLongNameIndex < givenMonthLongNameIndex || currentMonthShortNameIndex < givenMontShorthNameIndex) && currentYear == givenDate.getFullYear()) {
                //move to the next two months, in total we are going 6 months in future
                //don't want to loop more than 3 times.. as that's an invalid date duration
                //debug
                //console.log("looping to next calendar: " + loopingCounter);
                if (nextPageControl != null) {
                    nextPageControl.click();
                }
                if (loopingCounter == 12) {
                    break;
                }
            }
            else if (currentYear < givenDate.getFullYear()) {
                //move to the next two months, in total we are going 6 months in future
                //don't want to loop more than 3 times.. as that's an invalid date duration
                //debug
                //console.log("looping to next calendar: " + loopingCounter);
                if (nextPageControl != null) {
                    nextPageControl.click();
                }
                if (loopingCounter == 12) {
                    break;
                }
            }
        }


        //===========================================OLD logic==========================================
      
        if (currentMonthLongNameIndex > givenMonthLongNameIndex || currentMonthShortNameIndex > givenMontShorthNameIndex) {
            //debug
            console.log("need to go back in the calendar3");

            prevPageControl.click();
            if (loopingCounter == 12) {
                break;
            }
        }
        else {
            if (currentMonth.trim().toLowerCase() == longMonthName.trim().toLowerCase() || currentMonth.trim().toLowerCase() == shortMonthName.trim().toLowerCase()) {
                //debug

                console.log("current month:" + currentMonth);
                lookupMonthDataControl = currentTableMonthDataControls;
                break;
            }
            else if (nextMonth.trim().toLowerCase() == longMonthName.trim().toLowerCase() || nextMonth.trim().toLowerCase() == shortMonthName.trim().toLowerCase()) {
                //debug
                console.log("next month:" + nextMonth);

                //  console.log("nextMonthTableDataControls is " + nextMonthTableDataControls.innerHTML);
                lookupMonthDataControl = nextMonthTableDataControls;

                break;
            }
            else if (lookupMonthDataControl == null) {
                //move to the next two months, in total we are going 6 months in future
                //don't want to loop more than 3 times.. as that's an invalid date duration
                //debug
                console.log("looping to next calendar: " + loopingCounter);

                nextPageControl.click();
                if (loopingCounter == 12) {
                    break;
                }
            }
        }
        //====================================================================

    }
    console.log("lookupMonthDataControl is " + lookupMonthDataControl);
    console.log("Exit");
    return lookupMonthDataControl;
}
