var enums = require('./Enums.js');
var helper = require('./helper.js');
var botError = require('./BotError.js');




async function setInputs(browserPage, page, configuration, monitoring, response) {
  console.log("set input");
  /* Get the Selctor of input type From Json and looping*/ 
  let inputClickTags = page.tagsList().filter(tag => tag.action() == enums.tagTypeEnums.get("input").value);
  if (inputClickTags.length > 0) {
    for (var inputClickTag of inputClickTags) {

      let inputClickElement = await inputClickTag.element(browserPage, monitoring);
      await browserPage.evaluate(el => {
        el.click();
      }, inputClickElement);
      await setSourceAndDestination(browserPage, page, configuration, monitoring, response, 1, inputClickTag);
    }
  }
  else {
    await setSourceAndDestination(browserPage, page, configuration, monitoring, response, 2);
  }
}

async function setCalendar(browserPage, page, configuration, monitoring) {
  let calendarTags = page.tagsList().filter(tag => tag.action() == enums.tagTypeEnums.get("calendar").value);
  let calendarCloseTag = page.tagsList().filter(tag => tag.action() == enums.tagTypeEnums.get("click").value && tag.selectorType() == "calendarClose");
  await browserPage.waitFor(2000);
  for (var inputTag of calendarTags) {
    //Tab is for entering the value of date
    if (inputTag.selectorPattern() == enums.calendarSelectorPatternEnum.get("tab").value) {
      if ((inputTag.selectorType() == "fromCalendar")) {
        await browserPage.keyboard.press('Tab');
        await browserPage.waitFor(2000);
        let toElement = await inputTag.element(browserPage, monitoring);
        await browserPage.evaluate((toElement) => {
          toElement.removeAttribute('readOnly');
        }, toElement);
        let valueToClear = await (await toElement.getProperty('value')).jsonValue();
        for (let i = 0; i < valueToClear.length; i++) {
          await browserPage.keyboard.press("Backspace");
        }
        await browserPage.waitFor(1000);
        let outboundDate = helper.formatDate(configuration.parameters().startDate(), 'dd/mm/yyyy');
        await toElement.type(outboundDate, { delay: 100 });
      }
      else if ((inputTag.selectorType() == "toCalendar") && (configuration.parameters().isRoundtrip())) {
        await browserPage.waitFor(1000);
        await browserPage.keyboard.press('Tab');
        await browserPage.waitFor(1000);
        let toElement = await inputTag.element(browserPage, monitoring);
        await browserPage.evaluate((toElement) => {
          toElement.removeAttribute('readOnly');
        }, toElement);
        let valueToClear = await (await toElement.getProperty('value')).jsonValue();
        for (let i = 0; i < valueToClear.length; i++) {
          await browserPage.keyboard.press("Backspace");
        }
        await browserPage.waitFor(1000);
        let outboundDate = helper.formatDate(configuration.parameters().endDate(), 'dd/mm/yyyy');
        await toElement.type(outboundDate, { delay: 100 });
      }
    }
    //One-way and return to be selected in one open
    else if (inputTag.selectorPattern() == enums.calendarSelectorPatternEnum.get("OneClick").value) {
      let dateElement = await inputTag.element(browserPage, monitoring);
      await dateElement.click({ delay: 500 });
      if (configuration.parameters()._startDate.toString() && !configuration.parameters().isRoundtrip()) {
        let closedDate = await browserPage.evaluate(async (startdate) => {
          var departure_date_control = await findGivenDateControl(startdate);
          console.log(departure_date_control);
          if (departure_date_control == "closed") {
            return "closed";
          } else {
            departure_date_control.click({ delay: 500 });
          }
        }, date, configuration.parameters()._startDate.toString());
        if (closedDate == "closed") {
          throw new botError.ClosedCase("Site does not allow to search on request date");
        }
      } else if (configuration.parameters()._startDate.toString() && configuration.parameters()._endDate.toString() && configuration.parameters().isRoundtrip()) {
        let closedDate = await browserPage.evaluate(async (startDate, endDate) => {
          var departure_date_control = await findGivenDateControl(startDate, endDate);
          console.log(departure_date_control);
          if (departure_date_control == "closed") {
            return "closed";
          } else {
            departure_date_control.click({ delay: 500 });
          }
        }, configuration.parameters()._startDate.toString(), configuration.parameters()._endDate.toString());
        if (closedDate == "closed") {
          throw new botError.ClosedCase("Site does not allow to search on request date");
        }
      } else {
        throw new botError.ClosedCase("Enter the Date");
      }
      await browserPage.waitFor(2000);
    }
    else {
      //single calender opening
      if (inputTag.selectorType() == "fromCalendar") {
        //added time for calender input
        await calendarClick(browserPage, page, monitoring, inputTag, configuration.parameters()._pickUpDate.toString(),configuration.parameters()._pickUpTime.toString().slice(0,5));
      } else if ((inputTag.selectorType() == "toCalendar") && (configuration.parameters().isRoundtrip())) {
        await calendarClick(browserPage, page, monitoring, inputTag, configuration.parameters()._dropOffDate.toString());
      }
      if (calendarCloseTag.length > 0) {
        let calendarCloseElement = await calendarCloseTag[0].element(browserPage, monitoring);
        await browserPage.evaluate(el => {
          el.click();
        }, calendarCloseElement);
      }
    }
  }
}

async function calendarClick(browserPage, page, monitoring, inputTag, date, time) {
  let dateElement = await inputTag.element(browserPage, monitoring);
  if (inputTag.selectorPattern() == enums.calendarSelectorPatternEnum.get("standard").value) {
    await dateElement.click({ delay: 500 });
    let closedDate = await browserPage.evaluate(async (date,time) => {
      var departure_date_control = await findGivenDateControl(date,time);
      console.log(departure_date_control);
      if (departure_date_control == "closed") {
        return "closed";
      } else {
        departure_date_control.click({ delay: 500 });
      }
    }, date, time);
    if (closedDate == "closed") {
      throw new botError.ClosedCase("Site does not allow to search on request date");
    }
    await browserPage.waitFor(2000);
  }
  else if (inputTag.selectorPattern() == enums.calendarSelectorPatternEnum.get("evaluate").value) {
    await browserPage.evaluate(el => {
      function triggerMouseEvent(node, eventType) {
        var clickEvent = document.createEvent('MouseEvents');
        clickEvent.initEvent(eventType, true, true);
        node.dispatchEvent(clickEvent);
      }
      triggerMouseEvent(el, 'focus')
      el.click();
    }, dateElement);
    await browserPage.waitFor(500);

    let closedDate = await browserPage.evaluate(async (date, departureDateControl, type) => {
      var departure_date_control = await findGivenDateControl(date, type);
      console.log(departure_date_control);
      if (departure_date_control == "closed") {
        return "closed";
      } else {
        departure_date_control.click({ delay: 500 });
      }
    }, date, dateElement, inputTag.selectorType());
    if (closedDate == "closed") {
      throw new botError.ClosedCase("Site does not allow to search on request date");
    }

    await browserPage.waitFor(2000);
  }

}

async function setAdults(browserPage, page, configuration, monitoring) {
  var inputTag = page.tagsList().filter(tag => (tag.action() == enums.tagTypeEnums.get("click").value) && (tag.selectorType() == "adults"));
  console.log(inputTag.length);
  if (inputTag.length == 0) return;
  inputTag = inputTag[0];
  if (inputTag) {
    if (inputTag.pattern() == enums.patternTypeEnums.get("click").value) {
      let adultElement = await inputTag.element(browserPage, monitoring);
      await browserPage.evaluate((element, value) => {
        function selectAdults(element, value) {
          for (i = 0; i < element.options.length; i++) {
            if (parseInt(element.options[i].text) == value) {
              element.options[i].selected = true;
              return;
            }
          }
          return;
        }
        selectAdults(element, value);
      }, adultElement, configuration.parameters().SeatingCapacity())
      await browserPage.waitFor(2000);
    }
    else if (inputTag.pattern() == enums.patternTypeEnums.get("add").value) {
      let passengerElement = await inputTag.element(browserPage, monitoring);
      await passengerElement.click();
      await browserPage.waitFor(1000);
      let adultElement = null;
      if (page.tagsList().filter(tag => (tag.action() == enums.tagTypeEnums.get("select").value) && (tag.selectorType() == "adults")).length > 0) {
        let adultTag = page.tagsList().filter(tag => (tag.action() == enums.tagTypeEnums.get("select").value) && (tag.selectorType() == "adults"))[0];
        adultElement = await adultTag.element(browserPage, monitoring);
      }
      let addTag = page.tagsList().filter(tag => (tag.action() == enums.tagTypeEnums.get("click").value) && (tag.selectorType() == "adultsAdd"))[0];
      let addElement = await addTag.element(browserPage, monitoring);
      let adultValue = configuration.parameters().SeatingCapacity();
      console.log(adultValue);
      for (var i = 1; i < adultValue; i++) {
        await addElement.click();
        console.log("click called");
        await browserPage.waitFor(500);
      }
      let closeTag = page.tagsList().filter(tag => (tag.action() == enums.tagTypeEnums.get("click").value) && (tag.selectorType() == "closeAdults"))[0];
      if (closeTag) {
        let closeElement = await closeTag.element(browserPage, monitoring);
        await closeElement.click();
      }
      await browserPage.waitFor(500);
    }
    else if (inputTag.pattern() == enums.patternTypeEnums.get("listSearch").value) {
      let adultElement = await inputTag.element(browserPage, monitoring);
      await adultElement.click();
      let adultsDivClickTag = page.tagsList().filter(tag => (tag.action() == enums.tagTypeEnums.get("click").value) && (tag.selectorType() == "adultsDivClick"))[0];
      if (adultsDivClickTag) {
        let adultsDivClickElement = await adultsDivClickTag.element(browserPage, monitoring);
        await adultsDivClickElement.click();
        await browserPage.waitFor(500);
      }
      var adultsListTag = page.tagsList().filter(tag => (tag.action() == enums.tagTypeEnums.get("dropdown").value) && (tag.selectorType() == "adults"));
      if (adultsListTag.length == 0) return;
      let adultListElement = await adultsListTag[0].element(browserPage, monitoring);
      let passengersList = await adultListElement.$$('li');
      await browserPage.evaluate((element, value) => {
        function selectAdults(elements, value) {
          for (i = 0; i < elements.length; i++) {
            console.log(parseInt(elements[i].innerText));
            if (parseInt(elements[i].innerText) == value) {
              function triggerMouseEvent(node, eventType) {
                var clickEvent = document.createEvent('MouseEvents');
                clickEvent.initEvent(eventType, true, true);
                node.dispatchEvent(clickEvent);
              }

              triggerMouseEvent(elements[i], 'mousedown');
              elements[i].click();
              return;
            }
          }
          return;
        }

        selectAdults(element.querySelectorAll('li'), value);
      }, adultListElement, configuration.parameters().SeatingCapacity())
      await browserPage.waitFor(2000);
    }
  }
}

async function setSourceAndDestination(browserPage, page, configuration, monitoring, response, type, inputClickTag = null) {
  let inputTags;
  if (type == 1) {
    inputTags = page.tagsList().filter(tag => tag.action() == enums.tagTypeEnums.get("inputclick").value && tag.selectorType() == inputClickTag.selectorType());
  } else {
    inputTags = page.tagsList().filter(tag => tag.action() == enums.tagTypeEnums.get("inputclick").value);
  }

  let typedSourceCode = '';
  let typeDestinationCode = '';
  let i = 0;
  let j = 0;
  let sourceCode = configuration.parameters().pickUpLocation();
  let destinationCode = configuration.parameters().dropOffLocation();
  for (var inputTag of inputTags) {
    if (inputTag.selectorType() == "sourceLocation") {
      let fromElement = await inputTag.element(browserPage, monitoring);
      if (inputTag.waitSelector()) {
        console.log("Wait")
        await browserPage.waitFor(5000);
      }
      if (inputTag.mapInputValue()) {
        let mapInputValue = inputTag.mapInputValue();
        let mapSourceCode = mapInputValue[sourceCode];
        if (mapSourceCode) sourceCode = mapSourceCode;
      }
      await fromElement.click({ clickCount: 3 });
      await browserPage.keyboard.press("Backspace");
      await fromElement.type(sourceCode, { delay: 300 });
      await browserPage.waitFor(5000);
     
      let fromLocationCollectionListTag = page.tagsList().filter(tag => tag.selectorType() == "collectionSourceLocationList")[0];

      if (fromLocationCollectionListTag) {

        let isSourceLocation = false;
        while (i < 3) {
          let fromLocationCollectionElements = await fromLocationCollectionListTag.elements(browserPage, monitoring);
          for (let [index, fromLocationCollectionElement] of fromLocationCollectionElements.entries()) {
            var fromElementText = await (await fromLocationCollectionElement.getProperty('innerText')).jsonValue();
            if (fromLocationCollectionListTag.regexExpression()) {
              var res = fromElementText.trim().match(fromLocationCollectionListTag.regexExpression());
              if (res && res[1].trim().toLowerCase() === sourceCode.toLowerCase()) {
                fromLocationCollectionElement.click();
                isSourceLocation = true;
                i = 4;
                break;

              }
            } else {
              if (fromElementText && fromElementText.trim().toLowerCase() === sourceCode.toLowerCase()) {
                console.log('fromElmenttext' + fromElementText);
                await browserPage.evaluate((fromLocationCollectionElement) => {
                  console.log(fromLocationCollectionElement);
                  fromLocationCollectionElement.click();
                }, fromLocationCollectionElement);
              //  fromLocationCollectionElement.click();
                isSourceLocation = true;
                i = 4;
                break;

              }
            }
            console.log(res);
          }
          if (!isSourceLocation) {
            typedSourceCode = await (await fromElement.getProperty('value')).jsonValue();

            if (typedSourceCode.toLowerCase() === sourceCode.toLowerCase()) {
              isSourceLocation = false;
              break;

            } else {
              await fromElement.click({ clickCount: 3 });
              await browserPage.keyboard.press("Backspace");
              await fromElement.type(sourceCode, { delay: 100 });
              await browserPage.waitFor(5000);
              i++;
            }

          }
        }
        if (!isSourceLocation) {
          response.setAvailability = 'C';
          throw new botError.AirportCodeNotFoundError("Source location airport code not found.");
        }
      }
    } else if (inputTag.selectorType() == "destinationLocation") {
      let toElement = await inputTag.element(browserPage, monitoring);
      if (inputTag.mapInputValue()) {
        let mapInputValue = inputTag.mapInputValue();
        let mapDestinationCode = mapInputValue[destinationCode];
        if (mapDestinationCode) destinationCode = mapDestinationCode;
      }
      await toElement.click({ clickCount: 3 });
      await browserPage.keyboard.press("Backspace");
      await toElement.type(destinationCode, { delay: 300 });
      await browserPage.waitFor(5000);
    
      let toLocationCollectionListTag = page.tagsList().filter(tag => tag.selectorType() == "collectionDestinationLocationList")[0];
      if (toLocationCollectionListTag) {
        let isDestinationLocation = false;
        while (j < 3) {
          let toLocationCollectionElements = await toLocationCollectionListTag.elements(browserPage, monitoring);

          for (let [index, toLocationCollectionElement] of toLocationCollectionElements.entries()) {
            var toElementText = await (await toLocationCollectionElement.getProperty('innerText')).jsonValue();
            if (toLocationCollectionListTag.regexExpression()) {
              var res = toElementText.trim().match(toLocationCollectionListTag.regexExpression());
              if (res && res[1].trim().toLowerCase() === destinationCode.toLowerCase()) {
                toLocationCollectionElement.click();
                isDestinationLocation = true;
                j = 4;
                break;
              }
            } else {

              if (toElementText && toElementText.trim().toLowerCase() === destinationCode.toLowerCase()) {
                console.log('toElementText' + toElementText);
                await browserPage.evaluate((toLocationCollectionElement) => {
                  console.log(toLocationCollectionElement);
                  toLocationCollectionElement.click();
                }, toLocationCollectionElement);
               // toLocationCollectionElement.click();
                isDestinationLocation = true;
                j = 4;
                break;
              }
            }
            console.log(res);
          }
          if (!isDestinationLocation) {
            typeDestinationCode = await (await toElement.getProperty('value')).jsonValue();

            if (typeDestinationCode.toLowerCase() === destinationCode.toLowerCase()) {
              isDestinationLocation = false;
              break;

            } else {
              await toElement.click({ clickCount: 3 });
              await browserPage.keyboard.press("Backspace");
              await toElement.type(destinationCode, { delay: 100 });
              await browserPage.waitFor(5000);
              j++;
            }

          }
        }
        if (!isDestinationLocation) {
          response.setAvailability = 'C';
          throw new botError.AirportCodeNotFoundError("Destination location airport code not found.");
        }
      }

    }
  }
}
async function setExtraField(browserPage, page, configuration, monitoring, logger) {
  let extraFieldTags = page.tagsList().filter(tag => tag.action() == enums.tagTypeEnums.get("extraField").value);
  if (extraFieldTags.length > 0) {
    for (var extraFieldTag of extraFieldTags) {
      let extraElement = await extraFieldTag.element(browserPage, monitoring);
      await extraElement.click();
    }
  }
  return;
}


module.exports = {setInputs,setCalendar,setAdults};
