var {Selectors} = require("./Selector.js");
var {Selector} = require("./Selector.js");
var enums = require('./Enums.js');

class Page {
  constructor(pageDict, index, configuration){
    this._url = pageDict.url;
    this._tagsList = Selectors.create(pageDict.htmlTags, configuration);
    this._action = (pageDict.action) ? getActionType(pageDict.action): null;
    this._waitForNavigation = (pageDict.waitForNavigation) ? pageDict.waitForNavigation: false;
    this._popUpHandler = (pageDict.popUpHandler) ? pageDict.popUpHandler: null;
    this._actionSelector = Selector.create("actionSelector", pageDict.actionSelector);
    this._actionVerifier = (pageDict.actionVerifier) ? pageDict.actionVerifier : null;
    this._isStartPage = (pageDict.type == "main");
    this._type = (pageDict.type) ? getPageType(pageDict.type): null;
    this._applyFilters = (pageDict.applyFilters)? (pageDict.applyFilters): false;
    this._filtersList = (pageDict.filterTags)? Selectors.create(pageDict.filterTags, configuration): [];
    this._index = index;
  }
  /**
   * @return {string}
   */
  url() {
    return this._url;
  }
  /**
   * @return {string}
   */
  tagsList() {
    return this._tagsList;
  }
  /**
   * @return {string}
   */
  action() {
    return this._action;
  }
  /**
   * @return {string}
   */
  actionSelector() {
    return this._actionSelector;
  }
  /**
   * @return {boolean}
   */
  isStartPage() {
    return this._isStartPage;
  }
  /**
   * @return {string}
   */
  type() {
    return this._type;
  }
  /**
   * @return {boolean}
   */
  waitForNavigation() {
    return this._waitForNavigation;
  }
  /**
   * @return {string}
   */
  popUpHandler() {
    return this._popUpHandler;
  }
  /**
   * @return {string}
   */
  actionVerifier() {
    return this._actionVerifier;
  }
  /**
   * @return {integer}
   */
  index() {
    return this._index;
  }
  /**
   * @return {boolean}
   */
  applyFilters() {
    return this._applyFilters;
  }
  /**
   * @return {array}
   */
  filtersList() {
    return this._filtersList;
  }

  static create(pageDict, index, configuration) {
    return new Page(pageDict, index, configuration);
  }
}

function getPageType(_type){
  switch(_type){
      case enums.pageTypeEnums.get("main").key:
        return enums.pageTypeEnums.get("main").value;
      case enums.pageTypeEnums.get("advance search").key:
        return enums.pageTypeEnums.get("advance search").value;
      case enums.pageTypeEnums.get("calendar").key:
        return enums.pageTypeEnums.get("calendar").value;
      case enums.pageTypeEnums.get("listing").key:
        return enums.pageTypeEnums.get("listing").value;
      case enums.pageTypeEnums.get("detail").key:
        return enums.pageTypeEnums.get("detail").value;
  }
}

function getActionType(_type){
  switch(_type){
      case enums.actionEnums.get("click").key:
        return enums.actionEnums.get("click").value;
      case enums.actionEnums.get("input").key:
        return enums.actionEnums.get("input").value;
  }
}

module.exports = {Page};
