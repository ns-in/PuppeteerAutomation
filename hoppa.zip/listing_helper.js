var enums = require('./Enums.js');
var helper = require('./helper.js');
var responseHelper = require('./ResponseHelper.js');

var global = {
  index: 1,
  cacheUrl: null,
  isRequestFailed: false,
  outboundItem: 0,
  outboundColumnItem: 0,
  inboundItem: 0,
  cheapestSelected: false,
  cheapestSelectedInbound: false,
  classTypeColumns: {
    "economy": [],
    "premiumeconomy": [],
    "business": [],
    "first": []
  },
  rateTypeColumns:{
    "refundable":[],
    "non refundable": []
  },
  columnsNameIndexMapping:{}
};

async function checkForWait(browserPage){
  await browserPage.evaluate((className) => {
    let waitSelector = document.querySelectorAll(className);
    if (waitSelector.length > 0) waitSelector[0].click();
  }, ".plnext-widget-btn.btn.btn-primary.timeout-warning-btn-reset-session.small-primary");
}

/**
 * This method handles the extract type of selector and sets it to corresponding response object.
 *
 * @param {object}      browserPage        The browser page object.
 * @param {object}      parentElement      The object under which the selector would be found.
 * @param {selector}    tag                The selector which is to be evaluated.
 * @param {object}      response           The response class object.
 * @param {object}      page               The page class object.
 * @param {object}      configuration      The configuration class object.
 * @param {object}      monitoring         The monitoring class object.
 * @param {object}      logger             The logger object.
 *
 * @return None.
 */
async function handleExtract(browserPage, parentElement, tag, page, configuration, response, monitoring, logger, session){
  //if (isCombined == null) isCombined=configuration.isCombined();
  if (tag.action() == enums.tagTypeEnums.get("extractor").value){
    await extractData(browserPage, parentElement, tag, response, configuration, configuration.isCombined(), monitoring, logger);
  }
}

/**
 * This method fetches the tag value and sets it to corresponding response object.
 *
 * @param {object}      browserPage        The browser page object.
 * @param {object}      parentElement      The object under which the selector would be found.
 * @param {selector}    tag                The selector which is to be evaluated.
 * @param {object}      response           The response class object.
 * @param {object}      configuration      The configuration class object.
 * @param {object}      monitoring         The monitoring class object.
 * @param {object}      logger             The logger object.
 *
 * @return None.
 */
async function extractData(browserPage, parentElement, tag, response, configuration, isCombined, monitoring, logger){
  let value = await tag.value(browserPage, monitoring, parentElement);
  if (!value) return;
  responseHelper.mapValueToData(tag.objectName(), value, global.cacheUrl, configuration.parameters().isRoundtrip(), isCombined, tag.expression(), configuration.parameters().adultCount());
}

async function mapData(objectName, value, configuration, isCombined, expression=null){
  if (!value) return;
  responseHelper.mapValueToData(objectName, value, global.cacheUrl, configuration.parameters().isRoundtrip(), isCombined, expression, configuration.parameters().adultCount());
}

async function getClassHeaders(browserPage, monitoring, parentElements, tags, configuration, classheadersSelected){
  if (classheadersSelected) return;
  for(let [index, parentElement] of parentElements.entries()){
    for (let [cindex, _childTag] of tags.entries()){
      if (enums.tagTypeEnums.get("classFilter").value == _childTag.action()){
        let classHeaders = await _childTag.elements(browserPage, monitoring, parentElement);
        for (let [index, _classHeader] of classHeaders.entries())
        {
          var val = await browserPage.evaluate((_subFilter, index) => {
            let ele = document.querySelectorAll(_subFilter.appliedOn)[index];
            var filterCriteria = _subFilter.value.match(new RegExp(/endswith(.*)then/))[1];
            var endSpace = new RegExp('(?:^|\\W)c(\\w+_)(\\w' + filterCriteria.trim() + ')');
            let returnValue = null;
            if(endSpace.test(ele.className.trim())){
              returnValue = _subFilter.value.match(new RegExp(/then(.*)else/))[1];
            }else{
              returnValue = _subFilter.value.match(new RegExp(/else(.*)/))[1];
            }
            return returnValue.trim();
          }, _childTag.subFilter(), index);
          if (val.toLowerCase() == "refundable"){
            if (!global.rateTypeColumns.refundable.includes(index)) global.rateTypeColumns.refundable.push(index);
          }else{
            if (!global.rateTypeColumns["non refundable"].includes(index)) global.rateTypeColumns["non refundable"].push(index);
          }
          let _value = await (await _classHeader.getProperty('innerText')).jsonValue();
          if (!(index in global.columnsNameIndexMapping)) global.columnsNameIndexMapping[index] = _value.trim();
          if (!classheadersSelected) classheadersSelected=true;
          if (configuration.parameters().searchClassType() == enums.classTypeEnum.ECONOMY.value && enums.classTypeValuesEnum.Economy.value.find(e => e == _value.trim().toLowerCase()))
          {
            if (!global.classTypeColumns["economy"].includes(index)) global.classTypeColumns["economy"].push(index);
          }
          if (configuration.parameters().searchClassType() == enums.classTypeEnum.PREMIUMECONOMY.value && enums.classTypeValuesEnum.get("Premium Economy").value.find(e => e == _value.trim().toLowerCase()))
          {
            if (!global.classTypeColumns["premiumeconomy"].includes(index)) global.classTypeColumns["premiumeconomy"].push(index);
          }
          if (configuration.parameters().searchClassType() == enums.classTypeEnum.BUSINESS.value && enums.classTypeValuesEnum.Business.value.find(e => e == _value.trim().toLowerCase()))
          {
            if (!global.classTypeColumns["business"].includes(index)) global.classTypeColumns["business"].push(index);
          }
          if (configuration.parameters().searchClassType() == enums.classTypeEnum.FIRST.value && enums.classTypeValuesEnum.First.value.find(e => e == _value.trim().toLowerCase()))
          {
            if (!global.classTypeColumns["first"].includes(index)) global.classTypeColumns["first"].push(index);
          }
        }
      }
    }
  }
  return classheadersSelected;
}

async function getPageTags(browserPage, monitoring, page, configuration)
{
  let _parentTags = page.tagsList().filter(tag => (tag.parent() == null && tag.action() == enums.tagTypeEnums.get("select").value && tag.isRoot()));
  let finalTags = [];
  for (var _tag of _parentTags)
  {
    let parentElement = await _tag.verifyElement(browserPage, monitoring, null);
    if (parentElement) finalTags.push(_tag);
  }
  return finalTags;
}

module.exports = {global, checkForWait, handleExtract, getClassHeaders, getPageTags, mapData};
