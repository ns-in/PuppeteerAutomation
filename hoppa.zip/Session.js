var session = {
  response: null,
  outboundInboundItems: {},
  isFailed: false
}

module.exports = {session};
