class HTMLTagsError extends Error {
  constructor(message) {
    super(message);
    this.type = 1;
  }
}

class ProxyError extends Error {
  constructor(message) {
    super(message);
    this.type = 2;
  }
}

class OtherError extends Error {
  constructor(message) {
    super(message);
    this.type = 3;
  }
}

class WebsiteError extends Error {
  constructor(message) {
    super(message);
    this.type = 4;
  }
}

class TimeoutError extends Error {
  constructor(message) {
    super(message);
    this.type = 5;
  }
}

class AirportCodeNotFoundError extends Error {
  constructor(message) {
    super(message);
    this.type = 6;
  }
}

class ClosedCase extends Error {
  constructor(message) {
    super(message);
    this.type = 7;
  }
}

module.exports = {HTMLTagsError, ProxyError, OtherError, WebsiteError, TimeoutError, AirportCodeNotFoundError, ClosedCase};
