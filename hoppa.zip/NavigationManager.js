var enums = require('./Enums.js');
var navigationStartPage = require('./StartPage.js');
var navigationCalendarPage = require('./CalendarPage.js');
var navigationListingPage = require('./ListingPage.js');
var botError = require('./BotError.js');
const { performance } = require('perf_hooks');
var wait = false;


class NavigationManager {
  constructor(pages, configuration, response, monitoring, Logger) {
    this._pages = pages;
    this._configuration = configuration;
    this._response = response;
    this._monitoring = monitoring;
    this._Logger = Logger;
  }

  static create(pages, configuration, response, monitoring, Logger) {
    return new NavigationManager(pages, configuration, response, monitoring, Logger);
  }

  async crawl(browser, browserPage, session) {
    let _configuration = this._configuration;
    let _response = this._response;
    let _monitoring = this._monitoring;
    let _Logger = this._Logger;
    browser.on('targetcreated', async (target) => {
      if (target.type() !== 'page') {
        return;
      } else {
        wait = true;
        browserPage = await target.page();
        await browserPage.setJavaScriptEnabled(true);
        await browserPage.setExtraHTTPHeaders({
          'Accept-Language': 'en-US,en;q=0.9'
        });
        // Pass the Webdriver Test.
        await page.evaluateOnNewDocument(() => {
          Object.defineProperty(navigator, 'webdriver', {
			  get: () => false,
			});
			Object.defineProperty(navigator, 'userAgent', {
			  get: () => "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36",
			});
			// We can mock this in as much depth as we need for the test.
			window.navigator.chrome = {
			  runtime: {}
			};
			Object.defineProperty(navigator, 'plugins', {
			  get: () => [1, 2, 3, 4, 5],
			});
			// Overwrite the `languages` property to use a custom getter.
			Object.defineProperty(navigator, 'languages', {
			  get: () => ['en-US', 'en'],
			});
			Object.defineProperty(navigator, 'platform', {
			  get: () => "Linux x86_64",
			});
			const originalQuery = window.navigator.permissions.query;
			window.navigator.permissions.__proto__.query = parameters =>
			  parameters.name === 'notifications'
				? Promise.resolve({state: Notification.permission})
				: originalQuery(parameters);
        });
        try {
          await browserPage.authenticate({
            username: _configuration.proxy().UserId,
            password: _configuration.proxy().Password
          });
        } catch (e) {
          throw new botError.ProxyError("Proxy authentication failed for username " + configuration.proxy().UserId);
        }
        await browserPage.setUserAgent("Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36");
        await browserPage.setViewport({
          width: 1550,
          height: 750
        });
        let newTabNavigationStartTime = performance.now();
        await browserPage.waitForNavigation({ waitUntil: "domcontentloaded", timeout: 120000 });
        let _title = (await browserPage.title()).toLowerCase();
        while (!(_title.includes("error")) && !(_title.includes("calendar")) && !(_title.includes("flights"))) {
          let newTabIntermediateEndTime = performance.now();
          if ((newTabIntermediateEndTime - newTabNavigationStartTime) > 120000) throw new botError.TimeoutError("New Tab navigation timeout exceeded.");
          await browserPage.waitFor(10000);
          _title = (await browserPage.title()).toLowerCase();
        }
        let isPageLoaded = await browserPage.evaluate(() => document.readyState);
        while (isPageLoaded != "complete") {
          isPageLoaded = await browserPage.evaluate(() => document.readyState);
          await browserPage.waitFor(4000);
        }
        wait = false;
        await browserPage.waitFor(3000);
      }
    });
    this._Logger.Debug = "Navigation Manager Crawl called";
    this._pages = this._pages.sort(function (a, b) {
      return (a.index() - b.index());
    });
    let pagesLength = (await browser.pages()).length;
    await Promise.all([
      this._pages.reduce(async function (promise, page) {
        return promise.then(async function () {
          if (_response.availability) return;
          if (page.index() == 1) {
            try {
				await browserPage.waitFor(3000);
              await browserPage.goto(page.url(), { waitUntil: ['domcontentloaded', 'networkidle0'], timeout: 60000 });
              await browserPage.waitFor(2000);
            } catch (e) {
              if (e.message.indexOf('net::ERR_CONNECTION_CLOSED') > -1) {
                await browserPage.reload({ waitUntil: 'networkidle2', timeout: 60000 });
                await browserPage.waitFor(2000);
              }
            }
          }
          var _navigationPage = null;
          if (page.type() == enums.pageTypeEnums.get("main").value) _navigationPage = new navigationStartPage.StartPage();
          if (page.type() == enums.pageTypeEnums.get("calendar").value) _navigationPage = new navigationCalendarPage.CalendarPage();
          if (page.type() == enums.pageTypeEnums.get("listing").value) _navigationPage = new navigationListingPage.ListingPage();
          let _currentTitle = await browserPage.title();
          if (_currentTitle.toLowerCase().includes("error")) {
            _Logger.Error = "Website gave an error page for the defined criteria.";
            throw new botError.WebsiteError("Website gave an error page.");
          }
          if (page.type() == enums.pageTypeEnums.get("calendar").value && !(_currentTitle.toLowerCase().includes("calendar"))) {
            _Logger.Info = `Navigation Manager skipping Calendar page assuming direct listing is opened. Current title is: ${_currentTitle}`;
            return Promise.resolve();
          }
          let _pageType = null;
          if (page.type() == enums.pageTypeEnums.get("main").value) _pageType = enums.pageTypeEnums.get("main").key;
          if (page.type() == enums.pageTypeEnums.get("calendar").value) _pageType = enums.pageTypeEnums.get("calendar").key;
          if (page.type() == enums.pageTypeEnums.get("listing").value) _pageType = enums.pageTypeEnums.get("listing").key;
          _Logger.Info = "Navigation Manager Crawl started for " + _pageType;
          return _navigationPage.crawl(browserPage, page, _configuration, _response, _monitoring, _Logger, session).then(async function (res) {
            while (wait) {
              await browserPage.waitFor(3000);
            }
            let isPageLoaded = await browserPage.evaluate(() => document.readyState);
            while (isPageLoaded != "complete") {
              isPageLoaded = await browserPage.evaluate(() => document.readyState);
            }
            _Logger.Info = "Navigation Manager Crawl completed for " + _pageType;
          });
        });
      }, Promise.resolve())
    ]);
  }
}

module.exports = { NavigationManager };
