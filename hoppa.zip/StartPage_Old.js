var base = require('./BasePage.js');
var enums = require('./Enums.js');
var helper = require('./helper.js');
var botError = require('./BotError.js');
const {performance} = require('perf_hooks');
const {TimeoutError} = require('puppeteer/Errors');
var retry = 0;
var pageTitle = null;

var StartPage = base.BaseCrawlPage.subclass();
StartPage.prototype._setInput = async function(browserPage, page, configuration, response, monitoring, logger){
  console.log("set input start page");
  retry = 0;
  let isPageLoaded = await browserPage.evaluate(() => document.readyState);
  let newTabNavigationStartTime = performance.now();
  while(isPageLoaded != "complete"){
    let newTabIntermediateEndTime = performance.now();
    if ((newTabIntermediateEndTime-newTabNavigationStartTime) > 120000) throw new botError.TimeoutError("New Tab navigation timeout exceeded.");
    isPageLoaded = await browserPage.evaluate(() => document.readyState);
    await browserPage.waitFor(1500);
  }
  console.log("after state");
  await browserPage.waitFor(1500);
  await browserPage.addScriptTag({
    path: './' + configuration.calendarPath()
  });
  
  if (page.tagsList().filter(tag => tag.selectorType() == "booking").length > 0){
    let mainTab = page.tagsList().filter(tag => tag.selectorType() == "booking")[0];
    let tabElement = await mainTab.element(browserPage, monitoring);
    await tabElement.click({delay:500});
    await browserPage.waitFor(1500);
  }



  await setTripSelector(browserPage, page, configuration, monitoring, logger);
  await browserPage.waitFor(3000);
  logger.Debug = "SetTripSelector completed.";
  
  await setInputs(browserPage, page, configuration, monitoring, response);

  await setCalendar(browserPage, page, configuration, monitoring);
  logger.Debug = "setCalendar completed.";
  await browserPage.waitFor(3000);
  logger.Debug = "setInputs completed.";
  await setAdults(browserPage, page, configuration, monitoring);
  logger.Debug = "setAdults completed.";
  await browserPage.waitFor(2000);
  await setClass(browserPage, page, configuration, monitoring);
  logger.Debug = "setClass completed.";
  logger.Info = "SetInput completed on start page.";
  await browserPage.waitFor(1000);
  pageTitle = await browserPage.title();
}
StartPage.prototype._getInfo = async function(browserPage, page, configuration, response, monitoring, logger){
  logger.Info = "GetInput completed on start page.";
};
StartPage.prototype._navigate = async function(browserPage, page, configuration, response, monitoring, logger){
  if (page.action() == enums.actionEnums.get("click").value){
    let navigationElement = await page.actionSelector().element(browserPage, monitoring);
    await browserPage.evaluate(el => {
      el.click();
    }, navigationElement);
    //await browserPage.waitFor(5000);
    if (page.popUpHandler())
    {
      console.log("inside handler");
      try{
        await browserPage.evaluate(`${page.popUpHandler()}`);
      }catch(exception){

      }
      console.log("after handler");
    }
    console.log("before navigation");
    await browserPage.waitFor(2000);
    if (page.waitForNavigation()) {
      try {
        await browserPage.waitForNavigation({timeout: 180000});
      } catch (e) {
        if (e instanceof TimeoutError) {
          let _currentTitle = await browserPage.title();
          console.log(_currentTitle);
          console.log(_currentTitle.toLowerCase() == pageTitle.toLowerCase());
          if (_currentTitle.toLowerCase() != pageTitle.toLowerCase()){
            console.log("navigating from start page from catch");
            logger.Info = "Navigating from start page from catch.";
            return;
          }
        }
      }
    }
    console.log("after first navigation");
    await browserPage.waitFor(30000);
    if(page.actionVerifier() && retry < 1)
    {
      await browserPage.waitFor(5000);
      let _currentTitle = await browserPage.title();
      console.log(_currentTitle);
      if (_currentTitle.toLowerCase() == pageTitle.toLowerCase())
      {
      // await browserPage.setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3359.181 Safari/537.36");
        await browserPage.setUserAgent("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36");
        try {
          await browserPage.goto(page.url(), { timeout: 240000});
        } catch (e) {
          if (e instanceof TimeoutError) {
            throw new botError.TimeoutError("Page navigation from start page timeout exceeded one.");
          }
        }
        let newTabNavigationStartTime = performance.now();
        let isPageLoaded = "not";
        while(isPageLoaded != "complete"){
          let newTabIntermediateEndTime = performance.now();
          if ((newTabIntermediateEndTime-newTabNavigationStartTime) > 180000) throw new botError.TimeoutError("Page navigation from start page timeout exceeded two.");
          isPageLoaded = await browserPage.evaluate(() => document.readyState);
          await browserPage.waitFor(10000);
        }
        console.log(browserPage.url());
        await browserPage.waitFor(30000);
        //await this._setInput(browserPage, page, configuration, response, monitoring, logger);
        let navigationElement1 = await page.actionSelector().element(browserPage, monitoring);
        await browserPage.evaluate(el => {
          el.click();
        }, navigationElement1);
        if (page.popUpHandler())
        {
          console.log("inside handler");
          try{
            await browserPage.evaluate(`${page.popUpHandler()}`);
          }catch(exception){

          }
          console.log("after handler");
        }
        console.log("before second navigation");
        retry += 1;
        console.log(page.waitForNavigation());
        if (page.waitForNavigation()) {
          try {
            await browserPage.waitForNavigation({timeout: 180000});
            _currentTitle = await browserPage.title();
            if (_currentTitle.toLowerCase() == pageTitle.toLowerCase())
            {
              throw new botError.TimeoutError("Page navigation from start page timeout exceeded three.");
            }
          } catch (e) {
            if (e instanceof TimeoutError) {
              let _currentTitle = await browserPage.title();
              console.log(_currentTitle);
              if (_currentTitle.toLowerCase() != pageTitle.toLowerCase()){
                console.log("navigating from start page from catch");
                logger.Info = "Navigating from start page from catch.";
                return;
              }
            }else{
				logger.Info = browserPage.url();
				logger.Error = e;
              throw new botError.TimeoutError("Page navigation from start page timeout exceeded four.");
            }
          }
        }
        let _currentTitle1 = await browserPage.title();
        console.log(_currentTitle1);
      }
    }
    await browserPage.waitFor(20000);
    console.log("navigating from start page");
    logger.Info = "Navigating from start page.";
  }
};

async function setTripSelector(browserPage, page, configuration, monitoring, logger){
  console.log(configuration.parameters().isRoundtrip());
  logger.Debug = "Value for Roundtrip is: " + configuration.parameters().isRoundtrip().toString();
  if (page.tagsList().filter(tag => tag.selectorType() == "trip").length > 0)
  {
    let tripTag = page.tagsList().filter(tag => tag.selectorType() == "trip")[0];
    if(tripTag && tripTag.pattern() == enums.patternTypeEnums.get("click").value){
      let tripElement = await tripTag.element(browserPage, monitoring);
      await browserPage.evaluate(el => {
        el.click();
      }, tripElement);
      await browserPage.waitFor(2000);
    }
  }
}


async function setInputs(browserPage, page, configuration, monitoring, response){
  let inputTags = page.tagsList().filter(tag => tag.action() == enums.tagTypeEnums.get("input").value);
  for (var inputTag of inputTags){
    if (inputTag.selectorType() == "sourceLocation"){
      let fromElement = await inputTag.element(browserPage, monitoring);
      let valueToClear = await (await fromElement.getProperty('value')).jsonValue();
      await fromElement.focus();
      for (let i = 0; i < valueToClear.length; i++) {
        await browserPage.keyboard.press("Backspace");
      }
    
    /* Added Location type on the basis of Product */
    console.log(configuration.productId());
    if(configuration.productId()  == enums.productType.get("Car").value){
      await fromElement.type(configuration.parameters().pickUpLocation(), {delay: 100});
    }
    if(configuration.productId()  == enums.productType.get("Air").value){
    await fromElement.type(configuration.parameters().startLocation(), {delay: 100});
    }
    /* Added Location type on the basis of Product */

      await browserPage.waitFor(1000);
      let fromLocationListTag = page.tagsList().filter(tag => tag.selectorType() == "sourceLocationList")[0];
      let fromLocationListElement = await fromLocationListTag.element(browserPage, monitoring);
	  let from_none = await (await fromLocationListElement.getProperty('innerText')).jsonValue();
      if (from_none.includes("Hmmm") || from_none.includes("Uh-oh"))
      {
        response.setAvailability = 'C';
        throw new botError.AirportCodeNotFoundError("Source location airport code not found.");
      }
      await browserPage.evaluate(el => {
        el.click();
      }, fromLocationListElement);
      await browserPage.waitFor(1000);
      let fromElementVerify = await inputTag.element(browserPage, monitoring);
      let valueToVerify = await (await fromElementVerify.getProperty('value')).jsonValue();
      var exp = "\\(([^)]+)\\)";
      let res = valueToVerify.trim().match(exp);
      if (res && res[1].trim().toLowerCase() != configuration.parameters().startLocation().toLowerCase()){
        response.setAvailability = 'C';
        throw new botError.AirportCodeNotFoundError("Source location airport code not found.");
      }
    }else if (inputTag.selectorType() == "destinationLocation") {
      let toElement = await inputTag.element(browserPage, monitoring);
      let valueToClear = await (await toElement.getProperty('value')).jsonValue();
      for (let i = 0; i < valueToClear.length; i++) {
        await browserPage.keyboard.press("Backspace");
      }
      await toElement.type(configuration.parameters().destinationLocation(), {delay: 300});
      await browserPage.waitFor(5000);
      let toLocationListTag = page.tagsList().filter(tag => tag.selectorType() == "destinationLocationList")[0];
      let toLocationListElement = await toLocationListTag.element(browserPage, monitoring);
	  let to_none = await (await toLocationListElement.getProperty('innerText')).jsonValue();
      if (to_none.includes("Hmmm") || to_none.includes("Uh-oh"))
      {
        response.setAvailability = 'C';
        throw new botError.AirportCodeNotFoundError("Destination location airport code not found.");
      }
      await browserPage.evaluate(el => {
        el.click();
      }, toLocationListElement);
      await browserPage.waitFor(1000);
      let fromElementVerify = await inputTag.element(browserPage, monitoring);
      let valueToVerify = await (await fromElementVerify.getProperty('value')).jsonValue();
      var exp = "\\(([^)]+)\\)";
      let res = valueToVerify.trim().match(exp);
      if (res && res[1].trim().toLowerCase() != configuration.parameters().destinationLocation().toLowerCase()){
        response.setAvailability = 'C';
        throw new botError.AirportCodeNotFoundError("Destination location airport code not found.");
      }
    }
  }
}

async function setCalendar(browserPage, page, configuration, monitoring){
  let calendarTags = page.tagsList().filter(tag => tag.action() == enums.tagTypeEnums.get("calendar").value);
  await browserPage.waitFor(2000);
  for (var inputTag of calendarTags){
    if (inputTag.selectorType() == "fromCalendar"){
      await calendarClick(browserPage, monitoring, inputTag, configuration.parameters()._startDate.toString());
    }else if ((inputTag.selectorType() == "toCalendar") && (configuration.parameters().isRoundtrip())) {
      await calendarClick(browserPage, monitoring, inputTag, configuration.parameters()._endDate.toString());
    }
  }
}

async function calendarClick(browserPage, monitoring, inputTag, date)
{
  let dateElement = await inputTag.element(browserPage, monitoring);
  if(inputTag.selectorPattern() == 1){
    await dateElement.click();
    
    let closedDate = await browserPage.evaluate((date, departureDateControl) => {
      var departure_date_control = findGivenDateControl(date);
      if (departure_date_control == "closed")
      {
        return "closed";
      }
      departure_date_control.click({delay:500});
    }, date, dateElement);
    if(closedDate=="closed"){
      throw new botError.ClosedCase("Site does not allow to search on request date");
    }
    await browserPage.waitFor(2000);
  }
  else if(inputTag.selectorPattern() == 2){
    await browserPage.evaluate(el => {
      el.click();
    }, dateElement);
    await browserPage.waitFor(2000);
    await browserPage.evaluate((date) => {
      findGivenDateControl(date).then(()=>{
      });
    }, date);
    await browserPage.waitFor(2000);
  }
}

async function setAdults(browserPage, page, configuration, monitoring){
  var inputTag = page.tagsList().filter(tag => (tag.action() == enums.tagTypeEnums.get("click").value) && (tag.selectorType() == "adults"))[0];
  if(inputTag){
    if(inputTag.pattern() == enums.patternTypeEnums.get("click").value){
      let adultElement = await inputTag.element(browserPage, monitoring);
      await browserPage.evaluate((element, value) => {
        function selectAdults(element, value) {
          for (i = 0; i < element.options.length; i++) {
            if (parseInt(element.options[i].text) == value)
            {
              element.options[i].selected = true;
              return;
            }
          }
          return;
        }
        selectAdults(element, value);
      }, adultElement, configuration.parameters().adultCount())
      await browserPage.waitFor(2000);
    }
    else if(inputTag.pattern() == enums.patternTypeEnums.get("add").value){
      let passengerElement = await inputTag.element(browserPage, monitoring);
      await passengerElement.click();
      await browserPage.waitFor(1000);
      let adultElement = null;
      if (page.tagsList().filter(tag => (tag.action() == enums.tagTypeEnums.get("select").value) && (tag.selectorType() == "adults")).length > 0){
        let adultTag = page.tagsList().filter(tag => (tag.action() == enums.tagTypeEnums.get("select").value) && (tag.selectorType() == "adults"))[0];
        adultElement = await adultTag.element(browserPage, monitoring);
      }
      let addTag = page.tagsList().filter(tag => (tag.action() == enums.tagTypeEnums.get("click").value) && (tag.selectorType() == "adultsAdd"))[0];
      let addElement = await addTag.element(browserPage, monitoring);
      let adultValue = configuration.parameters().adultCount();
      console.log(adultValue);
      for (var i =1; i<adultValue;i++){
        await addElement.click();
        console.log("click called");
        await browserPage.waitFor(500);
      }
      let closeTag = page.tagsList().filter(tag => (tag.action() == enums.tagTypeEnums.get("click").value) && (tag.selectorType() == "closeAdults"))[0];
      if(closeTag){
        let closeElement = await closeTag.element(browserPage, monitoring);
        await closeElement.click();
      }
      await browserPage.waitFor(500);

    }
  }
}

async function setClass(browserPage, page, configuration, monitoring){
  let inputTag = page.tagsList().filter(tag => (tag.selectorType() == "classtype"))[0];
  if(inputTag){
    if(inputTag.pattern() == enums.patternTypeEnums.get("dropdown").value){
      let adultElement = await inputTag.element(browserPage, monitoring);
      await browserPage.evaluate((element, value) => {
        function selectClassType(element, value) {
          for (i = 0; i < element.options.length; i++) {
            if (element.options[i].text.includes(value))
            {
              element.options[i].selected = true;
              return;
            }
          }
          return;
        }
        selectClassType(element, value);
      }, adultElement, enums.classTypeGroupEnum.get(configuration.parameters().mappedClassType()).value )
      await browserPage.waitFor(2000);
    }
    else if(inputTag.pattern() == enums.patternTypeEnums.get("click").value){
      let classElement = await inputTag.element(browserPage, monitoring);
      await classElement.click();
      await browserPage.waitFor(3000);
      let classDivTag = page.tagsList().filter(tag => (tag.action() == enums.tagTypeEnums.get("select").value) && (tag.selectorType() == "classtypediv"))[0];
      let classDivElement = await classDivTag.element(browserPage, monitoring);
      let classListDivTag = page.tagsList().filter(tag => (tag.action() == enums.tagTypeEnums.get("select").value) && (tag.selectorType() == "classtypelist"))[0];
      let classListDivElement = await classDivTag.element(browserPage, monitoring);
      let columnTag = page.tagsList().filter(tag => (tag.action() == enums.tagTypeEnums.get("select").value) && (tag.selectorType() == "classtypecolumn"))[0];
      let columns = await columnTag.elements(browserPage, monitoring, classListDivElement);
      let classTypeName = null;
      let classNameTag = page.tagsList().filter(tag => (tag.action() == enums.tagTypeEnums.get("extractor").value) && (tag.selectorType() == "classtypename"))[0];
      let radioButtonTag = page.tagsList().filter(tag => (tag.action() == enums.tagTypeEnums.get("click").value) && (tag.selectorType() == "classtypename"))[0];
      let radioButton = null;
      await browserPage.waitFor(3000);
      for (var column of columns){
        classTypeName = await classNameTag.value(browserPage, monitoring, column);
        if(classTypeName == enums.classTypeGroupEnum.get(configuration.parameters().mappedClassType()).value){
          await browserPage.evaluate((attributes, el)=>{
            let radio = el.querySelector(attributes["ByClass"]);
            el.querySelector(attributes["ByClass"]).click();
            radio.click();
          }, radioButtonTag._attributes, column);
          break;
        }
      }
    }
  }
}

module.exports = {StartPage};
