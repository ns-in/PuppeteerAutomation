var enums = require('./Enums.js');
var helper = require('./helper.js');
var listingHelper = require('./listing_helper.js');
var responseHelper = require('./ResponseHelper.js');
var botError = require('./BotError.js');
var outboundSelectedArray = {"rowIndex": 0,"columnIndex": 0, "value": 0};
var inboundSelectedArray = {"rowIndex": 0,"columnIndex": 0, "value": 0};
var isContinue = false;
var classheadersSelected = false;
var priceType = null;
var classType = null;

/**
* This method handles traversal of the selectors to extract values.
*
* @param {object}      browserPage        The browser page object.
* @param {object}      page               The page class object.
* @param {object}      configuration      The configuration class object.
* @param {object}      response           The response class object.
* @param {object}      monitoring         The monitoring class object.
* @param {object}      logger             The logger object.
* @param {array}       parentTags         The list of selectors.
* @param {object}      elementHandle      The current select dom object.
*
* @return None.
*/
async function searchPatternSelectionInfo(browserPage, page, configuration, response, monitoring, logger, parentTags, session, elementHandle=null){
  if (!configuration.parameters().isRawReport())
  {
    for (var _tag of parentTags)
    {
      let childTags = null;
      let searchInPage = true;
      if ([enums.tagTypeEnums.get("select").value, enums.tagTypeEnums.get("linked").value].includes(_tag.action()))
      {
        childTags = page.tagsList().filter(tag => tag.parent() == _tag.name());
      }else{
        searchInPage = false;
        childTags = page.tagsList().filter(tag => tag.name() == _tag.name());
      }
      let parentElements = await _tag.elements(browserPage, monitoring, elementHandle);
      if (!classheadersSelected) {
        classheadersSelected = await listingHelper.getClassHeaders(browserPage, monitoring, parentElements, childTags, configuration, classheadersSelected);
        if (classheadersSelected && listingHelper.global.classTypeColumns["economy"].length == 0 && listingHelper.global.classTypeColumns["premiumeconomy"].length == 0 && listingHelper.global.classTypeColumns["business"].length == 0 && listingHelper.global.classTypeColumns["first"].length == 0) {
          response.setAvailability = 'C';
          return;
        }
      }
      let inbounds = childTags.filter(tag => tag.flightType() == "inbound");
      if (inbounds.length > 0){
        inboundSelectedArray = await getCheapestInbound(browserPage, searchInPage, parentElements, childTags, page, configuration, response, monitoring, logger, session);
      }
      let outbounds = childTags.filter(tag => tag.flightType() == "outbound");
      if (outbounds.length > 0){
          outboundSelectedArray = await getCheapestOutbound(browserPage, searchInPage, parentElements, childTags, page, configuration, response, monitoring, logger, session);
      }
      for(let [index, parentElement] of parentElements.entries()){
        for (let [cindex, _childTag] of childTags.entries()){
          if (_childTag.flightType() == "outbound"){
            if (!(index in session.outboundInboundItems)) session.outboundInboundItems[index] = {};
            listingHelper.global.outboundItem = index;
          }
          if (outbounds.length > 0 && _childTag.flightType() == "outbound"){
            if (index == outboundSelectedArray.rowIndex && outboundSelectedArray.value > 0){
              await handleSelect(browserPage, parentElement, _childTag, page, configuration, response, monitoring, logger, session);
              await handleOutboundClick(browserPage, parentElement, searchInPage, _childTag, page, configuration, response, monitoring, logger, session, outboundSelectedArray);
              await listingHelper.handleExtract(browserPage, parentElement, _childTag, page, configuration, response, monitoring, logger, session);
              isContinue = false;
            }else{
              isContinue = true;
            }
          }
          else if (inbounds.length > 0 && _childTag.flightType() == "inbound"){
            if (index == inboundSelectedArray.rowIndex && inboundSelectedArray.value > 0){
              await handleSelect(browserPage, parentElement, _childTag, page, configuration, response, monitoring, logger, session);
              await handleInboundClick(browserPage, parentElement, searchInPage, _childTag, page, configuration, response, monitoring, logger, session, inboundSelectedArray);
              await listingHelper.handleExtract(browserPage, parentElement, _childTag, page, configuration, response, monitoring, logger, session);
              isContinue = false;
            }else{
              isContinue = true;
            }
          }else{
            await handleSelect(browserPage, parentElement, _childTag, page, configuration, response, monitoring, logger, session);
            await handleClick(browserPage, parentElement, searchInPage, _childTag, page, configuration, response, monitoring, logger, session);
            await listingHelper.handleExtract(browserPage, parentElement, _childTag, page, configuration, response, monitoring, logger, session);
            isContinue = false;
          }
        }
        if (isContinue) {
          console.log("continuing");
          //continue;
        }
        if (_tag.raise() && _tag.raise() == "flush.flightdetails"){
          responseHelper.flushFlightDetails(response);
        }
        if (_tag.raise() && _tag.raise() == "flush.flightdetailsInbound"){
          responseHelper.flushFlightDetailsInbound(response);
        }
        if (_tag.raise() && _tag.raise() == "screenshot"){
          var imageName = "detailsScreen-" + configuration.requestDetailId() + "-" + Math.floor((Math.random() * 1000) + 1).toString() + ".png";
          listingHelper.global.cacheUrl = await helper.captureAndUploadScreenshot(browserPage, configuration, imageName);
          listingHelper.global.index += 1;
        }
        if (_tag.event()){
          let subChildTags = page.tagsList().filter(tag => tag.name() == _tag.event());
          await searchPatternSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session);
        }
      }
    }
  }
}

/**
 * This method handles the select type of selector used for navigating into the dom tree.
 *
 * @param {object}      browserPage        The browser page object.
 * @param {object}      parentElement      The object under which the selector would be found.
 * @param {selector}    tag                The selector which is to be evaluated.
 * @param {object}      response           The response class object.
 * @param {object}      page               The page class object.
 * @param {object}      configuration      The configuration class object.
 * @param {object}      monitoring         The monitoring class object.
 * @param {object}      logger             The logger object.
 *
 * @return None.
 */
async function handleSelect(browserPage, parentElement, tag, page, configuration, response, monitoring, logger, session, ignoreIteration = false){
  if ([enums.tagTypeEnums.get("select").value].includes(tag.action())){
    if (tag.raise() && tag.raise() == "screenshot"){
      var imageName = "detailsScreen-" + configuration.requestDetailId() + "-" + Math.floor((Math.random() * 1000) + 1).toString() + ".png";
      listingHelper.global.cacheUrl = await helper.captureAndUploadScreenshot(browserPage, configuration, imageName);
      listingHelper.global.index += 1;
    }
    await searchPatternSelectionInfo(browserPage, page, configuration, response, monitoring, logger, [tag], session, parentElement);
    if (ignoreIteration) return;
    if (tag.linked())
    {
      let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.linked());
      await searchPatternSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session);
    }
    if (tag.raise() && tag.raise() == "flush.flightdetails"){
      responseHelper.flushFlightDetails(response);
    }
    if (tag.raise() && tag.raise() == "flush.flightdetailsInbound"){
      responseHelper.flushFlightDetailsInbound(response);
    }
    if (tag.raise() && tag.raise() == "flush"){
      responseHelper.flush(response, configuration.parameters().isRoundtrip(), configuration.isCombined(), true, manipulateDate=false);
    }
    if (tag.event()){
      let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.event());
      await searchPatternSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session);
    }
  }
}

async function getCheapestInbound(browserPage, searchInPage, parentElements, childTags, page, configuration, response, monitoring, logger, session){
  let tempArray = {"rowIndex": 0,"columnIndex": 0, "value": 0};
  for(let [index, parentElement] of parentElements.entries()){
    for (let [cindex, _childTag] of childTags.entries()){
      await handleSelect(browserPage, parentElement, _childTag, page, configuration, response, monitoring, logger, session, true);
      if (_childTag.action() == enums.tagTypeEnums.get("search").value)
      {
        let clickElements = [];
        if (searchInPage){
          clickElements = await _childTag.elements(browserPage, monitoring, parentElement);
        }else{
          clickElements = await _childTag.elements(browserPage, monitoring, null);
        }
        var clickElementsLength = clickElements.length;
        let arr = Array(clickElementsLength - 0 ).fill().map((_, idx) => 0 + idx);
        for (let i of arr){
          let x = (await clickElements[i].$x('..'))[0];
          let y = (await x.$x('..'))[0];
          if (_childTag.ignoreValue())
          {
            let ignore = false;
            for (let _ignoreValue of _childTag.ignoreValue().split(','))
            {
              if ((await(await y.getProperty('className')).jsonValue()).indexOf(_ignoreValue.trim()) > -1) ignore = true;
            }
            if (ignore) {
              continue;
            }
          }
          if (classheadersSelected) {
            if(configuration.parameters().searchClassType() == enums.classTypeEnum.ECONOMY.value)
            {
              if(!listingHelper.global.classTypeColumns["economy"].includes(i)) continue;
            }
            if(configuration.parameters().searchClassType() == enums.classTypeEnum.PREMIUMECONOMY.value)
            {
              if(!listingHelper.global.classTypeColumns["premiumeconomy"].includes(i)) continue;
            }
            if(configuration.parameters().searchClassType() == enums.classTypeEnum.BUSINESS.value)
            {
              if(!listingHelper.global.classTypeColumns["business"].includes(i)) continue;
            }
            if(configuration.parameters().searchClassType() == enums.classTypeEnum.FIRST.value)
            {
              if(!listingHelper.global.classTypeColumns["first"].includes(i)) continue;
            }
          }
          let elementPrice = await browserPage.evaluate((element) => {
            return Promise.resolve(element.innerText.replace(/[^0-9\.]+/g,""));
          }, clickElements[i]);
          if (parseInt(inboundSelectedArray.value) == 0 || parseFloat(inboundSelectedArray.value) > parseFloat(elementPrice)){
            inboundSelectedArray.rowIndex = index;
            inboundSelectedArray.columnIndex = i;
            inboundSelectedArray.value = parseFloat(elementPrice);
          }
        }
      }
    }
  }
  if (inboundSelectedArray.rowIndex == 0 && inboundSelectedArray.value == 0) throw new botError.ClosedCase("No inbound found.");
  return inboundSelectedArray;
}

async function getCheapestOutbound(browserPage, searchInPage, parentElements, childTags, page, configuration, response, monitoring, logger, session){
  let tempArray = {"rowIndex": 0,"columnIndex": 0, "value": 0};
  for(let [index, parentElement] of parentElements.entries()){
    if (childTags.filter(_tag => _tag.action() == enums.tagTypeEnums.get("search").value).length == 0) return outboundSelectedArray;
    for (let [cindex, _childTag] of childTags.entries()){
      if (_childTag.action() == enums.tagTypeEnums.get("search").value)
      {
        let clickElements = [];
        if (searchInPage){
          clickElements = await _childTag.elements(browserPage, monitoring, parentElement);
        }else{
          clickElements = await _childTag.elements(browserPage, monitoring, null);
        }
        var clickElementsLength = clickElements.length;
        let arr = Array(clickElementsLength - 0 ).fill().map((_, idx) => 0 + idx);
        for (let i of arr){
          let x = (await clickElements[i].$x('..'))[0];
          let y = (await x.$x('..'))[0];
          if (_childTag.ignoreValue())
          {
            let ignore = false;
            for (let _ignoreValue of _childTag.ignoreValue().split(','))
            {
              if ((await(await y.getProperty('className')).jsonValue()).indexOf(_ignoreValue.trim()) > -1) ignore = true;
            }
            if (ignore) {
              continue;
            }
          }
          if (classheadersSelected) {
            if(configuration.parameters().searchClassType() == enums.classTypeEnum.ECONOMY.value)
            {
              if (configuration.parameters().isRefundable() && !listingHelper.global.rateTypeColumns["refundable"].includes(i)) continue;
              if(!listingHelper.global.classTypeColumns["economy"].includes(i) || listingHelper.global.rateTypeColumns["refundable"].includes(i)) continue;
            }
            if(configuration.parameters().searchClassType() == enums.classTypeEnum.PREMIUMECONOMY.value)
            {
              if (configuration.parameters().isRefundable() && !listingHelper.global.rateTypeColumns["refundable"].includes(i)) continue;
              if(!listingHelper.global.classTypeColumns["premiumeconomy"].includes(i) || listingHelper.global.rateTypeColumns["refundable"].includes(i)) continue;
            }
            if(configuration.parameters().searchClassType() == enums.classTypeEnum.BUSINESS.value)
            {
              if (configuration.parameters().isRefundable() && !listingHelper.global.rateTypeColumns["refundable"].includes(i)) continue;
              if(!listingHelper.global.classTypeColumns["business"].includes(i) || listingHelper.global.rateTypeColumns["refundable"].includes(i)) continue;
            }
            if(configuration.parameters().searchClassType() == enums.classTypeEnum.FIRST.value)
            {
              if (configuration.parameters().isRefundable() && !listingHelper.global.rateTypeColumns["refundable"].includes(i)) continue;
              if(!listingHelper.global.classTypeColumns["first"].includes(i) || listingHelper.global.rateTypeColumns["refundable"].includes(i)) continue;
            }
          }
          let elementPrice = await browserPage.evaluate((element) => {
            return Promise.resolve(element.innerText.replace(/[^0-9\.]+/g,""));
          }, clickElements[i]);
          if (parseInt(outboundSelectedArray.value) == 0 || parseFloat(outboundSelectedArray.value) > parseFloat(elementPrice)){
            outboundSelectedArray.rowIndex = index;
            outboundSelectedArray.columnIndex = i;
            outboundSelectedArray.value = parseFloat(elementPrice);
          }
        }
      }
    }
  }
  if (outboundSelectedArray.rowIndex == 0 && outboundSelectedArray.value == 0) throw new botError.ClosedCase("No outbound found.");
  return outboundSelectedArray;
}

/**
* This method handles the click type of selector for Outbound items.
*
* @param {object}      browserPage        The browser page object.
* @param {object}      parentElement      The object under which the selector would be found.
* @param {boolean}     searchInPage       The boolean value specifying if parent is to be ignored.
* @param {selector}    tag                The selector which is to be evaluated.
* @param {object}      response           The response class object.
* @param {object}      page               The page class object.
* @param {object}      configuration      The configuration class object.
* @param {object}      monitoring         The monitoring class object.
* @param {object}      logger             The logger object.
*
* @return None.
*/
async function handleOutboundClick(browserPage, parentElement, searchInPage, tag, page, configuration, response, monitoring, logger, session, outboundArray){
  if (tag.action() == enums.tagTypeEnums.get("click").value)
  {
    let objectName = "outbound>price>classType";
    let airlineClassType = "outbound>price>airlineClassType";
    let clickElements = [];
    if (searchInPage){
      clickElements = await tag.elements(browserPage, monitoring, parentElement);
    }else{
      clickElements = await tag.elements(browserPage, monitoring, null);
    }
    var clickElementsLength = clickElements.length;
    let indexes = [];
    if (tag.applyBusinessRules()){
      indexes.push(outboundArray.columnIndex);
      for(let key in listingHelper.global.rateTypeColumns)
      {
        if (listingHelper.global.rateTypeColumns[key].includes(outboundArray.columnIndex)) priceType = key;
      }
    }else{
      indexes = Array(clickElementsLength - 0 ).fill().map((_, idx) => 0 + idx);
    }
    for (let i of indexes){
      if (tag.applyBusinessRules()){
        if(configuration.parameters().searchClassType() == enums.classTypeEnum.ECONOMY.value)
        {
          if (i in listingHelper.global.columnsNameIndexMapping){
            listingHelper.mapData(airlineClassType, listingHelper.global.columnsNameIndexMapping[i], configuration, configuration.isCombined());
          }
          listingHelper.mapData(objectName, enums.classTypeGroupEnum.get("E").value, configuration, configuration.isCombined());
        }
        if(configuration.parameters().searchClassType() == enums.classTypeEnum.PREMIUMECONOMY.value)
        {
          if (i in listingHelper.global.columnsNameIndexMapping){
            listingHelper.mapData(airlineClassType, listingHelper.global.columnsNameIndexMapping[i], configuration, configuration.isCombined());
          }
          listingHelper.mapData(objectName, enums.classTypeGroupEnum.get("PE").value, configuration, configuration.isCombined());
        }
        if(configuration.parameters().searchClassType() == enums.classTypeEnum.BUSINESS.value)
        {
          if (i in listingHelper.global.columnsNameIndexMapping){
            listingHelper.mapData(airlineClassType, listingHelper.global.columnsNameIndexMapping[i], configuration, configuration.isCombined());
          }
          listingHelper.mapData(objectName, enums.classTypeGroupEnum.get("B").value, configuration, configuration.isCombined());
        }
        if(configuration.parameters().searchClassType() == enums.classTypeEnum.FIRST.value)
        {
          if (i in listingHelper.global.columnsNameIndexMapping){
            listingHelper.mapData(airlineClassType, listingHelper.global.columnsNameIndexMapping[i], configuration, configuration.isCombined());
          }
          listingHelper.mapData(objectName, enums.classTypeGroupEnum.get("F").value, configuration, configuration.isCombined());
        }
      }
      await browserPage.evaluate(el => {
        setTimeout(function() {
          el.click();
        }, 2000);
      }, clickElements[i]);
      await browserPage.waitFor(3000);
      if (tag.waitSelector())
      {
        while((await browserPage.$$(tag.waitSelector())).length > 0)
        {
          await browserPage.waitFor(10000);
        }
      }
      await browserPage.waitFor(3000);
      if (tag.raise() && tag.raise() == "screenshot"){
        var imageName = "detailsScreen-" + configuration.requestDetailId() + "-" + Math.floor((Math.random() * 1000) + 1).toString() + ".png";
        listingHelper.global.cacheUrl = await helper.captureAndUploadScreenshot(browserPage, configuration, imageName);
        listingHelper.global.index += 1;
      }
      if (tag.linked())
      {
        let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.linked());
        await searchPatternSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session);
      }
      if (tag.event()){
        let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.event());
        await searchPatternSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session);
      }
      if (tag.raise() && tag.raise() == "flush"){
        responseHelper.flush(response, configuration.parameters().isRoundtrip(), configuration.isCombined());
      }
    }
  }
}

/**
* This method handles the click type of selector for Inbound items.
*
* @param {object}      browserPage        The browser page object.
* @param {object}      parentElement      The object under which the selector would be found.
* @param {boolean}     searchInPage       The boolean value specifying if parent is to be ignored.
* @param {selector}    tag                The selector which is to be evaluated.
* @param {object}      response           The response class object.
* @param {object}      page               The page class object.
* @param {object}      configuration      The configuration class object.
* @param {object}      monitoring         The monitoring class object.
* @param {object}      logger             The logger object.
*
* @return None.
*/
async function handleInboundClick(browserPage, parentElement, searchInPage, tag, page, configuration, response, monitoring, logger, session, inboundArray){
  if (tag.action() == enums.tagTypeEnums.get("click").value)
  {
    let objectName = "inbound>price>classType";
    let airlineClassType = "inbound>price>airlineClassType";
    let clickElements = [];
    if (searchInPage){
      clickElements = await tag.elements(browserPage, monitoring, parentElement);
    }else{
      clickElements = await tag.elements(browserPage, monitoring, null);
    }

    let indexes = [];
    var clickElementsLength = clickElements.length;
    if (tag.applyBusinessRules()){
      indexes.push(inboundArray.columnIndex);
    }else{
      indexes = Array(clickElementsLength - 0 ).fill().map((_, idx) => 0 + idx);
    }
    for (let i of indexes){
      if (tag.applyBusinessRules()){
        if(configuration.parameters().searchClassType() == enums.classTypeEnum.ECONOMY.value)
        {
          if (i in listingHelper.global.columnsNameIndexMapping){
            listingHelper.mapData(airlineClassType, listingHelper.global.columnsNameIndexMapping[i], configuration, configuration.isCombined());
          }
          listingHelper.mapData(objectName, enums.classTypeGroupEnum.get("E").value, configuration, configuration.isCombined());
        }
        if(configuration.parameters().searchClassType() == enums.classTypeEnum.PREMIUMECONOMY.value)
        {
          if (i in listingHelper.global.columnsNameIndexMapping){
            listingHelper.mapData(airlineClassType, listingHelper.global.columnsNameIndexMapping[i], configuration, configuration.isCombined());
          }
          listingHelper.mapData(objectName, enums.classTypeGroupEnum.get("PE").value, configuration, configuration.isCombined());
        }
        if(configuration.parameters().searchClassType() == enums.classTypeEnum.BUSINESS.value)
        {
          if (i in listingHelper.global.columnsNameIndexMapping){
            listingHelper.mapData(airlineClassType, listingHelper.global.columnsNameIndexMapping[i], configuration, configuration.isCombined());
          }
          listingHelper.mapData(objectName, enums.classTypeGroupEnum.get("B").value, configuration, configuration.isCombined());
        }
        if(configuration.parameters().searchClassType() == enums.classTypeEnum.FIRST.value)
        {
          if (i in listingHelper.global.columnsNameIndexMapping){
            listingHelper.mapData(airlineClassType, listingHelper.global.columnsNameIndexMapping[i], configuration, configuration.isCombined());
          }
          listingHelper.mapData(objectName, enums.classTypeGroupEnum.get("F").value, configuration, configuration.isCombined());
        }
      }
      await browserPage.evaluate(el => {
        setTimeout(function() {
          el.click();
        }, 2000);
      }, clickElements[i]);
      await browserPage.waitFor(3000);
      if (tag.waitSelector())
      {
        while((await browserPage.$$(tag.waitSelector())).length > 0)
        {
          await browserPage.waitFor(10000);
        }
      }
      await browserPage.waitFor(3000);
      if (tag.raise() && tag.raise() == "screenshot"){
        var imageName = "detailsScreen-" + configuration.requestDetailId() + "-" + Math.floor((Math.random() * 1000) + 1).toString() + ".png";
        listingHelper.global.cacheUrl = await helper.captureAndUploadScreenshot(browserPage, configuration, imageName);
        listingHelper.global.index += 1;
      }
      if (tag.linked())
      {
        let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.linked());
        await searchPatternSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session);
      }
      if (tag.event()){
        let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.event());
        await searchPatternSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session);
      }
      if (tag.raise() && tag.raise() == "flush"){
        responseHelper.flush(response, configuration.parameters().isRoundtrip(), configuration.isCombined());
      }
    }
  }
}

/**
 * This method handles the click type of selector.
 *
 * @param {object}      browserPage        The browser page object.
 * @param {object}      parentElement      The object under which the selector would be found.
 * @param {boolean}     searchInPage       The boolean value specifying if parent is to be ignored.
 * @param {selector}    tag                The selector which is to be evaluated.
 * @param {object}      response           The response class object.
 * @param {object}      page               The page class object.
 * @param {object}      configuration      The configuration class object.
 * @param {object}      monitoring         The monitoring class object.
 * @param {object}      logger             The logger object.
 *
 * @return None.
 */
async function handleClick(browserPage, parentElement, searchInPage, tag, page, configuration, response, monitoring, logger, session){
  if (tag.action() == enums.tagTypeEnums.get("click").value)
  {
    let clickElements = [];
    if (searchInPage){
      clickElements = await tag.elements(browserPage, monitoring, parentElement);
    }else{
      clickElements = await tag.elements(browserPage, monitoring, null);
    }
    var clickElementsLength = clickElements.length;
    let arr = Array(clickElementsLength - 0 ).fill().map((_, idx) => 0 + idx);
    for (let i of arr){
      if (searchInPage){
        clickElements = await tag.elements(browserPage, monitoring, parentElement);
      }else{
        clickElements = await tag.elements(browserPage, monitoring, null);
      }
      if (tag.ignoreValue())
      {
        if ((await(await clickElements[i].getProperty('className')).jsonValue()).indexOf(tag.ignoreValue()) > -1) continue;
      }
      await browserPage.evaluate(el => {
        setTimeout(function() {
          el.click();
        }, 2000);
      }, clickElements[i]);
      await browserPage.waitFor(3000);
      if (listingHelper.global.isRequestFailed) throw new botError.ProxyError(`Proxy ${configuration.proxy().UserId} got 405 Status code response.`);
      if (tag.waitSelector())
      {
        while((await browserPage.$$(tag.waitSelector())).length > 0)
        {
          await browserPage.waitFor(10000);
        }
      }
      await browserPage.waitFor(3000);
      if (tag.raise() && tag.raise() == "screenshot"){
        var imageName = "detailsScreen-" + configuration.requestDetailId() + "-" + Math.floor((Math.random() * 1000) + 1).toString() + ".png";
        listingHelper.global.cacheUrl = await helper.captureAndUploadScreenshot(browserPage, configuration, imageName);
      }
      if (tag.linked())
      {
        let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.linked());
        await searchPatternSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session);
      }
      if (tag.event()){
        let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.event());
        await searchPatternSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session);
      }
      if (tag.raise() && tag.raise() == "flush"){
        responseHelper.flush(response, configuration.parameters().isRoundtrip(), configuration.isCombined());
      }
    }
  }
}

module.exports = {searchPatternSelectionInfo};
