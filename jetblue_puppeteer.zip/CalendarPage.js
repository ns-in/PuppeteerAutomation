var base = require('./BasePage.js');
var enums = require('./Enums.js');
var helper = require('./helper.js');
var botError = require('./BotError.js');

var CalendarPage = base.BaseCrawlPage.subclass();

CalendarPage.prototype._setInput = async function(browserPage, page, configuration, response, monitoring, logger, session){
  console.log("calendar set input");
  logger.Info = "SetInput completed on Calendar page.";
};
CalendarPage.prototype._getInfo = async function(browserPage, page, configuration, response, monitoring, logger, session){
  return new Promise(async function(resolve, reject) {
    let _closedTags = page.tagsList().filter(tag => (tag.parent() == null && tag.action() == enums.tagTypeEnums.get("closed").value));
    for (var _closedTag of _closedTags)
    {
      let value = await _closedTag.value(browserPage, monitoring);
      if (value) response.setAvailability = 'C';
    }
    resolve("success");
  });
  let _errorTags = page.tagsList().filter(tag => (tag.parent() == null && tag.action() == enums.tagTypeEnums.get("error").value));
  for (var _errorTag of _errorTags)
  {
    let value = await _errorTag.value(browserPage, monitoring);
    if (value) throw new botError.WebsiteError("Website gave an error page.");
  }
  logger.Info = "GetInfo completed on calendar page.";
};

CalendarPage.prototype._navigate = async function(browserPage, page, configuration, response, monitoring, logger, session){
  logger.Info = "Availability value before navigation from calendar page is " + response.availability;
  if (response.availability) return;
  if (page.action() == enums.actionEnums.get("click").value){
    let navigationElement = await page.actionSelector().element(browserPage, monitoring);
    console.log("clicking next to listing");
    await browserPage.waitFor(5000);
    await browserPage.evaluate(el => {
      el.click();
    }, navigationElement);
    //await navigationElement.click({delay:1000});
    await browserPage.waitForNavigation({waitUntil: ['domcontentloaded', 'networkidle0'], timeout: 120000});
    await browserPage.waitFor(7000);
  }
  logger.Info = "Navigate completed on calendar page.";
};

module.exports = {CalendarPage};
