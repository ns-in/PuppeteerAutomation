/// find all the div having the datepicker using $( "div[class*='hasDatepicker']" )
/// then find the one which is currently shown as class style will be show:block
/// then look for the From datepicker calendar which will have it in it's name  as $("div[class*='hasDatepicker']")[0].className
/// then get to the table child node which is housing the calendar dates
/// then put the table html in variable and run a queryselector for intended date and perform click
/// NOTE: This has to be repeated for the retrun date calendar all, after moving focus to the return input box.

var monthsLongNameArray = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];
var monthsShortNameArray = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];

function findGivenDateControl(configDateValue) {
    //get the specified date from the request
    var givenDate = new Date(configDateValue);
    //debug
    console.log("Date to search: " + givenDate);
    try {
        var lookupMonthDataControl = traverseAndGetCalendarControl(configDateValue);
        //debug
        if (lookupMonthDataControl == null) {
            console.log('unable to find');
        }else if(lookupMonthDataControl == "closed"){
            return "closed";
        }
        else {
          console.log("inside else");
          console.log(lookupMonthDataControl);
            var currentDates = lookupMonthDataControl.querySelectorAll('table > tbody > tr > td.selectable-day');
            console.log(currentDates.length);
            var selectedDateControl;
            for (let currentDate of  currentDates) {
                var anchor = currentDate.innerText.trim();
                console.log(anchor);
                console.log(givenDate.getDate());
                if (anchor != "") {
                    if (anchor == givenDate.getDate()) {
                        selectedDateControl = currentDate;
                        currentDate.click();
                        break;
                    }
                }
            }
        }
        //Return the selected Date control back for clicking
        return selectedDateControl;
    }
    catch (error) {
      console.log(error);
        console.log("Error occured in calendar script.Manually filling dates.");
        return null;
    }
}

//private helper method
function traverseAndGetCalendarControl(configDateValue) {
    var lookupMonthDataControl = null;
    var loopingCounter = 0;
    while (true) {
        loopingCounter++;
        //get the specified date from the request
        var givenDate = new Date(configDateValue),
            locale = "en-us",
            longMonthName = givenDate.toLocaleString(locale, {
                month: "long"
            }).split(" ")[0],
            shortMonthName = givenDate.toLocaleString(locale, {
                month: "short"
            }).split(" ")[0].substring(0, 3);

        var monthIndex = givenDate.getMonth();
        console.log("Month Index :" + monthIndex);
        // var givenMonthLongNameIndex = monthsLongNameArray.indexOf(longMonthName.trim().toLowerCase());
        // var givenMontShorthNameIndex = monthsShortNameArray.indexOf(shortMonthName.trim().toLowerCase());

        var givenMonthLongNameIndex = monthIndex;
        var givenMontShorthNameIndex = monthIndex;

        longMonthName = monthsLongNameArray[monthIndex];
        console.log("Long Month Name :" + longMonthName);
        shortMonthName = monthsShortNameArray[monthIndex];
        console.log("Short Month Name :" + shortMonthName);
        if (longMonthName == "" || shortMonthName == "") {
            console.log("Invalid Month Name.");
            retrun;
        }

        //Get the current month
        var currentTableMonthDataControls = document.querySelectorAll(".date-picker-height > div > div > jb-month-viewer > div");
        var calMonths = document.querySelectorAll(".date-picker-height > div > div > jb-month-viewer > div");
        var calMonthYearSelector = null;
        var currentTableMonthDataControl = null;
        for (let month of calMonths){
          if (month.hasAttribute('hidden')) continue;
          currentTableMonthDataControl= month;
          calMonthYearSelector = month.querySelector('div').innerText.trim().split(" ");
          break;
        }
        console.log(calMonthYearSelector);
        var currentMonth = calMonthYearSelector[0];
        var currentMonthLongNameIndex = monthsLongNameArray.indexOf(currentMonth.trim().toLowerCase());
        var currentMonthShortNameIndex = monthsShortNameArray.indexOf(currentMonth.trim().substring(0, 3).toLowerCase());
        //Get the year
        var currentYear = calMonthYearSelector[1];
        //Get the Prev Month control to traverse the calendar months --> this is very important as the phantom web driver has a cache page, so if the previous
        //request was in future, and the current request is present, then we have to move to the current month using the previous page control
        var prevPageControl = document.querySelector(".prev-month-button > button");

        var nextPageControl = document.querySelector(".next-month-button > button");
        if(nextPageControl.className.includes("disabled")) return "closed";
        //debug
        console.log("current month long name given Index:" + currentMonthLongNameIndex + " current month short name Index:" + currentMonthShortNameIndex);
        //console.log("next month long name given Index:" + nextMonthLongNameIndex + " next month short name Index:" + nextShortLongNameIndex);
        console.log("Sdf" + givenMonthLongNameIndex + "   " + givenMontShorthNameIndex);
        console.log(currentYear);
        console.log(givenDate.getFullYear());
        //console.log("current month:" + currentMonth.trim().toLowerCase() + "  next month:" + nextMonth.trim().toLowerCase() + " long given month:" + longMonthName.trim().toLowerCase() + " short given month:" + shortMonthName.trim().toLowerCase());
        if ((currentMonthLongNameIndex > givenMonthLongNameIndex || currentMonthShortNameIndex > givenMontShorthNameIndex) && (currentYear == givenDate.getFullYear())) {
            //debug
            debugger;
            console.log("need to go back in the calendar");
            if (prevPageControl != null) {
                prevPageControl.click();
            }
            if (loopingCounter == 10) {
                break;
            }
        }
        else {
           /* {
                console.log("currentMonth.trim().toLowerCase():"+currentMonth.trim().toLowerCase() )
                console.log("longMonthName.trim().toLowerCase():"+longMonthName.trim().toLowerCase())
                console.log("currentMonth.trim().toLowerCase():"+currentMonth.trim().toLowerCase() )
                console.log("shortMonthName.trim().toLowerCase():"+shortMonthName.trim().toLowerCase() )
                console.log("currentYear:"+currentYear )
                console.log("givenDate.getFullYear():"+givenDate.getFullYear())
            }*/
            if ((currentMonth.trim().toLowerCase() == longMonthName.trim().toLowerCase() || currentMonth.trim().toLowerCase() == shortMonthName.trim().toLowerCase()) && currentYear >= givenDate.getFullYear()) 
            {
                //debug
                console.log("current month :" + currentMonth);
                lookupMonthDataControl = currentTableMonthDataControl;
                break;
            }
            else if (lookupMonthDataControl == null) {
                //move to the next two months, in total we are going 6 months in future
                //don't want to loop more than 3 times.. as that's an invalid date duration
                //debug;
                console.log("looping to next calendar : " + loopingCounter);
                if (nextPageControl != null) {
                    nextPageControl.click();
                }
                if (loopingCounter == 10) {
                    break;
                }
            }
        }
    }
    return lookupMonthDataControl;
}
findGivenDateControl("06/18/2020");
