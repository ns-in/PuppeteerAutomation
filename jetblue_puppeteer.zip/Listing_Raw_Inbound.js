var base = require('./BasePage.js');
var enums = require('./Enums.js');
var responseHelper = require('./ResponseHelper.js');
var helper = require('./helper.js');
var index = 1;
var cacheUrl = null;
var cheapestSelected = false;
var cheapestSelectedInbound = false;

/**
 * This method handles traversal of the selectors to extract values.
 *
 * @param {object}      browserPage        The browser page object.
 * @param {object}      page               The page class object.
 * @param {object}      configuration      The configuration class object.
 * @param {object}      response           The response class object.
 * @param {object}      monitoring         The monitoring class object.
 * @param {object}      logger             The logger object.
 * @param {array}       parentTags         The list of selectors.
 * @param {object}      elementHandle      The current select dom object.
 *
 * @return None.
 */
async function rawInboundSelectionInfo(browserPage, page, configuration, response, monitoring, logger, parentTags, elementHandle=null){
  for (var _tag of parentTags)
  {
    await browserPage.waitFor(500);
    let childTags = [];
    let searchInPage = true;
    if ([enums.tagTypeEnums.get("select").value, enums.tagTypeEnums.get("linked").value].includes(_tag.action()))
    {
      childTags = page.tagsList().filter(tag => tag.parent() == _tag.name() && !tag.isLinked());
    }else{
      searchInPage = false;
      childTags = page.tagsList().filter(tag => tag.name() == _tag.name());
    }
    console.log("");
    console.log("parent "+_tag.name());
    let parentElements = await _tag.elements(browserPage, monitoring, elementHandle);
    console.log("parent tag elements : ", parentElements.length);
    console.log("child tags ", childTags.length);
    for (let _childTag of childTags){
      console.log("child: " + _childTag.name());
    }
    console.log("");
    for(let parentElement of parentElements){
      if(_tag.classIndicator()){
        console.log("checking class indicator");
        let classValue = await browserPage.evaluate((ci, pa)=>{
          let value = pa.querySelector(ci).innerText;
          return Promise.resolve(value);
        }, _tag.classIndicator(), parentElement);
        console.log("class value: ", classValue);
      }
      if (_tag.ignoreValue())
      {
        console.log("in ignore value");
        console.log("tag ignore value: ", _tag.ignoreValue());
        let ignoreCheck = await browserPage.evaluate((ignoreClass, pa)=>{
          let len = pa.querySelectorAll(ignoreClass).length;
          let ele = pa.querySelector(ignoreClass)
          if(ele){
            var style = window.getComputedStyle(ele);
            if(style.display == 'none') return Promise.resolve(false);
            return Promise.resolve(true);
          }
          return Promise.resolve(false);
        }, _tag.ignoreValue(), parentElement);
        console.log("ignoreCheck: ", ignoreCheck);
        console.log("");
        if(ignoreCheck){
          console.log("ignoring element");
          continue;
        }
      }
      for (let _childTag of childTags){
        if (_childTag.applyBusinessRules()){
          if (_childTag.flightType() == "outbound" && cheapestSelected && !configuration.parameters().isRawReport()) continue;
          if (_childTag.flightType() == "inbound" && cheapestSelectedInbound && !configuration.parameters().isRawReport()) continue;
        }
        console.log("parent "+_tag.name());
        console.log("child "+_childTag.name());
        console.log("");
        await handleSelect(browserPage, parentElement, _childTag, page, configuration, response, monitoring, logger, searchInPage);
        await handleClick(browserPage, parentElement, searchInPage, _childTag, page, configuration, response, monitoring, logger);
        await handleExtract(browserPage, parentElement, _childTag, page, configuration, response, monitoring, logger);
        console.log("executed tag");
        console.log("");
      }
      if(_tag.execute()){
        console.log("in execute");
        let executeTag = page.tagsList().filter(tag => tag.name() == _tag.execute())[0];
        console.log("Executing ", executeTag.name());
        console.log("element handle parent: ",_tag.parent());
        await browserPage.evaluate(( at, ha)=>{
          console.log(at["ByClass"]);
          console.log(ha);
          let ex = ha.querySelector(at["ByClass"]);
          console.log(ex);
          ex.click();
        }, executeTag._attributes, elementHandle);
        browserPage.waitFor(10000);
        // if (executeTag.action() == enums.tagTypeEnums.get("click").value){
        //   executeElement.click({delay:500});
        // }
      }
      if (_tag.raise() && _tag.raise() == "flush.flightdetails"){
        console.log("flushing outbound flight details ", _tag.name());
        responseHelper.flushFlightDetails(response);
      }
      if (_tag.raise() && _tag.raise() == "flush.flightdetailsInbound"){
        console.log("flushing inbound flight details ", _tag.name());
        responseHelper.flushFlightDetailsInbound(response);
      }
    }
  }
}

/**
 * This method handles the select type of selector used for navigating into the dom tree.
 *
 * @param {object}      browserPage        The browser page object.
 * @param {object}      parentElement      The object under which the selector would be found.
 * @param {selector}    tag                The selector which is to be evaluated.
 * @param {object}      response           The response class object.
 * @param {object}      page               The page class object.
 * @param {object}      configuration      The configuration class object.
 * @param {object}      monitoring         The monitoring class object.
 * @param {object}      logger             The logger object.
 *
 * @return None.
 */
async function handleSelect(browserPage, parentElement, tag, page, configuration, response, monitoring, logger, searchInPage){
  if ([enums.tagTypeEnums.get("select").value].includes(tag.action())){
    if (tag.raise() && tag.raise() == "screenshot"){
      var detailsScreen = await browserPage.screenshot({
          fullPage: true,
          omitBackground: true
      });
      var imageName = "detailsScreen-" + configuration.requestDetailId() + "-" + index.toString() + ".png";
      cacheUrl = await helper.uploadCache(detailsScreen, imageName, configuration.customerId(), configuration.apiEndpoints().CachePageServiceUrl);
      index += 1;
    }
    console.log("in handle select");
    await rawInboundSelectionInfo(browserPage, page, configuration, response, monitoring, logger, [tag], parentElement);
    if (tag.linked())
    {
      console.log("going to linked tag");
      if (tag.raise() && tag.raise() == "screenshot"){
        await browserPage.waitFor(2500);
        var detailsScreen = await browserPage.screenshot({
            fullPage: true,
            omitBackground: true
        });
        var imageName = "detailsScreen-" + configuration.requestDetailId() + "-" + index.toString() + ".png";
        cacheUrl = await helper.uploadCache(detailsScreen, imageName, configuration.customerId(), configuration.apiEndpoints().CachePageServiceUrl);
        index += 1;
      }
      let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.linked());
      let parentElementHandle = null;
      if (subChildTags.length > 0 && subChildTags[0].isLinked())
      {
        //console.log("assinging parent element handle to ", subChildTags[0].name());
        parentElementHandle = parentElement;
      }
      await rawInboundSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, parentElementHandle);
    }
    if (tag.event()){
      let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.event());
      await rawInboundSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags);
    }
    if (tag.raise() && tag.raise() == "flush"){
      console.log("flushing flight ", tag.name());
      responseHelper.flush(response, configuration.parameters().isRoundtrip());
    }
    else if(tag.raise() && tag.raise() == "flush.priceInbound"){
      console.log("flushing price ", tag.name());
      responseHelper.flushPriceDetailsInbound();
    }
  }
}

/**
 * This method handles the click type of selector.
 *
 * @param {object}      browserPage        The browser page object.
 * @param {object}      parentElement      The object under which the selector would be found.
 * @param {boolean}     searchInPage       The boolean value specifying if parent is to be ignored.
 * @param {selector}    tag                The selector which is to be evaluated.
 * @param {object}      response           The response class object.
 * @param {object}      page               The page class object.
 * @param {object}      configuration      The configuration class object.
 * @param {object}      monitoring         The monitoring class object.
 * @param {object}      logger             The logger object.
 *
 * @return None.
 */
async function handleClick(browserPage, parentElement, searchInPage, tag, page, configuration, response, monitoring, logger){
  if (tag.action() == enums.tagTypeEnums.get("click").value)
  {
    console.log("click : "+tag.name());
    await browserPage.waitFor(1500);
    let clickElements = [];
    if (searchInPage){
      clickElements = await tag.elements(browserPage, monitoring, parentElement);
    }else{
      clickElements = await tag.elements(browserPage, monitoring, null);
    }
    var clickElementsLength = clickElements.length;
    console.log("click elements: "+ clickElementsLength);
    for (let i=0; i<clickElementsLength; i++){
      if (i > 0){
        console.log("Search in page: ", searchInPage);
        if (searchInPage){
          clickElements = await tag.elements(browserPage, monitoring, parentElement);
        }else{
          clickElements = await tag.elements(browserPage, monitoring, null);
        }
      }
      if (tag.ignoreValue())
      {
        if ((await(await clickElements[i].getProperty('className')).jsonValue()).indexOf(tag.ignoreValue()) > -1) continue;
      }
      if (!configuration.parameters().isRawReport() && tag.cheapestIndicator())
      {
        let isCheapest = await browserPage.evaluate((element, className) => {
          let len = element.querySelectorAll(className).length;
          if (len > 0) return Promise.resolve(true);
          return Promise.resolve(false);
        }, clickElements[i], tag.cheapestIndicator().match(/[^ ,]+/g).join('.'));
        if (!isCheapest) continue;
      }
      console.log("clicking element");
      await clickElements[i].focus();
      await browserPage.waitFor(1500);
      await browserPage.evaluate(el => {
        setTimeout(function() {
          el.click();
        }, 2000);
        console.log("clicked element");
        console.log(el);
      }, clickElements[i]);
      console.log("after click");
      console.log("");
      if (tag.flightType() == "inbound") cheapestSelectedInbound = true;
      if (tag.flightType() == "outbound") cheapestSelected = true;
      await browserPage.waitFor(3000);
      if (tag.waitSelector())
      {
        while((await browserPage.$$(tag.waitSelector())).length > 0)
        {
          await browserPage.waitFor(10000);
        }
      }
      await browserPage.waitFor(500);
      if (tag.linked())
      {
        if (tag.raise() && tag.raise() == "screenshot"){
          await browserPage.waitFor(2500);
          var detailsScreen = await browserPage.screenshot({
              fullPage: true,
              omitBackground: true
          });
          var imageName = "detailsScreen-" + configuration.requestDetailId() + "-" + index.toString() + ".png";
          cacheUrl = await helper.uploadCache(detailsScreen, imageName, configuration.customerId(), configuration.apiEndpoints().CachePageServiceUrl);
          index += 1;
        }
        let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.linked());
        let parentElementHandle = null;
        if (subChildTags.length > 0 && subChildTags[0].isLinked())
        {
          parentElementHandle = parentElement;
        }
        await rawInboundSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, parentElementHandle);
      }
      if (tag.event()){
        let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.event());
        await rawInboundSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags);
      }
      if (tag.raise() && tag.raise() == "flush"){
        console.log("flushing at ", tag.name());
        console.log("");
        responseHelper.flush(response, configuration.parameters().isRoundtrip());
      }
    } //
  }
}

/**
 * This method handles the extract type of selector and sets it to corresponding response object.
 *
 * @param {object}      browserPage        The browser page object.
 * @param {object}      parentElement      The object under which the selector would be found.
 * @param {selector}    tag                The selector which is to be evaluated.
 * @param {object}      response           The response class object.
 * @param {object}      page               The page class object.
 * @param {object}      configuration      The configuration class object.
 * @param {object}      monitoring         The monitoring class object.
 * @param {object}      logger             The logger object.
 *
 * @return None.
 */
async function handleExtract(browserPage, parentElement, tag, page, configuration, response, monitoring, logger){
  if (tag.action() == enums.tagTypeEnums.get("extractor").value){
    await extractData(browserPage, parentElement, tag, response, configuration, monitoring, logger);
    if (tag.linked())
    {
      let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.linked());
      await rawInboundSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags);
    }
  }
}

/**
 * This method fetches the tag value and sets it to corresponding response object.
 *
 * @param {object}      browserPage        The browser page object.
 * @param {object}      parentElement      The object under which the selector would be found.
 * @param {selector}    tag                The selector which is to be evaluated.
 * @param {object}      response           The response class object.
 * @param {object}      configuration      The configuration class object.
 * @param {object}      monitoring         The monitoring class object.
 * @param {object}      logger             The logger object.
 *
 * @return None.
 */
async function extractData(browserPage, parentElement, tag, response, configuration, monitoring, logger){
  let value = await tag.value(browserPage, monitoring, parentElement);
  console.log("extracted tag "+ tag.name()+ " value "+ value);
  if(tag.ignoreValue()){
    console.log("in ignore value");
    console.log(value);
    if(value){
      if(value.indexOf(tag.ignoreValue) == -1){
        responseHelper.mapValueToData(tag.objectName(), value, cacheUrl, configuration.parameters().isRoundtrip(), configuration.isCombined(), tag.expression());
      }
      else{
        console.log("ignoring element");
      }
    }
    else{
      console.log("value null: ignoring element");
    }
  }
  else{
    responseHelper.mapValueToData(tag.objectName(), value, cacheUrl, configuration.parameters().isRoundtrip(), configuration.isCombined(), tag.expression());
  }
}

module.exports = {rawInboundSelectionInfo};
