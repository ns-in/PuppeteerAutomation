var enums = require('./Enums.js');
var helper = require('./helper.js');
var listingHelper = require('./listing_helper.js');
var responseHelper = require('./ResponseHelper.js');

/**
* This method handles traversal of the selectors to extract values for specific
* number of rows for inbound and outbound.
*
* @param {object}      browserPage        The browser page object.
* @param {object}      page               The page class object.
* @param {object}      configuration      The configuration class object.
* @param {object}      response           The response class object.
* @param {object}      monitoring         The monitoring class object.
* @param {object}      logger             The logger object.
* @param {array}       parentTags         The list of selectors.
* @param {object}      elementHandle      The current select dom object.
*
* @return None.
*/
async function rawSpecificSelectionInfo(browserPage, page, configuration, response, monitoring, logger, parentTags, session, elementHandle=null){
  logger.Debug = "rawSpecificSelectionInfo method called.";
  await listingHelper.checkForWait(browserPage);
  for (var _tag of parentTags)
  {
    let childTags = null;
    let searchInPage = true;
    if ([enums.tagTypeEnums.get("select").value, enums.tagTypeEnums.get("linked").value].includes(_tag.action()))
    {
      childTags = page.tagsList().filter(tag => tag.parent() == _tag.name());
    }else{
      searchInPage = false;
      childTags = page.tagsList().filter(tag => tag.name() == _tag.name());
    }
    let parentElements = await _tag.elements(browserPage, monitoring, elementHandle);
    let inbounds = childTags.filter(tag => tag.flightType() == "inbound");
    let outbounds = childTags.filter(tag => tag.flightType() == "outbound");
    if (inbounds.length > 0){
      logger.Info = `Inbound length is ${inbounds.length}.`;
      parentElements = parentElements.slice(0,configuration.inboundItemsCount());
    }
    if (outbounds.length > 0){
      logger.Info = `Outbound length is ${outbounds.length}.`;
      parentElements = parentElements.slice(0,configuration.outboundItemsCount());
    }
    for(let [index, parentElement] of parentElements.entries()){
      for (let [cindex, _childTag] of childTags.entries()){
        if (_childTag.flightType() == "outbound"){
          if (!(index in session.outboundInboundItems)) session.outboundInboundItems[index] = {};
          listingHelper.global.outboundItem = index;
        }
        if (_childTag.flightType() == "inbound"){
          listingHelper.global.inboundItem = index;
        }
        await handleSelect(browserPage, parentElement, _childTag, page, configuration, response, monitoring, logger, session);
        if (_childTag.flightType() && ["outbound", "inbound"].includes(_childTag.flightType().toLowerCase())){
          await handleOutboundInboundClick(browserPage, parentElement, searchInPage, _childTag, page, configuration, response, monitoring, logger, session);
        }
        else{
          await handleClick(browserPage, parentElement, searchInPage, _childTag, page, configuration, response, monitoring, logger, session);
        }
        await listingHelper.handleExtract(browserPage, parentElement, _childTag, page, configuration, response, monitoring, logger, session);
      }
      if (_tag.raise() && _tag.raise() == "flush.flightdetails"){
        responseHelper.flushFlightDetails(response);
      }
      if (_tag.raise() && _tag.raise() == "flush.flightdetailsInbound"){
        responseHelper.flushFlightDetailsInbound(response);
      }
    }
  }
}

/**
* This method handles the select type of selector used for navigating into the dom tree.
*
* @param {object}      browserPage        The browser page object.
* @param {object}      parentElement      The object under which the selector would be found.
* @param {selector}    tag                The selector which is to be evaluated.
* @param {object}      response           The response class object.
* @param {object}      page               The page class object.
* @param {object}      configuration      The configuration class object.
* @param {object}      monitoring         The monitoring class object.
* @param {object}      logger             The logger object.
*
* @return None.
*/
async function handleSelect(browserPage, parentElement, tag, page, configuration, response, monitoring, logger, session){
  if ([enums.tagTypeEnums.get("select").value].includes(tag.action())){
    if (tag.raise() && tag.raise() == "screenshot"){
      var imageName = "detailsScreen-" + configuration.requestDetailId() + "-" + Math.floor((Math.random() * 1000) + 1).toString() + ".png";
      listingHelper.global.cacheUrl = await helper.captureAndUploadScreenshot(browserPage, configuration, imageName);
    }
    await rawSpecificSelectionInfo(browserPage, page, configuration, response, monitoring, logger, [tag], session, parentElement);
    if (tag.event()){
      let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.event());
      await rawSpecificSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session);
    }
    if (tag.raise() && tag.raise() == "flush"){
      responseHelper.flush(response, configuration.parameters().isRoundtrip(), configuration.isCombined());
    }
  }
}

/**
* This method handles the click type of selector for Outbound items.
*
* @param {object}      browserPage        The browser page object.
* @param {object}      parentElement      The object under which the selector would be found.
* @param {boolean}     searchInPage       The boolean value specifying if parent is to be ignored.
* @param {selector}    tag                The selector which is to be evaluated.
* @param {object}      response           The response class object.
* @param {object}      page               The page class object.
* @param {object}      configuration      The configuration class object.
* @param {object}      monitoring         The monitoring class object.
* @param {object}      logger             The logger object.
*
* @return None.
*/
async function handleOutboundInboundClick(browserPage, parentElement, searchInPage, tag, page, configuration, response, monitoring, logger, session){
  if (tag.action() == enums.tagTypeEnums.get("click").value)
  {
    let clickElements = [];
    if (searchInPage){
      clickElements = await tag.elements(browserPage, monitoring, parentElement);
    }else{
      clickElements = await tag.elements(browserPage, monitoring, null);
    }
    var clickElementsLength = clickElements.length;
    logger.Info = `Outbound length is ${outbounds.length}.`;
    if (clickElements.length == 0) return;
    let arr = Array(clickElementsLength - 0 ).fill().map((_, idx) => 0 + idx);
    let tempArray = {"index": 0, "value": 0};
    for (let i of arr){
      let elementPrice = await browserPage.evaluate((element) => {
        return Promise.resolve(element.innerText.replace(/[^0-9\.]+/g,""));
      }, clickElements[i]);
      if (parseInt(tempArray.value) == 0 || parseFloat(tempArray.value) > parseFloat(elementPrice)){
        tempArray.index = i;
        tempArray.value = parseFloat(elementPrice);
      }
    }
    if (tag.ignoreValue())
    {
      if ((await(await clickElements[tempArray.index].getProperty('className')).jsonValue()).indexOf(tag.ignoreValue()) > -1) return;
    }
    if (tag.flightType() == "inbound") {
      if ((listingHelper.global.inboundItem in session.outboundInboundItems[listingHelper.global.outboundItem][listingHelper.global.outboundColumnItem]) && (session.outboundInboundItems[listingHelper.global.outboundItem][listingHelper.global.outboundColumnItem][listingHelper.global.inboundItem].includes(tempArray.index))) return;
    }
    await browserPage.evaluate(el => {
      setTimeout(function() {
        el.click();
      }, 2000);
    }, clickElements[tempArray.index]);
    await browserPage.waitFor(3000);
    if (tag.flightType() == "inbound") {
      if (!(listingHelper.global.inboundItem in session.outboundInboundItems[listingHelper.global.outboundItem][listingHelper.global.outboundColumnItem])) session.outboundInboundItems[listingHelper.global.outboundItem][listingHelper.global.outboundColumnItem][listingHelper.global.inboundItem] = [];
      if (!(session.outboundInboundItems[listingHelper.global.outboundItem][listingHelper.global.outboundColumnItem][listingHelper.global.inboundItem].includes(tempArray.index))) session.outboundInboundItems[listingHelper.global.outboundItem][listingHelper.global.outboundColumnItem][listingHelper.global.inboundItem].push(tempArray.index);
    }
    if (tag.flightType() == "outbound") {
      if (!(tempArray.index in session.outboundInboundItems[listingHelper.global.outboundItem])) session.outboundInboundItems[listingHelper.global.outboundItem][tempArray.index] = {};
      listingHelper.global.outboundColumnItem = tempArray.index;
    }
    if (tag.waitSelector())
    {
      while((await browserPage.$$(tag.waitSelector())).length > 0)
      {
        await browserPage.waitFor(10000);
      }
    }
    await browserPage.waitFor(300);
    if (tag.linked())
    {
      if (tag.raise() && tag.raise() == "screenshot"){
        var imageName = "detailsScreen-" + configuration.requestDetailId() + "-" + Math.floor((Math.random() * 1000) + 1).toString() + ".png";
        listingHelper.global.cacheUrl = await helper.captureAndUploadScreenshot(browserPage, configuration, imageName);
        listingHelper.global.index += 1;
      }
      let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.linked());
      await rawSpecificSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session);
    }
    if (tag.event()){
      let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.event());
      await rawSpecificSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session);
    }
    if (tag.raise() && tag.raise() == "flush"){
      responseHelper.flush(response, configuration.parameters().isRoundtrip(), configuration.isCombined());
    }
  }
}

/**
* This method handles the click type of selector.
*
* @param {object}      browserPage        The browser page object.
* @param {object}      parentElement      The object under which the selector would be found.
* @param {boolean}     searchInPage       The boolean value specifying if parent is to be ignored.
* @param {selector}    tag                The selector which is to be evaluated.
* @param {object}      response           The response class object.
* @param {object}      page               The page class object.
* @param {object}      configuration      The configuration class object.
* @param {object}      monitoring         The monitoring class object.
* @param {object}      logger             The logger object.
*
* @return None.
*/
async function handleClick(browserPage, parentElement, searchInPage, tag, page, configuration, response, monitoring, logger, session){
  if (tag.action() == enums.tagTypeEnums.get("click").value)
  {
    let clickElements = [];
    if (searchInPage){
      clickElements = await tag.elements(browserPage, monitoring, parentElement);
    }else{
      clickElements = await tag.elements(browserPage, monitoring, null);
    }
    var clickElementsLength = clickElements.length;
    let arr = Array(clickElementsLength - 0 ).fill().map((_, idx) => 0 + idx);
    for (let i of arr){
      if (searchInPage){
        clickElements = await tag.elements(browserPage, monitoring, parentElement);
      }else{
        clickElements = await tag.elements(browserPage, monitoring, null);
      }
      if (tag.ignoreValue())
      {
        if ((await(await clickElements[i].getProperty('className')).jsonValue()).indexOf(tag.ignoreValue()) > -1) continue;
      }
      await browserPage.evaluate(el => {
        setTimeout(function() {
          el.click();
        }, 2000);
      }, clickElements[i]);
      await browserPage.waitFor(3000);
      if (listingHelper.global.isRequestFailed) throw new botError.ProxyError(`Proxy ${configuration.proxy().UserId} got 405 Status code response.`);
      if (tag.waitSelector())
      {
        while((await browserPage.$$(tag.waitSelector())).length > 0)
        {
          await browserPage.waitFor(10000);
        }
      }
      await browserPage.waitFor(300);
      if (tag.linked())
      {
        if (tag.raise() && tag.raise() == "screenshot"){
          var imageName = "detailsScreen-" + configuration.requestDetailId() + "-" + Math.floor((Math.random() * 1000) + 1).toString() + ".png";
          listingHelper.global.cacheUrl = await helper.captureAndUploadScreenshot(browserPage, configuration, imageName);
        }
        let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.linked());
        await rawSpecificSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session);
      }
      if (tag.event()){
        let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.event());
        await rawSpecificSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session);
      }
      if (tag.raise() && tag.raise() == "flush"){
        responseHelper.flush(response, configuration.parameters().isRoundtrip(), configuration.isCombined());
      }
    }
  }
}

module.exports = {rawSpecificSelectionInfo};
