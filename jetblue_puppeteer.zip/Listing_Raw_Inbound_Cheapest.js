var enums = require('./Enums.js');
var helper = require('./helper.js');
var listingHelper = require('./listing_helper.js');
var responseHelper = require('./ResponseHelper.js');

/**
* This method handles traversal of the selectors to extract values.
*
* @param {object}      browserPage        The browser page object.
* @param {object}      page               The page class object.
* @param {object}      configuration      The configuration class object.
* @param {object}      response           The response class object.
* @param {object}      monitoring         The monitoring class object.
* @param {object}      logger             The logger object.
* @param {array}       parentTags         The list of selectors.
* @param {object}      elementHandle      The current select dom object.
*
* @return None.
*/
async function rawCheapestSelectionInfo(browserPage, page, configuration, response, monitoring, logger, parentTags, session, elementHandle=null){
  await listingHelper.checkForWait(browserPage);
  for (var _tag of parentTags)
  {
    let childTags = null;
    let searchInPage = true;
    if ([enums.tagTypeEnums.get("select").value, enums.tagTypeEnums.get("linked").value].includes(_tag.action()))
    {
      childTags = page.tagsList().filter(tag => tag.parent() == _tag.name());
    }else{
      searchInPage = false;
      childTags = page.tagsList().filter(tag => tag.name() == _tag.name());
    }
    let parentElements = await _tag.elements(browserPage, monitoring, elementHandle);
    let inbounds = childTags.filter(tag => tag.flightType() == "inbound");
    let inboundSelectedArray = null;
    if (inbounds.length > 0){
        inboundSelectedArray = await getCheapestInbound(browserPage, searchInPage, parentElements, childTags, page, configuration, response, monitoring, logger, session);
    }
    for(let [index, parentElement] of parentElements.entries()){
      for (let [cindex, _childTag] of childTags.entries()){
        if (_childTag.flightType() == "outbound"){
          if (!(index in session.outboundInboundItems)) session.outboundInboundItems[index] = {};
          listingHelper.global.outboundItem = index;
        }
        await handleSelect(browserPage, parentElement, _childTag, page, configuration, response, monitoring, logger, session);
        if (_childTag.flightType() == "outbound"){
          await handleOutboundClick(browserPage, parentElement, searchInPage, _childTag, page, configuration, response, monitoring, logger, session);
        }
        else if (inbounds.length > 0 && _childTag.flightType() == "inbound"){
          if (index == inboundSelectedArray.rowIndex){
            await handleInboundClick(browserPage, parentElement, searchInPage, _childTag, page, configuration, response, monitoring, logger, session, inboundSelectedArray);
          }
        }else{
          await handleClick(browserPage, parentElement, searchInPage, _childTag, page, configuration, response, monitoring, logger, session);
        }
        await listingHelper.handleExtract(browserPage, parentElement, _childTag, page, configuration, response, monitoring, logger, session);
      }
      if (_tag.raise() && _tag.raise() == "flush.flightdetails"){
        responseHelper.flushFlightDetails(response);
      }
      if (_tag.raise() && _tag.raise() == "flush.flightdetailsInbound"){
        responseHelper.flushFlightDetailsInbound(response);
      }
    }
  }
}

/**
 * This method handles the select type of selector used for navigating into the dom tree.
 *
 * @param {object}      browserPage        The browser page object.
 * @param {object}      parentElement      The object under which the selector would be found.
 * @param {selector}    tag                The selector which is to be evaluated.
 * @param {object}      response           The response class object.
 * @param {object}      page               The page class object.
 * @param {object}      configuration      The configuration class object.
 * @param {object}      monitoring         The monitoring class object.
 * @param {object}      logger             The logger object.
 *
 * @return None.
 */
async function handleSelect(browserPage, parentElement, tag, page, configuration, response, monitoring, logger, session){
  if ([enums.tagTypeEnums.get("select").value].includes(tag.action())){
    if (tag.raise() && tag.raise() == "screenshot"){
      var imageName = "detailsScreen-" + configuration.requestDetailId() + "-" + Math.floor((Math.random() * 1000) + 1).toString() + ".png";
      listingHelper.global.cacheUrl = await helper.captureAndUploadScreenshot(browserPage, configuration, imageName);
    }
    await rawCheapestSelectionInfo(browserPage, page, configuration, response, monitoring, logger, [tag], session, parentElement);
    if (tag.event()){
      let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.event());
      await rawCheapestSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session);
    }
    if (tag.raise() && tag.raise() == "flush"){
      responseHelper.flush(response, configuration.parameters().isRoundtrip(), configuration.isCombined());
    }
  }
}

async function getCheapestInbound(browserPage, searchInPage, parentElements, childTags, page, configuration, response, monitoring, logger, session){
  let tempArray = {"rowIndex": 0,"columnIndex": 0, "value": 0};
  for(let [index, parentElement] of parentElements.entries()){
    for (let [cindex, _childTag] of childTags.entries()){
      await handleSelect(browserPage, parentElement, _childTag, page, configuration, response, monitoring, logger, session);
      if (_childTag.action() == enums.tagTypeEnums.get("click").value)
      {
        let clickElements = [];
        if (searchInPage){
          clickElements = await _childTag.elements(browserPage, monitoring, parentElement);
        }else{
          clickElements = await _childTag.elements(browserPage, monitoring, null);
        }
        var clickElementsLength = clickElements.length;
        let arr = Array(clickElementsLength - 0 ).fill().map((_, idx) => 0 + idx);
        for (let i of arr){
          let elementPrice = await browserPage.evaluate((element) => {
            return Promise.resolve(element.innerText.replace(/[^0-9\.]+/g,""));
          }, clickElements[i]);
          if (parseInt(tempArray.value) == 0 || parseFloat(tempArray.value) > parseFloat(elementPrice)){
            tempArray.rowIndex = index;
            tempArray.columnIndex = i;
            tempArray.value = parseFloat(elementPrice);
          }
        }
      }
    }
  }
  return tempArray;
}

/**
* This method handles the click type of selector for Outbound items.
*
* @param {object}      browserPage        The browser page object.
* @param {object}      parentElement      The object under which the selector would be found.
* @param {boolean}     searchInPage       The boolean value specifying if parent is to be ignored.
* @param {selector}    tag                The selector which is to be evaluated.
* @param {object}      response           The response class object.
* @param {object}      page               The page class object.
* @param {object}      configuration      The configuration class object.
* @param {object}      monitoring         The monitoring class object.
* @param {object}      logger             The logger object.
*
* @return None.
*/
async function handleOutboundClick(browserPage, parentElement, searchInPage, tag, page, configuration, response, monitoring, logger, session){
  if (tag.action() == enums.tagTypeEnums.get("click").value)
  {
    let clickElements = [];
    if (searchInPage){
      clickElements = await tag.elements(browserPage, monitoring, parentElement);
    }else{
      clickElements = await tag.elements(browserPage, monitoring, null);
    }
    var clickElementsLength = clickElements.length;
    let arr = Array(clickElementsLength - 0 ).fill().map((_, idx) => 0 + idx);
    let tempArray = {"index": 0, "value": 0};
    for (let i of arr){
      let elementPrice = await browserPage.evaluate((element) => {
        return Promise.resolve(element.innerText.replace(/[^0-9\.]+/g,""));
      }, clickElements[i]);
      if (parseInt(tempArray.value) == 0 || parseFloat(tempArray.value) > parseFloat(elementPrice)){
        tempArray.index = i;
        tempArray.value = parseFloat(elementPrice);
      }
    }
    console.log(tempArray);
    if (tag.ignoreValue())
    {
      if ((await(await clickElements[tempArray.index].getProperty('className')).jsonValue()).indexOf(tag.ignoreValue()) > -1) return;
    }
    if ((tempArray.index in session.outboundInboundItems[listingHelper.global.outboundItem])) return;
    await browserPage.evaluate(el => {
      setTimeout(function() {
        el.click();
      }, 2000);
    }, clickElements[tempArray.index]);
    await browserPage.waitFor(3000);
    if (!(tempArray.index in session.outboundInboundItems[listingHelper.global.outboundItem])) session.outboundInboundItems[listingHelper.global.outboundItem][tempArray.index] = {};
    listingHelper.global.outboundColumnItem = tempArray.index;
    if (tag.waitSelector())
    {
      while((await browserPage.$$(tag.waitSelector())).length > 0)
      {
        await browserPage.waitFor(10000);
      }
    }
    await browserPage.waitFor(300);
    if (tag.linked())
    {
      if (tag.raise() && tag.raise() == "screenshot"){
        var imageName = "detailsScreen-" + configuration.requestDetailId() + "-" + Math.floor((Math.random() * 1000) + 1).toString() + ".png";
        listingHelper.global.cacheUrl = await helper.captureAndUploadScreenshot(browserPage, configuration, imageName);
        listingHelper.global.index += 1;
      }
      let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.linked());
      await rawCheapestSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session);
    }
    if (tag.event()){
      let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.event());
      await rawCheapestSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session);
    }
    if (tag.raise() && tag.raise() == "flush"){
      responseHelper.flush(response, configuration.parameters().isRoundtrip(), configuration.isCombined());
    }
  }
}

/**
* This method handles the click type of selector for Inbound items.
*
* @param {object}      browserPage        The browser page object.
* @param {object}      parentElement      The object under which the selector would be found.
* @param {boolean}     searchInPage       The boolean value specifying if parent is to be ignored.
* @param {selector}    tag                The selector which is to be evaluated.
* @param {object}      response           The response class object.
* @param {object}      page               The page class object.
* @param {object}      configuration      The configuration class object.
* @param {object}      monitoring         The monitoring class object.
* @param {object}      logger             The logger object.
*
* @return None.
*/
async function handleInboundClick(browserPage, parentElement, searchInPage, tag, page, configuration, response, monitoring, logger, session, inboundArray){
  if (tag.action() == enums.tagTypeEnums.get("click").value)
  {
    let clickElements = [];
    if (searchInPage){
      clickElements = await tag.elements(browserPage, monitoring, parentElement);
    }else{
      clickElements = await tag.elements(browserPage, monitoring, null);
    }
    if (tag.ignoreValue())
    {
      if ((await(await clickElements[inboundArray.columnIndex].getProperty('className')).jsonValue()).indexOf(tag.ignoreValue()) > -1) return;
    }
    if ((listingHelper.global.inboundItem in session.outboundInboundItems[listingHelper.global.outboundItem][listingHelper.global.outboundColumnItem]) && (session.outboundInboundItems[listingHelper.global.outboundItem][listingHelper.global.outboundColumnItem][listingHelper.global.inboundItem].includes(inboundArray.columnIndex))) return;
    await browserPage.evaluate(el => {
      setTimeout(function() {
        el.click();
      }, 2000);
    }, clickElements[inboundArray.columnIndex]);
    await browserPage.waitFor(3000);
    if (tag.waitSelector())
    {
      while((await browserPage.$$(tag.waitSelector())).length > 0)
      {
        await browserPage.waitFor(10000);
      }
    }
    await browserPage.waitFor(300);
    if (tag.linked())
    {
      if (tag.raise() && tag.raise() == "screenshot"){
        var imageName = "detailsScreen-" + configuration.requestDetailId() + "-" + Math.floor((Math.random() * 1000) + 1).toString() + ".png";
        listingHelper.global.cacheUrl = await helper.captureAndUploadScreenshot(browserPage, configuration, imageName);
      }
      let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.linked());
      await rawCheapestSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session);
    }
    if (tag.event()){
      let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.event());
      await rawCheapestSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session);
    }
    if (tag.raise() && tag.raise() == "flush"){
      responseHelper.flush(response, configuration.parameters().isRoundtrip(), configuration.isCombined());
    }
  }
}

/**
 * This method handles the click type of selector.
 *
 * @param {object}      browserPage        The browser page object.
 * @param {object}      parentElement      The object under which the selector would be found.
 * @param {boolean}     searchInPage       The boolean value specifying if parent is to be ignored.
 * @param {selector}    tag                The selector which is to be evaluated.
 * @param {object}      response           The response class object.
 * @param {object}      page               The page class object.
 * @param {object}      configuration      The configuration class object.
 * @param {object}      monitoring         The monitoring class object.
 * @param {object}      logger             The logger object.
 *
 * @return None.
 */
async function handleClick(browserPage, parentElement, searchInPage, tag, page, configuration, response, monitoring, logger, session){
  if (tag.action() == enums.tagTypeEnums.get("click").value)
  {
    let clickElements = [];
    if (searchInPage){
      clickElements = await tag.elements(browserPage, monitoring, parentElement);
    }else{
      clickElements = await tag.elements(browserPage, monitoring, null);
    }
    var clickElementsLength = clickElements.length;
    let arr = Array(clickElementsLength - 0 ).fill().map((_, idx) => 0 + idx);
    for (let i of arr){
      if (searchInPage){
        clickElements = await tag.elements(browserPage, monitoring, parentElement);
      }else{
        clickElements = await tag.elements(browserPage, monitoring, null);
      }
      if (tag.ignoreValue())
      {
        if ((await(await clickElements[i].getProperty('className')).jsonValue()).indexOf(tag.ignoreValue()) > -1) continue;
      }
      await browserPage.evaluate(el => {
        setTimeout(function() {
          el.click();
        }, 2000);
      }, clickElements[i]);
      await browserPage.waitFor(3000);
      if (listingHelper.global.isRequestFailed) throw new botError.ProxyError(`Proxy ${configuration.proxy().UserId} got 405 Status code response.`);
      if (tag.waitSelector())
      {
        while((await browserPage.$$(tag.waitSelector())).length > 0)
        {
          await browserPage.waitFor(10000);
        }
      }
      await browserPage.waitFor(300);
      if (tag.linked())
      {
        if (tag.raise() && tag.raise() == "screenshot"){
          var imageName = "detailsScreen-" + configuration.requestDetailId() + "-" + Math.floor((Math.random() * 1000) + 1).toString() + ".png";
          listingHelper.global.cacheUrl = await helper.captureAndUploadScreenshot(browserPage, configuration, imageName);
        }
        let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.linked());
        await rawCheapestSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session);
      }
      if (tag.event()){
        let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.event());
        await rawCheapestSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session);
      }
      if (tag.raise() && tag.raise() == "flush"){
        responseHelper.flush(response, configuration.parameters().isRoundtrip(), configuration.isCombined());
      }
    }
  }
}

module.exports = {rawCheapestSelectionInfo};
