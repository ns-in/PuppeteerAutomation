var enums = require('./Enums.js');
var helper = require('./helper.js');
var listingHelper = require('./listing_helper.js');
var responseHelper = require('./ResponseHelper.js');
var isScreenshotTaken = false;
var classheadersSelected = false;
var isBoundIgnore = false;

/**
* This method handles traversal of the selectors to extract values for specific
* number of rows for inbound and outbound.
*
* @param {object}      browserPage        The browser page object.
* @param {object}      page               The page class object.
* @param {object}      configuration      The configuration class object.
* @param {object}      response           The response class object.
* @param {object}      monitoring         The monitoring class object.
* @param {object}      logger             The logger object.
* @param {array}       parentTags         The list of selectors.
* @param {object}      elementHandle      The current select dom object.
*
* @return None.
*/
async function rawReadSelectionInfo(browserPage, page, configuration, response, monitoring, logger, parentTags, session, elementHandle = null) {
  logger.Debug = "rawReadSelectionInfo method called.";
  //await listingHelper.checkForWait(browserPage);
  for (var _tag of parentTags) {
    let childTags = null;
    let searchInPage = true;
    if ([enums.tagTypeEnums.get("select").value, enums.tagTypeEnums.get("linked").value].includes(_tag.action())) {
      childTags = page.tagsList().filter(tag => tag.parent() == _tag.name() && tag.action() != "classFilter");
    } else {
      searchInPage = false;
      childTags = page.tagsList().filter(tag => tag.name() == _tag.name() && tag.action() != "classFilter");
    }
    let parentElements = await _tag.elements(browserPage, monitoring, elementHandle);
    if(_tag.name()=='outBoundFlightDetailsClickSelector'){
      logger.Info = "parentElements len 1:"+parentElements.length;
    }
    if(_tag.name()=='outboundDetailsSelector'){
      logger.Info = "parentElements len 2:"+parentElements.length;
    }
    if (!classheadersSelected) {
      classheadersSelected = await listingHelper.getClassHeaders(browserPage, monitoring, parentElements, childTags, configuration, classheadersSelected);
      if (classheadersSelected && listingHelper.global.classTypeColumns["economy"].length == 0 && listingHelper.global.classTypeColumns["premiumeconomy"].length == 0 && listingHelper.global.classTypeColumns["business"].length == 0 && listingHelper.global.classTypeColumns["first"].length == 0) {
        response.setAvailability = 'C';
        return;
      }
    }
    for (let [index, parentElement] of parentElements.entries()) {
      let childIgnoreTag = childTags.filter(ct => ct.ignoreValue() && ct._isRowIgnore == true);
      if (childIgnoreTag.length > 0) {
        childIgnoreTag = childIgnoreTag[0];
        let isIgnore = await getIfIgnore(browserPage, parentElement, searchInPage, childIgnoreTag, monitoring);
        if (isIgnore) {
          logger.Info = "isIgnore Continue Indexing:"+index;
          continue;
        }
      }
      for (let [cindex, _childTag] of childTags.entries()) {
        if (_childTag.flightType() == "outbound") {
          if (isBoundIgnore) {
            logger.Info = " isBoundIgnore Continue Indexing:"+index;
            continue;
          }
          if (!(index in session.outboundInboundItems)) session.outboundInboundItems[index] = {};
          listingHelper.global.outboundItem = index;
        }
        if (_childTag.flightType() == "inbound") {
          listingHelper.global.inboundItem = index;
        }
        if (_childTag.action() == enums.tagTypeEnums.get("select").value) {
          await handleSelect(browserPage, parentElement, _childTag, page, configuration, response, monitoring, logger, session);
        }
        if (_childTag.action() == enums.tagTypeEnums.get("click").value) {
          if (_childTag.flightType() && ["outbound", "inbound"].includes(_childTag.flightType().toLowerCase()) && _childTag.applyBusinessRules()) {
            await handleOutboundInboundClick(browserPage, parentElement, searchInPage, _childTag, page, configuration, response, monitoring, logger, session);
          }
          else {
            await handleClick(browserPage, parentElement, searchInPage, _childTag, page, configuration, response, monitoring, logger, session);
          }
        }
        if (_childTag.action() == enums.tagTypeEnums.get("extractor").value) {
          await listingHelper.handleExtract(browserPage, parentElement, _childTag, page, configuration, response, monitoring, logger, session);
        }
      }
      if (_tag.raise() && _tag.raise() == "flush.flightdetails") {
        logger.Info = "Flushing flight detail.";
        responseHelper.flushFlightDetails(response);
      }
      if (_tag.raise() && _tag.raise() == "flush.flightdetailsInbound") {
        responseHelper.flushFlightDetailsInbound(response);
      }
      if (_tag.raise() && _tag.raise() == "flush.pricedetails") {
        logger.Info = "Flushing price detail.";
        responseHelper.flushPriceDetails(response, true);
      }
      if (_tag.raise() && _tag.raise() == "flush.inboundpricedetails") {
        responseHelper.flushPriceDetailsInbound(true);
      }
      if (_tag.raise() && _tag.raise() == "screenshot") {
        if (!isScreenshotTaken) {
          var imageName = "detailsScreen-" + configuration.requestDetailId() + "-" + Math.floor((Math.random() * 1000) + 1).toString() + ".png";
          listingHelper.global.cacheUrl = await helper.captureAndUploadScreenshot(browserPage, configuration, imageName);
          listingHelper.global.index += 1;
          isScreenshotTaken = true;
        }
      }
      if (_tag.event()) {
        let subChildTags = page.tagsList().filter(tag => tag.name() == _tag.event());
        await rawReadSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session);
      }
      if (_tag.raise() && _tag.raise() == "flush.inbound") {
        responseHelper.flushInbound(response, false);
      }
      if (_tag.raiseRaw() && _tag.raiseRaw() == "flush.outbound") {
        logger.Info = "Flushing outbound detail.";
        responseHelper.flushOutbound(response, false);
      }
      if ((!_tag.raiseRaw()) && _tag.raise() == "flush") {
        logger.Info = "Flush detail rawReadSelectionInfo";
        responseHelper.flush(response, configuration.parameters().isRoundtrip(), true, true, manipulateDate = false);
      }
      //isBoundIgnore = false;
    }
  }
}

/**
* This method handles the select type of selector used for navigating into the dom tree.
*
* @param {object}      browserPage        The browser page object.
* @param {object}      parentElement      The object under which the selector would be found.
* @param {selector}    tag                The selector which is to be evaluated.
* @param {object}      response           The response class object.
* @param {object}      page               The page class object.
* @param {object}      configuration      The configuration class object.
* @param {object}      monitoring         The monitoring class object.
* @param {object}      logger             The logger object.
*
* @return None.
*/
async function handleSelect(browserPage, parentElement, tag, page, configuration, response, monitoring, logger, session) {
  if ([enums.tagTypeEnums.get("select").value].includes(tag.action())) {
    if (tag.raise() && tag.raise() == "screenshot") {
      if (!isScreenshotTaken) {
        var imageName = "detailsScreen-" + configuration.requestDetailId() + "-" + Math.floor((Math.random() * 1000) + 1).toString() + ".png";
        listingHelper.global.cacheUrl = await helper.captureAndUploadScreenshot(browserPage, configuration, imageName);
        isScreenshotTaken = true;
      }
    }
    await rawReadSelectionInfo(browserPage, page, configuration, response, monitoring, logger, [tag], session, parentElement);
    if (tag.linked()) {
      let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.linked());
      await rawReadSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session);
    }
    if (tag.raise() && tag.raise() == "flush.flightdetails") {
      logger.Info = "Flush detail flightDetail handel select";
      responseHelper.flushFlightDetails(response);
    }
    if (tag.raise() && tag.raise() == "flush.flightdetailsInbound") {
      responseHelper.flushFlightDetailsInbound(response);
    }
    if (tag.event()) {
      let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.event());
      await rawReadSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session, parentElement);
    }
  }
}

/**
* This method handles the click type of selector for Outbound items.
*
* @param {object}      browserPage        The browser page object.
* @param {object}      parentElement      The object under which the selector would be found.
* @param {boolean}     searchInPage       The boolean value specifying if parent is to be ignored.
* @param {selector}    tag                The selector which is to be evaluated.
* @param {object}      response           The response class object.
* @param {object}      page               The page class object.
* @param {object}      configuration      The configuration class object.
* @param {object}      monitoring         The monitoring class object.
* @param {object}      logger             The logger object.
*
* @return None.
*/
async function handleOutboundInboundClick(browserPage, parentElement, searchInPage, tag, page, configuration, response, monitoring, logger, session) {
  if (tag.action() == enums.tagTypeEnums.get("click").value) {
    let objectName = '';
    let airlineClassType = '';
    if (tag.flightType() == "inbound") {
      objectName = "inbound>price>classType";
      airlineClassType = "inbound>price>airlineClassType";
    }
    if (tag.flightType() == "outbound") {
      objectName = "outbound>price>classType";
      airlineClassType = "outbound>price>airlineClassType";
    }
    let clickElements = [];
    if (searchInPage) {
      clickElements = await tag.elements(browserPage, monitoring, parentElement);
    } else {
      clickElements = await tag.elements(browserPage, monitoring, null);
    }
    var clickElementsLength = clickElements.length;
    if (clickElementsLength == 0) isBoundIgnore = true;
    //let arr = Array(clickElementsLength - 0 ).fill().map((_, idx) => 0 + idx);
    for (let i = 0; i <= clickElementsLength - 1; i++) {
      let x = (await clickElements[i].$x('..'))[0];
      let y = (await x.$x('..'))[0];
      if (tag.ignoreValue()) {
        let ignore = false;
        for (let _ignoreValue of tag.ignoreValue().split(',')) {
          if ((await (await y.getProperty('className')).jsonValue()).indexOf(_ignoreValue.trim()) > -1) ignore = true;
        }
        if (ignore) {
          console.log("ignore continue");
          continue;
        }
      }
      if (classheadersSelected) {
        if (configuration.parameters().searchClassType() == enums.classTypeEnum.ECONOMY.value) {
          if (configuration.parameters().isRefundable() && !listingHelper.global.rateTypeColumns["refundable"].includes(i)) continue;
          if (!listingHelper.global.classTypeColumns["economy"].includes(i) || listingHelper.global.rateTypeColumns["refundable"].includes(i)) continue;
          if (i in listingHelper.global.columnsNameIndexMapping) {
            listingHelper.mapData(airlineClassType, listingHelper.global.columnsNameIndexMapping[i], configuration, configuration.isCombined());
          }
          listingHelper.mapData(objectName, enums.classTypeGroupEnum.get("E").value, configuration, configuration.isCombined());
        }
        else if (configuration.parameters().searchClassType() == enums.classTypeEnum.PREMIUMECONOMY.value) {
          if (configuration.parameters().isRefundable() && !listingHelper.global.rateTypeColumns["refundable"].includes(i)) continue;
          if (!listingHelper.global.classTypeColumns["premiumeconomy"].includes(i) || listingHelper.global.rateTypeColumns["refundable"].includes(i)) continue;
          if (i in listingHelper.global.columnsNameIndexMapping) {
            listingHelper.mapData(airlineClassType, listingHelper.global.columnsNameIndexMapping[i], configuration, configuration.isCombined());
          }
          listingHelper.mapData(objectName, enums.classTypeGroupEnum.get("PE").value, configuration, configuration.isCombined());
        }
        else if (configuration.parameters().searchClassType() == enums.classTypeEnum.BUSINESS.value) {
          if (configuration.parameters().isRefundable() && !listingHelper.global.rateTypeColumns["refundable"].includes(i)) continue;
          if (!listingHelper.global.classTypeColumns["business"].includes(i) || listingHelper.global.rateTypeColumns["refundable"].includes(i)) continue;
          if (i in listingHelper.global.columnsNameIndexMapping) {
            listingHelper.mapData(airlineClassType, listingHelper.global.columnsNameIndexMapping[i], configuration, configuration.isCombined());
          }
          listingHelper.mapData(objectName, enums.classTypeGroupEnum.get("B").value, configuration, configuration.isCombined());
        }
        else if (configuration.parameters().searchClassType() == enums.classTypeEnum.FIRST.value) {
          if (configuration.parameters().isRefundable() && !listingHelper.global.rateTypeColumns["refundable"].includes(i)) continue;
          if (!listingHelper.global.classTypeColumns["first"].includes(i) || listingHelper.global.rateTypeColumns["refundable"].includes(i)) continue;
          if (i in listingHelper.global.columnsNameIndexMapping) {
            listingHelper.mapData(airlineClassType, listingHelper.global.columnsNameIndexMapping[i], configuration, configuration.isCombined());
          }
          listingHelper.mapData(objectName, enums.classTypeGroupEnum.get("F").value, configuration, configuration.isCombined());
        }
        else {
          console.log("else continue");
          continue;
        }
      } else {
        if (configuration.parameters().searchClassType() == enums.classTypeEnum.ECONOMY.value) {
          listingHelper.mapData(objectName, enums.classTypeGroupEnum.get("E").value, configuration, configuration.isCombined());
        }
        else if (configuration.parameters().searchClassType() == enums.classTypeEnum.PREMIUMECONOMY.value) {
          listingHelper.mapData(objectName, enums.classTypeGroupEnum.get("PE").value, configuration, configuration.isCombined());
        }
        else if (configuration.parameters().searchClassType() == enums.classTypeEnum.BUSINESS.value) {
          listingHelper.mapData(objectName, enums.classTypeGroupEnum.get("B").value, configuration, configuration.isCombined());
        }
        else if (configuration.parameters().searchClassType() == enums.classTypeEnum.FIRST.value) {
          listingHelper.mapData(objectName, enums.classTypeGroupEnum.get("F").value, configuration, configuration.isCombined());
        }
      }
      /*if (searchInPage){
        clickElements = await tag.elements(browserPage, monitoring, parentElement);
      }else{
        clickElements = await tag.elements(browserPage, monitoring, null);
      }*/
      if (listingHelper.global.isRequestFailed) throw new botError.ProxyError(`Proxy ${configuration.proxy().UserId} got 405 Status code response.`);
      if (tag.raise() && tag.raise() == "screenshot") {
        if (!isScreenshotTaken) {
          var imageName = "detailsScreen-" + configuration.requestDetailId() + "-" + Math.floor((Math.random() * 1000) + 1).toString() + ".png";
          listingHelper.global.cacheUrl = await helper.captureAndUploadScreenshot(browserPage, configuration, imageName);
          isScreenshotTaken = true;
        }
      }
      if (tag.linked()) {
        let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.linked());
        await rawReadSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session);
      }
      if (tag.event()) {
        let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.event());
        await rawReadSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session, clickElements[i]);
      }
      if (tag.raise() && tag.raise() == "flush") {
        logger.Info = "Flush detail handleOutboundInboundClick";
        responseHelper.flush(response, configuration.parameters().isRoundtrip(), false, true, manipulateDate = false);
      }
    }
  }
}

async function getIfIgnore(browserPage, parentElement, searchInPage, tag, monitoring) {
  if (tag.action() == enums.tagTypeEnums.get("click").value) {
    let clickElements = [];
    if (searchInPage) {
      clickElements = await tag.elements(browserPage, monitoring, parentElement);
    } else {
      clickElements = await tag.elements(browserPage, monitoring, null);
    }
    var clickElementsLength = clickElements.length;
    if (clickElementsLength == 0) return true;
    return false;
  }
}

/**
* This method handles the click type of selector.
*
* @param {object}      browserPage        The browser page object.
* @param {object}      parentElement      The object under which the selector would be found.
* @param {boolean}     searchInPage       The boolean value specifying if parent is to be ignored.
* @param {selector}    tag                The selector which is to be evaluated.
* @param {object}      response           The response class object.
* @param {object}      page               The page class object.
* @param {object}      configuration      The configuration class object.
* @param {object}      monitoring         The monitoring class object.
* @param {object}      logger             The logger object.
*
* @return None.
*/
async function handleClick(browserPage, parentElement, searchInPage, tag, page, configuration, response, monitoring, logger, session) {
  if (tag.action() == enums.tagTypeEnums.get("click").value) {
    let clickElements = [];
    if (searchInPage) {
      clickElements = await tag.elements(browserPage, monitoring, parentElement);
    } else {
      clickElements = await tag.elements(browserPage, monitoring, null);
    }
    var clickElementsLength = clickElements.length;
    let arr = Array(clickElementsLength - 0).fill().map((_, idx) => 0 + idx);
    for (let i of arr) {
      if (searchInPage) {
        clickElements = await tag.elements(browserPage, monitoring, parentElement);
      } else {
        clickElements = await tag.elements(browserPage, monitoring, null);
      }
      if (tag.ignoreValue()) {
        if ((await (await clickElements[i].getProperty('className')).jsonValue()).indexOf(tag.ignoreValue()) > -1) continue;
      }
      await browserPage.evaluate(el => {
        setTimeout(function () {
          el.click();
        }, 500);
      }, clickElements[i]);
      await browserPage.waitFor(3000);
      if (listingHelper.global.isRequestFailed) throw new botError.ProxyError(`Proxy ${configuration.proxy().UserId} got 405 Status code response.`);
      if (tag.waitSelector()) {
        while ((await browserPage.$$(tag.waitSelector())).length > 0) {
          await browserPage.waitFor(10000);
        }
      }
      await browserPage.waitFor(3000);
      if (tag.raise() && tag.raise() == "screenshot") {
        if (!isScreenshotTaken) {
          var imageName = "detailsScreen-" + configuration.requestDetailId() + "-" + Math.floor((Math.random() * 1000) + 1).toString() + ".png";
          listingHelper.global.cacheUrl = await helper.captureAndUploadScreenshot(browserPage, configuration, imageName);
          isScreenshotTaken = true;
        }
      }
      if (tag.linked()) {
        let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.linked());
        await rawReadSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session);
      }
      if (tag.event()) {
        let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.event());
        await rawReadSelectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session);
      }
      if (tag.raise() && tag.raise() == "flush") {
        logger.Info = "Flush detail handel click";
        responseHelper.flush(response, configuration.parameters().isRoundtrip(), false, true, manipulateDate = false);
      }
    }
  }
}

module.exports = { rawReadSelectionInfo };
