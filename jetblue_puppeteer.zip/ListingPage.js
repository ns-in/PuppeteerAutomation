var base = require('./BasePage.js');
var enums = require('./Enums.js');
var responseHelper = require('./ResponseHelper.js');
var helper = require('./helper.js');
var botError = require('./BotError.js');
var listingHelper = require('./listing_helper.js');
var rawInboundHelper = require('./Listing_Raw_Inbound.js');
var rawCheapestHelper = require('./Listing_Raw_Inbound_Cheapest.js');
var rawSpecificHelper = require('./Listing_Raw_Specific_Items.js');
var searchPatternListingHelper = require('./ListingPage_SearchPattern.js');
var samePageReadListingHelper = require('./ListingPage_SamePage_Read_NoChange.js');
const {TimeoutError} = require('puppeteer/Errors');

const {performance} = require('perf_hooks');
var pageTitle = null;

var ListingPage = base.BaseCrawlPage.subclass();

ListingPage.prototype._setInput = async function(browserPage, page, configuration, response, monitoring, logger, session){
  let isPageLoaded = await browserPage.evaluate(() => document.readyState);
  let newTabNavigationStartTime = performance.now();
  while(isPageLoaded != "complete"){
    let newTabIntermediateEndTime = performance.now();
    if ((newTabIntermediateEndTime-newTabNavigationStartTime) > 120000) throw new botError.TimeoutError("New Tab navigation timeout exceeded.");
    isPageLoaded = await browserPage.evaluate(() => document.readyState);
  }
  logger.Info = "SetInput completed on listing page.";
  pageTitle = await browserPage.title();
  browserPage.on('response', response => {
    if (response.status() == 405)
    {
      listingHelper.global.isRequestFailed = true;
    }
  });
  await browserPage.waitFor(1000);
  if (page.popUpHandler())
  {
    await browserPage.evaluate(`${page.popUpHandler()}`);
  }
  await applyFilters(browserPage, page, configuration, monitoring, logger);
};

ListingPage.prototype._getInfo = async function(browserPage, page, configuration, response, monitoring, logger, session){
  var isClosed = async function() {
    var promise = new Promise(async function(resolve, reject) {
      let _isClosed = false;
      let _closedTags = page.tagsList().filter(tag => (tag.parent() == null && tag.action() == enums.tagTypeEnums.get("closed").value));
      for (var _closedTag of _closedTags)
      {
        let value = await _closedTag.value(browserPage, monitoring);
        if(_closedTag.objectName() && value){
          if(_closedTag.objectName().trim().toLowerCase() == value.trim().toLowerCase())
          {
            _isClosed = true;
          }
        }else{
          if (value) _isClosed = true;
        }
      }
      resolve(_isClosed);
    });
    return promise;
  };
  if (await isClosed()){
    response.setAvailability = 'C';
    return;
  }
  let _parentTags = await listingHelper.getPageTags(browserPage, monitoring, page, configuration);
  if (_parentTags[0].isCombined() != null)
  {
    configuration._isCombined = _parentTags[0].isCombined();
  }
  if (configuration.parameters().flightClass() == enums.classTypeEnum.RAW.value){
    await rawCheapestHelper.rawCheapestSelectionInfo(browserPage, page, configuration, response, monitoring, logger, _parentTags, session);
  }else if(configuration.parameters().flightClass() == enums.classTypeEnum.RAWINBOUND.value){
    let _pageTypeTags = page.tagsList().filter(tag => (tag.objectName() == "pagetype"));
    let _parentTags = null;
    for(_tag of _pageTypeTags){
      let pageElement = await _tag.element(browserPage, monitoring);
      if(pageElement){
        _parentTags = page.tagsList().filter(tag => (tag.name() == _tag.pageLink()));
        break;
      }
    }
    await browserPage.waitFor(10000);
    await rawInboundHelper.rawInboundSelectionInfo(browserPage, page, configuration, response, monitoring, logger, _parentTags);
  }else if (configuration.parameters().flightClass() == enums.classTypeEnum.RAWSPECIFIC.value) {
    await rawSpecificHelper.rawSpecificSelectionInfo(browserPage, page, configuration, response, monitoring, logger, _parentTags, session);
  }else if (configuration.parameters().flightClass() == enums.classTypeEnum.CHEAPESTSEARCH.value) {
    configuration._isCombined = true;
    await searchPatternListingHelper.searchPatternSelectionInfo(browserPage, page, configuration, response, monitoring, logger, _parentTags, session);
  }
  else if (configuration.parameters().flightClass() == enums.classTypeEnum.RAWSAMEPAGEREADNOCHANGE.value) {
    //if (configuration.parameters().isRoundtrip()) configuration._isCombined = true;
    //if (!configuration.parameters().isRoundtrip()) configuration._isCombined = false;
    //configuration._isCombined = false;
    await samePageReadListingHelper.rawReadSelectionInfo(browserPage, page, configuration, response, monitoring, logger, _parentTags, session);
  }
  else{
    await selectionInfo(browserPage, page, configuration, response, monitoring, logger, _parentTags, session);
  }
  logger.Info = "GetInput completed on listing page.";
};

ListingPage.prototype._navigate = async function(browserPage, page, configuration, response, monitoring, logger, session){
  if (!page.action()) return;
  if (page.action() == enums.actionEnums.get("click").value){
    let navigationElement = await page.actionSelector().element(browserPage, monitoring);
    await navigationElement.click({delay:3000});
    logger.Info = "Navigating from start page.";
  }
};

async function applyFilters(browserPage, page, configuration, monitoring, logger){
  if(page.applyFilters()){
    for (var tag of page.filtersList()){
      if (tag.action() == enums.tagTypeEnums.get("click").value){
        let element = await tag.verifyElement(browserPage, monitoring);
        if (!element) continue;
        await browserPage.evaluate(el => {
          el.click();
        }, element);
        if (tag.waitForNavigation()) {
          try {
            await browserPage.waitForNavigation({timeout: 180000});
          } catch (e) {
            if (e instanceof TimeoutError) {
              let _currentTitle = await browserPage.title();
              console.log(_currentTitle);
              console.log(_currentTitle.toLowerCase() == pageTitle.toLowerCase());
              if (_currentTitle.toLowerCase() == pageTitle.toLowerCase()){
                console.log("Listing timeout catch");
              }else{
                throw new botError.TimeoutError("Page navigation from listing page timeout exceeded.");
              }
            }
          }
          let isPageLoaded = await browserPage.evaluate(() => document.readyState);
          while(isPageLoaded != "complete"){
            isPageLoaded = await browserPage.evaluate(() => document.readyState);
          }
        }else{
          await browserPage.waitFor(6000);
        }
      }
    }
  }
}

/**
 * This method handles traversal of the selectors to extract values.
 *
 * @param {object}      browserPage        The browser page object.
 * @param {object}      page               The page class object.
 * @param {object}      configuration      The configuration class object.
 * @param {object}      response           The response class object.
 * @param {object}      monitoring         The monitoring class object.
 * @param {object}      logger             The logger object.
 * @param {array}       parentTags         The list of selectors.
 * @param {object}      elementHandle      The current select dom object.
 *
 * @return None.
 */
async function selectionInfo(browserPage, page, configuration, response, monitoring, logger, parentTags, session, elementHandle=null){
  await listingHelper.checkForWait(browserPage);
  for (var _tag of parentTags)
  {
    let childTags = null;
    let searchInPage = true;
    if ([enums.tagTypeEnums.get("select").value, enums.tagTypeEnums.get("linked").value].includes(_tag.action()))
    {
      childTags = page.tagsList().filter(tag => tag.parent() == _tag.name());
    }else{
      searchInPage = false;
      childTags = page.tagsList().filter(tag => tag.name() == _tag.name());
    }
    let parentElements = await _tag.elements(browserPage, monitoring, elementHandle);
    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]]; // eslint-disable-line no-param-reassign
        }
    }
    shuffleArray(parentElements);
    for(let [index, parentElement] of parentElements.entries()){
      for (let [cindex, _childTag] of childTags.entries()){
        if (_childTag.applyBusinessRules()){
          if (_childTag.flightType() == "outbound" && listingHelper.global.cheapestSelected && !configuration.parameters().isRawReport()) continue;
          if (_childTag.flightType() == "inbound" && listingHelper.global.cheapestSelectedInbound && !configuration.parameters().isRawReport()) continue;
        }
        if (_childTag.flightType() == "outbound"){
          console.log(`index ${index}`);
          if (!(index in session.outboundInboundItems)) session.outboundInboundItems[index] = {};
          listingHelper.global.outboundItem = index;
        }
        if (_childTag.flightType() == "inbound"){
          listingHelper.global.inboundItem = index;
        }
        await handleSelect(browserPage, parentElement, _childTag, page, configuration, response, monitoring, logger, session);
        await handleClick(browserPage, parentElement, searchInPage, _childTag, page, configuration, response, monitoring, logger, session);
        await listingHelper.handleExtract(browserPage, parentElement, _childTag, page, configuration, response, monitoring, logger, session);
        //if (_childTag.flightType() == "outbound") outboundItem += 1;
      }
      if (_tag.raise() && _tag.raise() == "flush.flightdetails"){
        responseHelper.flushFlightDetails(response);
      }
      if (_tag.raise() && _tag.raise() == "flush.flightdetailsInbound"){
        responseHelper.flushFlightDetailsInbound(response);
      }
    }
  }
}

/**
 * This method handles the select type of selector used for navigating into the dom tree.
 *
 * @param {object}      browserPage        The browser page object.
 * @param {object}      parentElement      The object under which the selector would be found.
 * @param {selector}    tag                The selector which is to be evaluated.
 * @param {object}      response           The response class object.
 * @param {object}      page               The page class object.
 * @param {object}      configuration      The configuration class object.
 * @param {object}      monitoring         The monitoring class object.
 * @param {object}      logger             The logger object.
 *
 * @return None.
 */
async function handleSelect(browserPage, parentElement, tag, page, configuration, response, monitoring, logger, session){
  if ([enums.tagTypeEnums.get("select").value].includes(tag.action())){
    if (tag.raise() && tag.raise() == "screenshot"){
      var imageName = "detailsScreen-" + configuration.requestDetailId() + "-" + Math.floor((Math.random() * 1000) + 1).toString() + ".png";
      listingHelper.global.cacheUrl = await helper.captureAndUploadScreenshot(browserPage, configuration, imageName);
    }
    await selectionInfo(browserPage, page, configuration, response, monitoring, logger, [tag], session, parentElement);
    if (tag.event()){
      let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.event());
      await selectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session);
    }
    if (tag.raise() && tag.raise() == "flush"){
      responseHelper.flush(response, configuration.parameters().isRoundtrip(), configuration.isCombined());
    }
  }
}

/**
 * This method handles the click type of selector.
 *
 * @param {object}      browserPage        The browser page object.
 * @param {object}      parentElement      The object under which the selector would be found.
 * @param {boolean}     searchInPage       The boolean value specifying if parent is to be ignored.
 * @param {selector}    tag                The selector which is to be evaluated.
 * @param {object}      response           The response class object.
 * @param {object}      page               The page class object.
 * @param {object}      configuration      The configuration class object.
 * @param {object}      monitoring         The monitoring class object.
 * @param {object}      logger             The logger object.
 *
 * @return None.
 */
async function handleClick(browserPage, parentElement, searchInPage, tag, page, configuration, response, monitoring, logger, session){
  if (tag.action() == enums.tagTypeEnums.get("click").value)
  {
    let clickElements = [];
    if (searchInPage){
      clickElements = await tag.elements(browserPage, monitoring, parentElement);
    }else{
      clickElements = await tag.elements(browserPage, monitoring, null);
    }
    var clickElementsLength = clickElements.length;
    let arr = Array(clickElementsLength - 0 ).fill().map((_, idx) => 0 + idx);
    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]]; // eslint-disable-line no-param-reassign
        }
    }
    shuffleArray(arr);
    for (let i of arr){
      if (searchInPage){
        clickElements = await tag.elements(browserPage, monitoring, parentElement);
      }else{
        clickElements = await tag.elements(browserPage, monitoring, null);
      }
      if (tag.ignoreValue())
      {
        if ((await(await clickElements[i].getProperty('className')).jsonValue()).indexOf(tag.ignoreValue()) > -1) continue;
      }
      if (!configuration.parameters().isRawReport() && tag.cheapestIndicator())
      {
        let isCheapest = await browserPage.evaluate((element, className) => {
          let len = element.querySelectorAll(className).length;
          if (len > 0) return Promise.resolve(true);
          return Promise.resolve(false);
        }, clickElements[i], tag.cheapestIndicator().match(/[^ ,]+/g).join('.'));
        if (!isCheapest) continue;
      }
      if (tag.flightType() == "inbound") {
        if ((listingHelper.global.inboundItem in session.outboundInboundItems[listingHelper.global.outboundItem][listingHelper.global.outboundColumnItem]) && (session.outboundInboundItems[listingHelper.global.outboundItem][listingHelper.global.outboundColumnItem][listingHelper.global.inboundItem].includes(i))) continue;
      }
      if (tag.flightType() == "outbound" && !configuration.parameters().isRoundtrip()) {
        if ((i in session.outboundInboundItems[listingHelper.global.outboundItem])) continue;
      }
      await browserPage.evaluate(el => {
        setTimeout(function() {
          el.click();
        }, 2000);
      }, clickElements[i]);
      await browserPage.waitFor(3000);
      if (listingHelper.global.isRequestFailed) throw new botError.ProxyError(`Proxy ${configuration.proxy().UserId} got 405 Status code response.`);
      if (tag.flightType() == "inbound") {
        listingHelper.global.cheapestSelectedInbound = true;
        if (!(listingHelper.global.inboundItem in session.outboundInboundItems[listingHelper.global.outboundItem][listingHelper.global.outboundColumnItem])) session.outboundInboundItems[listingHelper.global.outboundItem][listingHelper.global.outboundColumnItem][listingHelper.global.inboundItem] = [];
        if (!(session.outboundInboundItems[listingHelper.global.outboundItem][listingHelper.global.outboundColumnItem][listingHelper.global.inboundItem].includes(i))) session.outboundInboundItems[listingHelper.global.outboundItem][listingHelper.global.outboundColumnItem][listingHelper.global.inboundItem].push(i);
      }
      if (tag.flightType() == "outbound") {
        listingHelper.global.cheapestSelected = true;
        if (!(i in session.outboundInboundItems[listingHelper.global.outboundItem])) session.outboundInboundItems[listingHelper.global.outboundItem][i] = {};
        listingHelper.global.outboundColumnItem = i;
      }
      if (tag.waitSelector())
      {
        while((await browserPage.$$(tag.waitSelector())).length > 0)
        {
          await browserPage.waitFor(10000);
        }
      }
      await browserPage.waitFor(300);
      if (tag.linked())
      {
        if (tag.raise() && tag.raise() == "screenshot"){
          var imageName = "detailsScreen-" + configuration.requestDetailId() + "-" + Math.floor((Math.random() * 1000) + 1).toString() + ".png";
          listingHelper.global.cacheUrl = await helper.captureAndUploadScreenshot(browserPage, configuration, imageName);
          listingHelper.global.index += 1;
        }
        let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.linked());
        await selectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session);
      }
      if (tag.event()){
        let subChildTags = page.tagsList().filter(_tag => _tag.name() == tag.event());
        await selectionInfo(browserPage, page, configuration, response, monitoring, logger, subChildTags, session);
      }
      if (tag.raise() && tag.raise() == "flush"){
        responseHelper.flush(response, configuration.parameters().isRoundtrip(), configuration.isCombined());
      }
    }
  }
}

module.exports = {ListingPage};
