const uuidv4 = require('uuid/v4');
var dateFormat = require('dateformat');
var enums = require('./Enums.js');

var baseFlightTypeDetails = {
  "arrivalTime": null,
  "departureTime": null,
  "stopOvers": null,
  "guid": null,
  "outboundGuid": null,
  "price": [],
  "flightDetails": [],
  "duration": null,
  "fareCode": null,
  "route": null,
  "extraText": null,
  "customValue": null,
  "discount": 0,
  "OTAPosition": "",
  "OTAName": "",
  "baggage1Fee": 0,
  "baggage2Fee": 0,
  "baggage3Fee": 0,
  "creditCardDetails": null,
  "operatingCXR": "",
  "bookingClassCode": null,
  "extAncillaryService": null,
  "ancillaryCurrency": null,
  "path": null
}
var baseFlightDetails = {
    "index": null,
    "airlineName": '',
    "flightNumber": null,
    "airlineCode": null,
    "extraText": null,
    "mealPlan": null,
    "type": '',
    "layover": null,
    "city": '',
    "departureTime": null,
    "arrivalTime": null,
    "airportName": null,
    "destinationAirport": null,
    "duration": null
}
var basePrice  = {
  "index": 1,
  "classType": null,
  "airlineClassType": null,
  "price": null,
  "tax": {},
  "fareCode": null,
  "discount": 0,
  "isTaxIncluded": false
}
var flightDetails = Object.assign({}, baseFlightDetails);
var flightDetailsInbound = Object.assign({}, baseFlightDetails);
var priceDetails = Object.assign({}, basePrice);
var priceDetailsInbound = Object.assign({}, basePrice);
var priceDetailsInboundList = [];
var priceDetailsOutboundList = [];
var priceDetailsCombined = Object.assign({}, basePrice);
var outboundTypeDetails = JSON.parse(JSON.stringify(baseFlightTypeDetails)); //Object.assign({}, baseFlightTypeDetails);
var inboundTypeDetails = JSON.parse(JSON.stringify(baseFlightTypeDetails));
var combinedTypeDetails = JSON.parse(JSON.stringify(baseFlightTypeDetails));
var flightDetailsIndex = 0;
var flightDetailsIndexInbound = 0;
var priceDetailsIndexInbound = 1;
var priceDetailsIndexOutbound = 1;
var currency = "";

function getKey(object, key) {
  let obj = Object.keys(object).find(k => k.toLowerCase() === key.toLowerCase());
  return obj;
}

function evaluateExpression(value, expression, paxCount=1){
  if(Object.keys(expression).length == 0){
    return null;
  }else{
    if(expression["type"] == enums.expressionTypeEnums.get("regex").value){
        let res = value.match(expression["pattern"]);
        value = [];
        if(expression["value"].constructor === Array){
            for(i=0; i<=expression["value"].length; i++){
                value.push(res[i]);
            }
        }
        else{
            value.push(res[0]);
        }
        let result = evaluateValue(value , expression["value"], paxCount);
        return result;
      }else if(expression["type"] == enums.expressionTypeEnums.get("split").value){
        value = value.split(expression["pattern"]);
        result = evaluateValue(value, expression["value"], paxCount);
        return result;
    }
  }
}

function evaluateValue(value, valArr, paxCount){
  let output = [];
  for(let [index, val] of valArr.entries()){
    if(Object.keys(val["expression"]).length != 0){
      let temp = evaluateExpression(value[index], val["expression"]);
      output = output.concat(temp);
      // console.log("temp: ", temp)
    }else{
      if(val.manipulate && val.manipulate.toLowerCase() == "divide" && val.manipulateBy.toLowerCase() == "pax")
      {
        value[val.index] = parseFloat(value[val.index].replace(',', ''))/parseInt(paxCount);
      }
      output.push({"objectName": val["value"], "value": value[val.index]});
    }
  }
  return output;
}

function mapValueToData(objectName, value, cacheUrl, isRoundtrip, isCombined, expression, paxCount=1){
  let values = [];
  if (expression){
    values = evaluateExpression(value, expression, paxCount);
  }else{
    values = [{"value": value, "objectName": ""}];
  }
  for(var i of values){
    let objects = objectName.split('>');
    value = i["value"];
    if (i["objectName"].length != 0){
      objects.push(i["objectName"]);
    }
    if (cacheUrl)
    {
      if (!outboundTypeDetails.path) outboundTypeDetails.path = cacheUrl;
      if (!inboundTypeDetails.path) inboundTypeDetails.path = cacheUrl;
    }
    switch (objects[0].toLowerCase()) {
      case ("outbound"):
        if (cacheUrl && !outboundTypeDetails.path) outboundTypeDetails.path = cacheUrl;
        break;
      case ("inbound"):
        if (cacheUrl && (!inboundTypeDetails.path || inboundTypeDetails.path != cacheUrl)) inboundTypeDetails.path = cacheUrl;
        break;
      }
    // prev code unchanged from here
    if (objects[0].toLowerCase() == "response"){
      if (objects[1].toLowerCase() == "currency"){
        currency = value.toString().trim();
      }
      return;
    }
    if (!isRoundtrip && objects[0].toLowerCase() == "combined") objects[0] = "outbound";
    if (isRoundtrip && isCombined && objects[1].toLowerCase() == "price") objects[0] = "combined";
    switch (true) {
      case ((objects[0].toLowerCase() == "outbound") && (objects[1].toLowerCase() == "flightdetails") && (getKey(baseFlightDetails, objects[2].toLowerCase()) in flightDetails)):
        flightDetails.index = flightDetailsIndex;
        flightDetails[getKey(baseFlightDetails, objects[2].toLowerCase())] = value;
        break;
      case ((objects[0].toLowerCase() == "inbound") && (objects[1].toLowerCase() == "flightdetails") && (getKey(baseFlightDetails, objects[2].toLowerCase()) in flightDetailsInbound)):
        flightDetailsInbound.index = flightDetailsIndexInbound;
        flightDetailsInbound[getKey(baseFlightDetails, objects[2].toLowerCase())] = value;
        break;
      case (!isCombined && (objects[0].toLowerCase() == "inbound") && objects[1].toLowerCase() == "price"):
        if (cacheUrl && (!inboundTypeDetails.path || inboundTypeDetails.path != cacheUrl)) inboundTypeDetails.path = cacheUrl;
        if (objects[2].toLowerCase() == "tax"){
          priceDetailsInbound[getKey(basePrice, objects[2].toLowerCase())]['other'] = value.toString().replace(',', '');
        }
        else{
          priceDetailsInbound.index = priceDetailsIndexInbound;
          priceDetailsInbound[getKey(basePrice, objects[2].toLowerCase())] = value.toString().replace(',', '');
        }
        return;
      case (!isCombined && (objects[0].toLowerCase() == "outbound") && objects[1].toLowerCase() == "price"):
        if (cacheUrl && !outboundTypeDetails.path) outboundTypeDetails.path = cacheUrl;
        if (objects[2].toLowerCase() == "tax"){
          priceDetails[getKey(basePrice, objects[2].toLowerCase())]['other'] = value.toString().replace(',', '');
        }
        else{
          priceDetails.index = priceDetailsIndexOutbound;
          priceDetails[getKey(basePrice, objects[2].toLowerCase())] = value.toString().replace(',', '');
        }
        return;
      case (!isRoundtrip && (objects[0].toLowerCase() == "outbound") && objects[1].toLowerCase() == "price"):
        if (cacheUrl && !outboundTypeDetails.path) outboundTypeDetails.path = cacheUrl;
        if (objects[2].toLowerCase() == "tax"){
          priceDetails[getKey(basePrice, objects[2].toLowerCase())]['other'] = value.toString().replace(',', '');
        }
        else{
          priceDetails.index = priceDetailsIndexOutbound;
          priceDetails[getKey(basePrice, objects[2].toLowerCase())] = value.toString().replace(',', '');
        }
        return;
      case ((objects[0].toLowerCase() == "combined") && objects[1].toLowerCase() == "price"):
        if (objects[2].toLowerCase() == "tax"){
          priceDetailsCombined[getKey(basePrice, objects[2].toLowerCase())]['other'] = value.toString().replace(',', '');
        }
        else{
          priceDetailsCombined[getKey(basePrice, objects[2].toLowerCase())] = value.toString().replace(',', '');
        }
        return;
      case ((objects[1].toLowerCase() != "flightdetails") && (objects[1].toLowerCase() != "price")):
        switch (objects[0].toLowerCase()) {
          case ("outbound"):
            if (cacheUrl && !outboundTypeDetails.path) outboundTypeDetails.path = cacheUrl;
            //if (objects[1].toLowerCase() == "arrivaltime"){
              //if (outboundTypeDetails[getKey(baseFlightTypeDetails, objects[1].toLowerCase())]) return;
            //}
            setBaseFlightTypeDetails(outboundTypeDetails, objects[1].toLowerCase(), value);
            return;
          case ("inbound"):
            if (cacheUrl && (!inboundTypeDetails.path || inboundTypeDetails.path != cacheUrl)) inboundTypeDetails.path = cacheUrl;
            //if (objects[1].toLowerCase() == "arrivaltime"){
              //if (inboundTypeDetails[getKey(baseFlightTypeDetails, objects[1].toLowerCase())]) return;
            //}
            setBaseFlightTypeDetails(inboundTypeDetails, objects[1].toLowerCase(), value);
            return;
          case ("combined"):
            if (objects[1].toLowerCase() == "arrivaltime"){
              if (combinedTypeDetails[getKey(baseFlightTypeDetails, objects[1].toLowerCase())]) return;
            }
            setBaseFlightTypeDetails(combinedTypeDetails, objects[1].toLowerCase(), value);
            return;
        }
      default:
    }
  }

}

function setBaseFlightTypeDetails(obj, key, value){
  if (key.toLowerCase() == "departuretime"){
    if (obj[getKey(baseFlightTypeDetails, key.toLowerCase())] == null) obj[getKey(baseFlightTypeDetails, key.toLowerCase())] = value;
  } else{
    obj[getKey(baseFlightTypeDetails, key.toLowerCase())] = value;
  }
}

function flushFlightDetails(response){
  outboundTypeDetails.flightDetails.push(flightDetails);
  baseFlightTypeDetails.flightDetails = [];
  flightDetails = Object.assign({}, baseFlightDetails);
  flightDetailsIndex += 1;
}

function flushPriceDetails(response, isTaxIncluded){
  priceDetails.isTaxIncluded = isTaxIncluded;
  priceDetailsOutboundList.push(priceDetails);
  //baseFlightTypeDetails.price = [];
  priceDetails = Object.assign({}, basePrice);
  priceDetailsIndexOutbound += 1;
}

function flushFlightDetailsInbound(response){
  inboundTypeDetails.flightDetails.push(flightDetailsInbound);
  baseFlightTypeDetails.flightDetails = [];
  flightDetailsInbound = Object.assign({}, baseFlightDetails);
  flightDetailsIndexInbound += 1;
}

function flushPriceDetailsInbound(isTaxIncluded=false){
  priceDetailsInbound.isTaxIncluded = isTaxIncluded;
  priceDetailsInboundList.push(priceDetailsInbound);
  //baseFlightTypeDetails.price = [];
  priceDetailsInbound = Object.assign({}, basePrice);
  priceDetailsIndexInbound += 1;
}

function flush(response, isRoundtrip, isCombined=false, clearOutbound = true, manipulateDate=true){
  if (!outboundTypeDetails['guid']) outboundTypeDetails['guid'] = uuidv4();
  outboundTypeDetails = updateObjectData(outboundTypeDetails, manipulateDate);
  if (isRoundtrip) {
    inboundTypeDetails = updateObjectData(inboundTypeDetails, manipulateDate);
    if (!inboundTypeDetails['guid']) inboundTypeDetails['guid'] = uuidv4();
    inboundTypeDetails.outboundGuid = outboundTypeDetails['guid'];
    if (!inboundTypeDetails.path) inboundTypeDetails.path =outboundTypeDetails.path;
    if(isCombined){
      combinedTypeDetails['guid'] = inboundTypeDetails['guid'];
      combinedTypeDetails.price.push(priceDetailsCombined);
      combinedTypeDetails.path =outboundTypeDetails.path;
      response.setCombined = Object.assign({}, combinedTypeDetails);
    }else{
      if (priceDetailsOutboundList.length == 0)
      {
        outboundTypeDetails.price.push(priceDetails);
      }else{
        outboundTypeDetails.price = priceDetailsOutboundList;
      }
      if(priceDetailsInboundList.length == 0){
        inboundTypeDetails.price.push(priceDetailsInbound);
      }
      else{
        inboundTypeDetails.price = priceDetailsInboundList;
      }
    }
    response.setInbound = Object.assign({}, inboundTypeDetails);
  }else{
    if (priceDetailsOutboundList.length == 0)
    {
      outboundTypeDetails.price.push(priceDetails);
    }else{
      outboundTypeDetails.price = [...priceDetailsOutboundList];
    }
  }
  if (!currency) currency = "USD";
  response.setCurrency = currency;
  response.setOutbound = Object.assign({}, outboundTypeDetails);
  baseFlightTypeDetails.flightDetails = [];
  baseFlightTypeDetails.price = [];
  if(clearOutbound) outboundTypeDetails = JSON.parse(JSON.stringify(baseFlightTypeDetails));
  inboundTypeDetails = JSON.parse(JSON.stringify(baseFlightTypeDetails));
  combinedTypeDetails = JSON.parse(JSON.stringify(baseFlightTypeDetails));
  flightDetails = Object.assign({}, baseFlightDetails);
  flightDetailsInbound = Object.assign({}, baseFlightDetails);
  priceDetails = Object.assign({}, basePrice);
  priceDetailsInbound = Object.assign({}, basePrice);
  priceDetailsCombined = Object.assign({}, basePrice);
  priceDetailsInboundList = [];
  priceDetailsOutboundList = [];
  flightDetailsIndex = 0;
  flightDetailsIndexInbound = 0;
  priceDetailsIndexInbound = 1;
  priceDetailsIndexOutbound = 1;
}

function flushOutbound(response, manipulateDate=true){
  if (!outboundTypeDetails['guid']) outboundTypeDetails['guid'] = uuidv4();
  outboundTypeDetails = updateObjectData(outboundTypeDetails, manipulateDate);
  if (priceDetailsOutboundList.length == 0)
  {
    outboundTypeDetails.price.push(priceDetails);
  }else{
    outboundTypeDetails.price = [...priceDetailsOutboundList];
  }
  if (!currency) currency = "USD";
  response.setCurrency = currency;
  response.setOutbound = Object.assign({}, outboundTypeDetails);
  baseFlightTypeDetails.flightDetails = [];
  baseFlightTypeDetails.price = [];
  outboundTypeDetails = JSON.parse(JSON.stringify(baseFlightTypeDetails));
  flightDetails = Object.assign({}, baseFlightDetails);
  priceDetails = Object.assign({}, basePrice);
  priceDetailsOutboundList = [];
  flightDetailsIndex = 0;
  priceDetailsIndexOutbound = 1;
}

function flushInbound(response, manipulateDate=true){
  inboundTypeDetails = updateObjectData(inboundTypeDetails, manipulateDate);
  for (let _outbound of response.outbound)
  {
    if (!inboundTypeDetails['guid']) inboundTypeDetails['guid'] = uuidv4();
    inboundTypeDetails.outboundGuid = _outbound['guid'];
    if(priceDetailsInboundList.length == 0){
      inboundTypeDetails.price.push(priceDetailsInbound);
    }
    else{
      inboundTypeDetails.price = [...priceDetailsInboundList];
    }
    response.setInbound = Object.assign({}, inboundTypeDetails);
  }
  if (!currency) currency = "USD";
  response.setCurrency = currency;
  baseFlightTypeDetails.flightDetails = [];
  baseFlightTypeDetails.price = [];
  inboundTypeDetails = JSON.parse(JSON.stringify(baseFlightTypeDetails));
  flightDetailsInbound = Object.assign({}, baseFlightDetails);
  priceDetailsInbound = Object.assign({}, basePrice);
  priceDetailsInboundList = [];
  flightDetailsIndexInbound = 0;
  priceDetailsIndexInbound = 1;
}


function updateObjectData(object, manipulateDate){
  object.stopOvers = (object.flightDetails.length -1 > 0)?object.flightDetails.length -1 : 0;
  object['departureTime'] = dateFormat(object['departureTime'], "mm/dd/yyyy").toString().trim();
  var arrivalDate = new Date(object['departureTime']);
  if (object['arrivalTime'] && manipulateDate){
    object['arrivalTime'] = object['arrivalTime'].substring(1,2);
    arrivalDate.setDate(arrivalDate.getDate() + parseInt(object['arrivalTime']));
    object['arrivalTime'] = dateFormat(arrivalDate.toString(), "mm/dd/yyyy").toString().trim();
  }else{
    if (!object['arrivalTime']) object['arrivalTime'] = object['departureTime'].toString().trim();
    object['arrivalTime'] = dateFormat(object['arrivalTime'], "mm/dd/yyyy").toString().trim();
  }
  if (object.stopOvers == 0 && object.duration == null && object.flightDetails.length > 0){
    object.duration = object.flightDetails[0].duration;
  }
  if (object.flightDetails.length == 0) return object;
  object['departureTime'] = object['departureTime'] + " " + object.flightDetails[0]['departureTime'];
  object['arrivalTime'] = object['arrivalTime'] + " " + object.flightDetails[object.flightDetails.length - 1]['arrivalTime'];
  return object;
}

module.exports = {mapValueToData, flush, flushFlightDetails, flushFlightDetailsInbound, flushPriceDetailsInbound, flushPriceDetails,flushOutbound, flushInbound};
